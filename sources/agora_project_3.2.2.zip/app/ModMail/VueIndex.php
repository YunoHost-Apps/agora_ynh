<script>
$(function(){
	////	Init l'affichage de l'arborescence de contacts
	$(".vMails").each(function(){
		var folderTreeLevel=$(this).attr("data-treeLevel");
		if(typeof folderTreeLevel!=="undefined" && folderTreeLevel>0)
			{$(this).css("padding-left",(folderTreeLevel*22)+"px");}
	});

	////	Affiche/masque les users d'un espace (sauf espace courant)
	$(".vMailsLabel").click(function(){
		$("#mailsList"+$(this).attr("data-targetObjId")).slideToggle();
	});

	////	Switch la sélection d'users/contacts
	$(".vSwitchSelect").click(function(){
		$("#"+$(this).attr("data-mailsListId")+" input[name='personList[]']").each(function(){
			$(this).prop("checked", !$(this).prop("checked")).trigger("change");
		});
	});

	////	Fixe la hauteur de l'éditeur et Préselectionne le titre du mail
	$("[name='title']").focus();
});

////    On contrôle le formulaire
function formControl()
{
	//Sélection d'une personne, d'un titre et d'un message
	if($("[name='personList[]']:checked").length==0 && $("[name='groupList[]']:checked").length==0)	{notify("<?= Txt::trad("MAIL_specifier_mail") ?>");	return false;}
	else if($("[name='title']").isEmpty())															{notify("<?= Txt::trad("requiredFields")." : ".Txt::trad("title") ?>");	 return false;}
	else if(isEmptyEditor("description"))															{notify("<?= Txt::trad("requiredFields")." : ".Txt::trad("description") ?>");	 return false;}
}
</script>

<style>
/*Menu de gauche*/
.vMailsBlock		{margin:10px 0px 0px 4px;}
.vMailsLabel img	{max-width:24px;}
.vMailsMenu			{padding-left:24px !important; display:none;}
.vMailsMenu>div		{padding:2px;}
.vMailsMenu img		{max-width:18px;}
.vMailsMenu[id='mailsList<?= Ctrl::$curSpace->_targetObjId ?>']	{display:block;}/*par défaut, on n'affiche que les users de l'espace courant*/
/*formulaire principal*/
.vMailMain			{padding:10px;}
.vMailMain [name='title']	{width:100%; margin-bottom:20px;}
.vMailMain [name='description']	{height:300px;}
.vMailOptions		{display:table; width:100%; margin-top:20px;}
.vMailOptions>div	{display:table-cell;}
.vMailOptions>div:last-child{text-align:right;}
[id^='files']:not([id='files1'])	{display:none;}
.formMainButton		{margin-top:10px;}/*surcharge*/

/*RESPONSIVE*/
@media screen and (max-width:1024px){
	.vMailOptions, .vMailOptions>div	{display:inline-block; margin-bottom:10px;}
}
</style>

<form action="index.php" method="post" onsubmit="return formControl()" enctype="multipart/form-data" class="mainPageForm">
<div class="pageCenter">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?php
			////	LISTE DES MAILS : USERS DE L'AGORA / DU MODULE CONTACT
			foreach($containerList as $tmpContainer)
			{
				//Init
				$cptPerson=0;
				$tmpSwitchLabel=$tmpGroupsLabels=$tmpUsersLabels=null;
				//SWITCH LA SELECTION (2 à 500 pers.)
				if(count($tmpContainer->personList)>=2 && count($tmpContainer->personList)<=500)
					{$tmpSwitchLabel="<div class='vSwitchSelect sLink' data-mailsListId='mailsList".$tmpContainer->_targetObjId."'><img src='app/img/switch.png' class='vPersonImg'> ".Txt::trad("invertSelection")."</div>";}
				//GROUPES D'USERS (ESPACE)
				if($tmpContainer::objectType=="space"){
					foreach(MdlUserGroup::getGroups($tmpContainer) as $tmpGroup){
						$tmpBoxId=$tmpContainer->_targetObjId.$tmpGroup->_targetObjId;
						$tmpGroupsLabels.="<div title=\"".$tmpGroup->usersLabel."\"><input type='checkbox' name=\"groupList[]\" value=\"".$tmpGroup->_targetObjId."\" id=\"".$tmpBoxId."\"> <label for=\"".$tmpBoxId."\"><img src='app/img/user/userGroup.png' class='vPersonImg'> ".$tmpGroup->title."</label></div>";
					}
				}
				//PERSONNES DU CONTENEUR
				foreach($tmpContainer->personList as $tmpPerson){
					if(empty($tmpPerson->mail) || ($tmpContainer::objectType=="contactFolder" && $cptPerson>500))	{continue;}//zap  les users sans mails et Limit à 500 pers. pour les contacts
					$tmpBoxId=$tmpContainer->_targetObjId.$tmpPerson->_targetObjId;
					$tmpUsersLabels.="<div title=\"".$tmpPerson->mail."\"><input type='checkbox' name=\"personList[]\" value=\"".$tmpPerson->_targetObjId."\" id=\"".$tmpBoxId."\"> <label for=\"".$tmpBoxId."\">".$tmpPerson->display()."</label></div>";
					$cptPerson++;
				}
				////	AFFICHE CHAQUE BLOCK D'USERS / CONTACTS
				echo "<div class='vMailsBlock' ".($tmpContainer::objectType=="contactFolder"?"data-treeLevel='".$tmpContainer->treeLevel."'":null).">
						<div class='vMailsLabel sLink' data-targetObjId=\"".$tmpContainer->_targetObjId."\"><img src=\"app/img/".($tmpContainer::objectType=="space"?"user":"contact")."/iconSmall.png\"> ".$tmpContainer->name." <img src='app/img/arrowBottom.png'></div>
						<div class='vMailsMenu' id=\"mailsList".$tmpContainer->_targetObjId."\">".$tmpGroupsLabels.$tmpUsersLabels.$tmpSwitchLabel."</div>
					</div>";
			}
			?>
			<hr>
			<div class="menuLine sLink" onclick="lightboxOpen('?ctrl=mail&action=mailHistory');">
				<div class="menuIcon"><img src="app/img/mail/mailHistory.png"></div>
				<div><?= Txt::trad("MAIL_historique_mail") ?></div>
			</div>
		</div>
	</div>

	<div class="pageCenterContent">
		<div class="vMailMain sBlock">
			<input type="text" name="title" placeholder="<?= txt::trad("MAIL_title") ?>">
			<textarea name="description"></textarea>
			<?= CtrlMisc::initHtmlEditor("description") ?>
			<div class="vMailOptions">
				<div>
					<?php if(!empty(Ctrl::$curUser->mail)){ ?><div title="<?= Txt::trad("MAIL_receptionNotifInfo") ?>"><input type="checkbox" name="receptionNotif" value="1" id="receptionNotif"><label for="receptionNotif"><?= Txt::trad("MAIL_receptionNotif") ?></label></div><?php } ?>
					<div title="<?= Txt::trad("MAIL_hideRecipientsInfo") ?>"><input type="checkbox" name="hideRecipients" value="1" id="hideRecipients" <?= $checkhideRecipients ?>><label for="hideRecipients"><?= Txt::trad("MAIL_hideRecipients") ?></label></div>
					<div title="<?= Txt::trad("MAIL_noFooterInfo") ?>"><input type="checkbox" name="noFooter" value="1" id="noFooter"><label for="noFooter"><?= Txt::trad("MAIL_noFooter") ?></label></div>
				</div>
				<div title="<?= File::uploadMaxFilesize("info") ?>">
					<?php for($i=1; $i<=10; $i++){ ?><div id="files<?= $i ?>"><?= Txt::trad("MAIL_fichier_joint") ?>  <input type="file" name="files<?= $i ?>" onChange="$('#files<?= $i+1 ?>').fadeIn();"></div><?php } ?>
				</div>
			</div>
			<?= Txt::formValidate("send",true) ?>
		</div>
	</div>
</div>
</form>