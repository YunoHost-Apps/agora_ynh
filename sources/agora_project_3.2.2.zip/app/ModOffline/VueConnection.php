<script type="text/javascript">
////	Acces guest à un espace  (accès direct ou avec mot de passe)
function publicSpaceAccess(_idSpace, password)
{
	// Accès direct sans password  /  Saisie du mot de passe  /  Controle Ajax du mot de passe
	if(password==0)			{redir("?_idSpaceAccess="+_idSpace);}
	else if(password==1)	{lightboxPrompt("<?= Txt::trad("password") ?>", "publicSpaceAccess('"+_idSpace+"',$('.promptInputText').val());", "password");}
	else if(password.length>1)
	{
		var ajaxUrl="?action=publicSpaceAccess&password="+encodeURIComponent(password)+"&_idSpace="+encodeURIComponent(_idSpace);
		$.ajax(ajaxUrl).done(function(ajaxResult){
			if(find("true",ajaxResult))	{redir("?_idSpaceAccess="+_idSpace+"&password="+password);}
			else						{notify("<?= Txt::trad("spacePassError") ?>");  return false;}
		});
	}
}

////	Init la page
$(function(){
	// apparition en "fade" du formulaire
	$(".sBlock").fadeIn(800);
	// Mets le focus sur l'input du login (ou le password)
    $("input[name='<?= empty($defaultLogin) ? "connectLogin" : "connectPassword" ?>']").focus();
	//Fait clignoter le "vForgotPassword" si une mauvaise authentification vient d'être faite
	<?php if(Req::isParam("msgNotif") && (in_array("NOTIF_identification",Req::getParam("msgNotif")) || in_array(Txt::trad("NOTIF_identification"),Req::getParam("msgNotif")))){ ?>
		$(".vForgotPassword").addClass("underlineShadow").css("color","#d00").effect("pulsate",{times:20},20000);
	<?php } ?>
});
</script>


<style>
/*Header Bar (surcharges) & Principaux blocks*/
.headerBarCell			{padding-left:10px; padding-right:10px;}
.headerBarCell:nth-child(2)	{text-align:right;}
.vPageCenter			{text-align:center; margin-top:200px;}
.sBlock					{position:relative; display:none; width:650px; margin-left:auto; margin-right:auto;}/*surcharge*/
.vBlockLogoConnect		{margin-bottom:50px; padding:5px;}
.vBlockLogoConnect img	{max-width:99%; max-height:250px;}
.vBlockIdentify			{padding-top:30px;}
.vBlockPublic			{margin-top:50px;}

/*Identification*/
.vBlockIcon				{position:absolute; top:-10px; left:-10px;}
[name="connectLogin"]	{width:180px;}
[name="connectPassword"]{width:100px;}
[type="submit"]			{margin-left:5px;}
.vConnectOptions		{display:table; width:100%; margin-top:20px;}
.vConnectOptions>div	{display:table-cell; text-align:left; padding:5px;}
.vConnectOptions>div:last-child	{text-align:right;}
.vForgotPassword		{margin-left:15px;}
img[src*='check']		{height:16px;}

/*Accès public*/
.vPublic			{display:table; width:100%;}
.vPublic>div		{display:table-cell; text-align:left; padding:30px 10px 30px 10px;}
.vPublic>div:first-child		{text-align:right;}
.vPublicSpace:not(:first-child)	{margin-top:15px;}

/*RESPONSIVE*/
@media screen and (max-width:1024px)
{
	.headerBarCell:nth-child(2)	{font-size:90%; font-weight:normal;}
	.vPageCenter			{margin-top:80px;}
	.sBlock					{box-sizing:border-box; width:95%;}
	.vBlockLogoConnect		{margin-bottom:30px;}
	.vBlockLogoConnect img	{max-height:120px;}
	.vBlockPublic			{margin-top:30px;}
	.vBlockIcon				{left:-5px;}
	[name="connectLogin"], [name="connectPassword"], [type="submit"]	{width:250px !important; height:35px !important; margin-bottom:10px !important;}
	.vForgotPassword		{display:block; margin-top:10px;}
}
</style>


<div class="headerBar">
	<div class="headerBarCell"><?= Ctrl::$agora->name ?></div>
	<div class="headerBarCell"><?= Ctrl::$agora->description ?></div>
</div>


<div class="vPageCenter">

	<!--LOGO DE CONNEXION-->
	<?php if(strlen(Ctrl::$agora->pathLogoConnect())){ ?>
	<div class="sBlock vBlockLogoConnect">
		<img src="<?= Ctrl::$agora->pathLogoConnect() ?>">
	</div>
	<?php } ?>
	
	<!--BLOCK "IDENTIFICATION"-->
	<form action="index.php" method="post" class="sBlock vBlockIdentify" OnSubmit="return controlConnect()">
		<img src="app/img/connection.png" class="vBlockIcon">
		<!--INPUTS PRINCIPAUX-->
		<input type="text" name="connectLogin" value="<?= $defaultLogin ?>" placeholder="<?= Txt::trad("placeholderLogin") ?>" title="<?= Txt::trad("placeholderLogin") ?>">
		<input type="password" name="connectPassword" placeholder="<?= Txt::trad("password") ?>" title="<?= Txt::trad("password") ?>">
		<?php if(Req::isParam(["targetObjUrl","_idSpaceAccess"])){ ?>
			<input type="hidden" name="targetObjUrl" value="<?= Req::getParam("targetObjUrl") ?>">
			<input type="hidden" name="_idSpaceAccess" value="<?= Req::getParam("_idSpaceAccess") ?>">
		<?php } ?>
		<button type="submit"><?= Txt::trad("connect") ?></button>
		<!--OPTIONS-->
		<div class="vConnectOptions">
			<div>
				<?php if(!empty($usersInscription)){ ?><a onclick="lightboxOpen('?action=usersInscription')" title="<?= Txt::trad("usersInscriptionInfo") ?>"><img src="app/img/check.png">&nbsp;<?= Txt::trad("usersInscription") ?></a><?php } ?>
			</div>
			<div>
				<input type="checkbox" name="rememberMe" value="1" id="boxRememberMe" checked>
				<label for="boxRememberMe" title="<?= Txt::trad("connectAutoInfo") ?>"><?= Txt::trad("connectAuto") ?> !</label>
				<a class="vForgotPassword" onclick="lightboxOpen('?action=forgotPassword')" title="<?= Txt::trad("forgotPasswordInfo") ?>"><?= Txt::trad("forgotPassword") ?></a>
			</div>
		</div>
	</form>

	<!--BLOCK "PUBLIC"-->
	<?php if(!empty($objPublicSpaces)){ ?>
		<div class="sBlock vBlockPublic">
			<img src="app/img/publicBig.png" class="vBlockIcon">
			<div class="vPublic">
				<div><?= Txt::trad("guestAccess") ?></div>
				<div>
				<?php foreach($objPublicSpaces as $tmpSpace){ ?>
					<div class="vPublicSpace"><a href="javascript:publicSpaceAccess('<?= $tmpSpace->_id ?>','<?= empty($tmpSpace->password)?0:1 ?>');"><img src="app/img/arrowRight.png">&nbsp; <?= $tmpSpace->name ?></a></div>
				<?php } ?>
				</div>
			</div>
		</div>
	<?php } ?>
</div>