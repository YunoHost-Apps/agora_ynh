<script type="text/javascript">
////	Resize
lightboxWidth(500);

////	Contrôle du formulaire
function formControl()
{
	if(!isMail($("[name='mail']").val())){
		notify("<?= Txt::trad("mailInvalid") ?>");
		return false;
	}
}
</script>

<style>
form			{text-align:center;padding:0px;margin:0px;}
[name='mail']	{width:200px;}
</style>

<div class="lightboxTitle"><?= Txt::trad("FORGOTPASS_preciseMail") ?></div>

<form action="index.php" method="post" OnSubmit="return formControl();" class="lightboxContent">
	<input type="text" name="mail">
	<?= Txt::formValidate("send",false) ?>
</form>