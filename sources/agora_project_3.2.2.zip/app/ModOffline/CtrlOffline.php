<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Controleur des pages "Offline"
 */
class CtrlOffline extends Ctrl
{
	const moduleName="offline";

	/*
	 * ACTION PAR DEFAUT : connexion à l'espace
	 */
	public static function actionDefault()
	{
		static::$isMainPage=true;
		//Réinitialise le password? confirme une invitation?
		MdlUser::reinitPassword();
		MdlUser::confirmInvitation();
		//Affiche la page
		$vDatas["usersInscription"]=Db::getVal("select count(*) from ap_space where usersInscription=1");
		$vDatas["objPublicSpaces"]=Db::getObjTab("space", "select * from ap_space where public=1 order by name");
		//Login par défaut
		if(Req::isParam("login"))				{$vDatas["defaultLogin"]=Req::getParam("login");}
		elseif(!empty($_COOKIE["AGORAP_LOG"]))	{$vDatas["defaultLogin"]=$_COOKIE["AGORAP_LOG"];}
		else									{$vDatas["defaultLogin"]=null;}
		static::displayPage("VueConnection.php",$vDatas);
	}

	/*
	 * ACTION : Renvoie le mot de passe oublié
	 */
	public static function actionForgotPassword()
	{
		//Formulaire validé
		if(Req::isParam("formValidate"))
		{
			$userId=Db::getVal("SELECT _id FROM ap_user WHERE mail=".Db::format(Req::getParam("mail"))." AND mail!='' AND mail is not null");
			if(empty($userId))    {self::addNotif("FORGOTPASS_noMail");}
			else{
				CtrlUser::sendMailCoordonnates(Ctrl::getObj("user",$userId), "sendCoords");
				static::lightboxClose(false);
			}
		}
		//Affiche le formulaire
		static::displayPage("VueForgotPassword.php");
	}

	/*
	 * ACTION : Inscription d'utilisateur
	 */
	public static function actionUsersInscription()
	{
		//Nb max d'utilisateurs dépassé?
		if(MdlUser::quotaExceeded()==false)	{Ctrl::lightboxClose(false);}
		//Formulaire validé
		if(Req::isParam("formValidate")){
			Db::query("INSERT INTO ap_userInscription SET _idSpace=".Db::formatParam("_idSpace").", name=".Db::formatParam("name").", firstName=".Db::formatParam("firstName").", mail=".Db::formatParam("mail").", password=".Db::formatParam("password").", message=".Db::formatParam("message").", date=".Db::dateNow());
			self::addNotif("usersInscriptionRecorded","success");
			static::lightboxClose(false);
		}
		//Affiche le formulaire
		$vDatas["objSpacesInscription"]=Db::getObjTab("space", "select * from ap_space where usersInscription=1");
		static::displayPage("VueUsersInscription.php",$vDatas);
	}

	/*
	 * ACTION : Install de l'Agora
	 */
	public static function actionInstall()
	{
		//init & Install authorisé? & chmod sur le dossier DATAS
		static::$isMainPage=true;
		self::installControl();
		////	Formulaire validé
		if(Req::isParam("formValidate"))
		{
			////	MODIF DU FICHIER DE CONFIG
			File::setChmod(PATH_DATAS);
			$AGORA_SALT=Txt::idUniq(8);
			$spaceDiskLimit=File::getBytesSize(Req::getParam("spaceDiskLimit")."go");
			File::updateConfigFile(["AGORA_SALT"=>$AGORA_SALT, "db_host"=>Req::getParam("db_host"), "db_login"=>Req::getParam("db_login"), "db_password"=>Req::getParam("db_password"), "db_name"=>Req::getParam("db_name"), "limite_nb_users"=>"10000", "limite_espace_disque"=>$spaceDiskLimit]);

			////	CREE LA BASE DE DONNEES (AVEC CONTROLES D'ACCES)
			$controlConnect=self::installSgbdControl(Req::getParam("db_host"), Req::getParam("db_login"), Req::getParam("db_password"), Req::getParam("db_name"));
			if($controlConnect!=true && $controlConnect!="errorConnectDb")	{self::noAccessExit();}
			elseif($controlConnect=="errorConnectDb"){
				$objPDO=new PDO("mysql:host=".Req::getParam("db_host"),Req::getParam("db_login"),Req::getParam("db_password"));
				$objPDO->query("CREATE DATABASE `".Req::getParam("db_name")."` DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;");
			}
			//Se connecte au sgbd & Importe la Bdd!
			$objPDO=new PDO("mysql:host=".Req::getParam("db_host").";dbname=".Req::getParam("db_name").";charset=utf8;", Req::getParam("db_login"), Req::getParam("db_password"));
			$dbFile="app/ModOffline/db.sql";
			$handle=fopen($dbFile,"r");
			foreach(explode(";",fread($handle,filesize($dbFile))) as $tmpQuery){
				if(strlen($tmpQuery)>5)  {$objPDO->query($tmpQuery);}
			}

			////	INITIALISE LES TABLES DE LA BDD  (ne pas utiliser le "Db::format()", sinon instancie un "new PDO()"!)
/***********/
			$objPDO->query("UPDATE ap_agora SET  name=".$objPDO->quote(Req::getParam("spaceName")).", description=".$objPDO->quote(Txt::trad("INSTALL_spaceDescription")).", timezone=".$objPDO->quote(Req::getParam("timezone")).", lang=".$objPDO->quote(Req::getParam("lang")).", dateUpdateDb=".Db::dateNow().", version_agora='".VERSION_AGORA."'");
			$objPDO->query("UPDATE ap_space SET  name=".$objPDO->quote(Req::getParam("spaceName")).", description=".$objPDO->quote(Req::getParam("spaceDescription")).", public=".(Req::getParam("spacePublic")==1?"'1'":"NULL")."  WHERE _id=1");
			//User principal (admin général)
			$password=MdlUser::passwordSha1(Req::getParam("adminPassword"),$AGORA_SALT);
			$objPDO->query("UPDATE ap_user SET  login=".$objPDO->quote(Req::getParam("adminLogin")).", password=".$objPDO->quote($password).", name=".$objPDO->quote(Req::getParam("adminName")).", firstName=".$objPDO->quote(Req::getParam("adminFirstName")).", mail=".$objPDO->quote(Req::getParam("adminMail"))."  WHERE _id=1");
			//Update la première actualité		////!!!!!!!!!!!!!FAIRE TRADUCTIONS
			$newsDescription="<div style='font-size:150%;margin:30px 0px 30px 0px;font-weight:bold;' align='center'>Bienvenue sur votre nouvel espace !</div><a href=\"javascript:lightboxOpen('?ctrl=user&action=SendInvitation')\"><i><b>Cliquez ici pour inviter des personnes à vous y rejoindre</b></i></a>";
			$objPDO->query("UPDATE ap_dashboardNews SET  description=".$objPDO->quote($newsDescription).", dateCrea=".Db::dateNow()."  WHERE _id=1");
			//Renomme l'agenda de l'espace
			$objPDO->query("UPDATE ap_calendar SET  title=".$objPDO->quote(Req::getParam("spaceName"))."  WHERE _id=1 AND type='ressource'");
/***********/

			//REDIRECTION
			self::addNotif("INSTALL_installOk");
			self::redir("?disconnect=1");
		}
		//Charge la langue & Affiche le formulaire
		Txt::loadTrads(Req::getParam("tradInstall"));
		static::displayPage("VueInstall.php");
	}

	/*
	 * AJAX : Vérifie une connexion au SGBD
	 */
	public static function actionInstallVerifMysql()
	{
		//Install authorisé?
		self::installControl();
		//Vérif la connexion à Mysql, Vérif la connexion à la BDD, et Vérif si la BDD contient déjà l'appli
		echo self::installSgbdControl(Req::getParam("db_host"),Req::getParam("db_login"),Req::getParam("db_password"),Req::getParam("db_name"));
	}

	/*
	 * Vérifie la version du parser PHP et si l'appli n'est pas déjà installé en Bdd
	 */
	public static function installControl()
	{
		Req::verifPhpVersion();
		if(defined("db_host") && defined("db_login") && defined("db_password") && defined("db_name") && self::installSgbdControl(db_host,db_login,db_password,db_name)==="errorAppliInstalled")
			{self::noAccessExit();}
	}

	/*
	 * Verifie une connexion SGBD
	 */
	public static function installSgbdControl($db_host, $db_login, $db_password, $db_name)
	{
		//Connection PDO
		try{
			//Vérif la connexion à la bdd
			$objPDO=new PDO("mysql:host=".$db_host.";dbname=".$db_name.";charset=utf8;", $db_login, $db_password, array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
			//Vérif si l'appli est déjà installé
			$result=$objPDO->query("SHOW TABLES FROM `".$db_name."` WHERE `Tables_in_".$db_name."` LIKE 'gt_%' OR `Tables_in_".$db_name."` LIKE 'ap_%'");
			if(count($result->fetchAll(PDO::FETCH_COLUMN,0))>0)  {return "errorAppliInstalled";}//Erreur: L'application est déjà installée
		}
		//Erreur de connexion à Mysql/bdd
		catch(PDOException $exception){
			if(preg_match("/Unknown database/i",$exception->getMessage()))	{return "errorConnectDb";}				//Erreur: Database inconnue
			elseif(preg_match("/Access denied/i",$exception->getMessage()))	{return "errorConnectIdentification";}	//Erreur: Pas d'identification de l'user Mysql
			else															{return "errorConnectSGBD";}			//Erreur: Problemme d'accès au GSBD (erreur de host?)
		}
		//Pas d'erreur
		return true;
	}

	/*
	 * AJAX : Test le password de connexion à un espace public
	 */
	public static function actionPublicSpaceAccess()
	{
		$password=Db::getVal("SELECT count(*) FROM ap_space WHERE _id=".Db::formatParam("_idSpace")." AND BINARY password=".Db::formatParam("password"));//"BINARY"=>case sensitive
		echo (empty($password)) ? "false" : "true";
	}
}