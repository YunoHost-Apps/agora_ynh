<script type="text/javascript">
////	Resize
lightboxWidth(430);

////	Contrôle du formulaire
function formControl()
{
	// Certains champs sont obligatoire
	if($("input[name='name']").isEmpty())		{notify("<?= Txt::trad("USER_specifyName"); ?>");  return false;}
	if($("input[name='firstName']").isEmpty())	{notify("<?= Txt::trad("USER_specifyFirstName"); ?>");  return false;}
	// Verif mail & verif Ajax s'il existe déjà (car utilisé comme identifiant..)
	if($("input[name='mail']").isEmpty() || !isMail($("input[name='mail']").val()))   {notify("<?= Txt::trad("mailInvalid"); ?>");  return false;}
	var ajaxUrl="?ctrl=misc&action=UserAccountExist&mail="+encodeURIComponent($("input[name='mail']").val());
	var ajaxResult=$.ajax({url:ajaxUrl,async:false}).responseText;//Attend la réponse Ajax pour passer à la suite (async:false)
	if(find("true",ajaxResult))   {notify("<?= Txt::trad("USER_mailPresentYet"); ?>");  return false;}
	// Verif mot de passe
	if($("input[name='password']").isEmpty() || $("input[name='password']").val()!=$("input[name='passwordVerif']").val())   {notify("<?= Txt::trad("USER_specifyPassword"); ?>");  return false;}
	// Vérif du captcha
	if(captchaControl()==false)    {return false;}
}
</script>

<style>
select, input, textarea	{margin-bottom:15px !important;}
input, textarea			{width:100% !important;}
.formValidate			{margin-top:15px;}
</style>


<div class="lightboxTitle"><?= ucfirst(Txt::trad("usersInscriptionSpace")) ?></div>

<form action="index.php" method="post" OnSubmit="return formControl();" id="userInscription" class="lightboxContent">
	<select name="_idSpace">
		<?php foreach($objSpacesInscription as $tmpSpace){ ?>
		<option value="<?= $tmpSpace->_id ?>" title="<?= $tmpSpace->description ?>"><?= $tmpSpace->name ?></option>
		<?php } ?>
	</select><br>
	<input type="text" name="name" placeholder="<?= Txt::trad("name"); ?>"><br>
	<input type="text" name="firstName" placeholder="<?= Txt::trad("firstName"); ?>"><br>
	<input type="text" name="mail" placeholder="<?= Txt::trad("mail"); ?>"><br>
	<input type="password" name="password" class="editInputPassword" placeholder="<?= Txt::trad("password"); ?>"><br>
	<input type="password" name="passwordVerif" class="editInputPassword" placeholder="<?= Txt::trad("passwordVerif"); ?>"><br>
	<textarea name="message" placeholder="<?= Txt::trad("comment"); ?>"><?= Req::getParam("message") ?></textarea><br>
	<?= CtrlMisc::menuCaptcha() ?>
	<?= Txt::formValidate() ?>
</form>