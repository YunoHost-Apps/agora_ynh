<script>
$(function(){
	//Active/désactive les notifications des messages par mail
	<?php if($displayForum=="subjectMessages"){ ?>
		$("#notifyLastMessage").click(function(){
			$.ajax("?ctrl=forum&action=notifyLastMessage&targetObjId=<?= $curSubject->_targetObjId ?>").done(function(ajaxResult){
				if(ajaxResult=="addUser")	{$("#notifyLastMessage").addClass("vNotifyLastMessageSelect");}
				else						{$("#notifyLastMessage").removeClass("vNotifyLastMessageSelect");}
			});
		});
		//Selectionne "Me notifier par email"?
		if("<?= (int)$curSubject->curUserNotifyLastMessage() ?>"=="1")  {$("#notifyLastMessage").addClass("vNotifyLastMessageSelect");}
	<?php } ?>
});
</script>

<style>
/*Theme & Sujet & Message*/
.pageModMenuContainer{<?= ($pageFullOrCenter=="pageCenter") ? "display:none" : null ?>}
.objLines .objContainer			{height:70px; padding:0px;}/*surcharge*/
.objContent>div					{padding:7px;}/*surcharge*/
.objContent>div:last-child		{padding-right:35px;}/*surcharge*/
.objContent hr					{background:linear-gradient(90deg,#e9e9e9,transparent) !important; margin:0px;}
/*Themes*/
.vTheme>div						{line-height:20px;}
.vTheme>div:last-child			{width:250px; white-space:nowrap; text-align:right; padding-right:5px;}
.vThemeTitle					{text-transform:uppercase;}
.vThemeDescription				{margin-top:7px; font-weight:normal;}
/*Sujet & Message*/
.vSubjMessDescription			{margin-top:10px; font-weight:normal;}
.vSubjMessDetails, .vSubjMessAutor	{font-size:95%; line-height:20px; text-align:right;}
.vSubjMessDetails				{width:280px;}
.vSubjMessAutor					{width:250px;}
.vSubjMessAutor>div				{display:inline-block; white-space:nowrap; line-height:20px;}
.vSubjMessAutor>div img			{max-width:40px; max-height:40px; border-radius:50%;}
.vSubjMessQuote					{margin-right:8px;}
.vSubjectContainer				{margin-bottom:10px !important; height:auto !important; box-shadow:3px 3px 6px #800;}
.vMessageContainer				{height:auto !important;}
.vSubjectContainer .objContent, .vMessageContainer .objContent	{cursor:default !important;}
.vMessageQuoted					{overflow:auto; max-height:100px; background:#eee; margin-top:15px; margin-bottom:10px; padding:5px; border-radius:5px; font-style:italic;}
.vMessageQuoted [src*='quote']	{float:right; opacity:0.5; height:20px;}
.vNotifyLastMessageSelect		{color:#a00; font-style:italic;}

/*RESPONSIVE*/
@media screen and (max-width:1024px){
	.objLines .objContainer		{height:auto !important;}/*surcharge*/
	.objContent					{display:block; padding:7px !important;}/*surcharge*/
	.objContent>div				{display:block; padding:2px !important; width:100% !important;}/*surcharge*/
	.objContent>div:last-child	{margin-top:5px;}/*surcharge*/
	.vSubjMessDetails>div		{display:inline-block;}
	.vSubjMessAutor>div			{line-height:15px;}
	.vSubjMessAutor>div img		{max-width:30px; max-height:30px;}
}
</style>

<div class="<?= $pageFullOrCenter ?>">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
		<?php
		////	MENU DES SUJETS
		if($displayForum=="subjects"){
			$tradSubjects=($subjectsTotalNb>1) ? "FORUM_sujets" : "FORUM_sujet";
			if(MdlForumSubject::addRight())  {echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".MdlForumSubject::getUrlNew()."&_idTheme=".Req::getParam("_idTheme")."');\"><div class='menuIcon'><img src='app/img/plus.png'></div><div>".Txt::trad("FORUM_ajouter_sujet")."</div></div><hr>";}
			echo MdlForumSubject::menuSort();
			echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/info.png'></div><div>".$subjectsTotalNb." ".Txt::trad($tradSubjects)."</div></div>";
		}
		////	EDIT LES THEMES
		if(!empty($editTheme))
			{echo "<div class='menuLine sLink' onclick=\"lightboxOpen('?ctrl=forum&action=ForumThemeEdit');\"><div class='menuIcon'><img src='app/img/category.png'></div><div>".Txt::trad("FORUM_themes_gestion")."</div></div>";}
		////	MENU D'UN SUJET ET SES MESSAGES
		if($displayForum=="subjectMessages"){
			if(Ctrl::$curContainer->editContentRight())	{echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".MdlForumMessage::getUrlNew()."');\"><div class='menuIcon'><img src='app/img/plus.png'></div><div>".Txt::trad("FORUM_ajouter_message")."</div></div>";}
			if(!empty(Ctrl::$curUser->mail))			{echo "<div class='menuLine sLink' id='notifyLastMessage' title=\"".Txt::trad("FORUM_notifyLastPostInfo")."\"><div class='menuIcon'><img src='app/img/mail.png'></div><div>".Txt::trad("FORUM_notifyLastPost")."</div></div>";}
			echo "<hr>".MdlForumMessage::menuSort()."<div class='menuLine'><div class='menuIcon'><img src='app/img/info.png'></div><div>".$messagesNb." ".Txt::trad($messagesNb>1?"FORUM_messages":"FORUM_message")."</div></div>";
		}
		?>
		</div>
	</div>

	<div class="objLines <?= ($displayForum=="theme" && empty($editTheme))?"pageCenterContent":"pageFullContent" ?>">
		<?php
		////	LISTE DES THEMES
		if($displayForum=="theme")
		{
			foreach($themeList as $tmpTheme)
			{
				//Init
				$displayDescription=(!empty($tmpTheme->description))  ?  "<div class='vThemeDescription'>".$tmpTheme->description."</div>":  null;
				$subjectsNb=(!empty($tmpTheme->subjectsNb))  ?  "<div>".$tmpTheme->subjectsNb." ".Txt::trad($tmpTheme->subjectsNb>1?"FORUM_sujets":"FORUM_sujet")." - ".Txt::trad("FORUM_lastPost")." : ".$tmpTheme->subjectLast->displayDate()."</div>"  :  null;
				$messagesNb=(!empty($tmpTheme->messagesNb))  ?  "<div>".$tmpTheme->messagesNb." ".Txt::trad($tmpTheme->messagesNb>1?"FORUM_messages":"FORUM_message")." - ".Txt::trad("FORUM_lastPost")."  : ".$tmpTheme->messageLast->displayDate()."</div>"  :  null;
				//Affichage
				echo "<div class='objContainer sBlock' onClick=\"redir('?ctrl=forum&_idTheme=".$tmpTheme->idThemeUrl."')\">
						<div class='vTheme objContent sLink'>
							<div><div class='vThemeTitle'>".$tmpTheme->display()."</div>".$displayDescription."</div>
							<div>".$subjectsNb.$messagesNb."</div>
						</div>
					</div>";
			}
		}

		////	PATH DU FORUM (ACCUEIL FORUM > THEME COURANT > SUBJET COURANT)
		if(!empty($curTheme) || !empty($curSubject)){
			$curThemeLink=(!empty($curTheme))  ?  "<a href=\"?ctrl=forum&_idTheme=".$curTheme->idThemeUrl."\">".Txt::reduce($curTheme->display(),50)."</a>"  :  null;
			echo "<div class='forumPath sBlock'><a href='?ctrl=forum'><img src='app/img/forum/icon.png'> ".Txt::trad("FORUM_accueil_forum")."</a> &nbsp; ".$curThemeLink."</div>";
		}

		////	LISTE DES SUJETS
		if($displayForum=="subjects")
		{
			foreach($subjectsDisplayed as $tmpSubject)
			{
				//Init
				$tmpSubjectSelect=($tmpSubject->curUserLastMessageIsNew())  ?  "class='sLinkSelect'"  :  null;
				$displayedTitle=(!empty($tmpSubject->title))  ?  $tmpSubject->title."<hr>"  :  null;
				$messagesTrad=($tmpSubject->messagesNb>1)  ?  Txt::trad("FORUM_messages")  :  Txt::trad("FORUM_message");
				$messageLastPost=(!empty($tmpSubject->messagesNb))  ?  " - ".Txt::trad("FORUM_lastPost")." : ".$tmpSubject->messageLast->displayDate()  :  null;
				//Affichage
				echo $tmpSubject->divContainer("objAlternate").$tmpSubject->contextMenu().
					"<div class='vSubject objContent sLink' onclick=\"redir('?ctrl=forum&targetObjId=".$tmpSubject->_targetObjId."')\" title=\"".Txt::trad("FORUM_voir_sujet")."\">
						<div ".$tmpSubjectSelect.">".$displayedTitle."<div class='vSubjMessDescription'>".Txt::reduce(strip_tags($tmpSubject->description),250)."</div></div>
						<div class='vSubjMessDetails'>
							<div>".$tmpSubject->messagesNb." ".$messagesTrad." ".$messageLastPost."</div>
							<div>".$tmpSubject->displayAutor().", ".$tmpSubject->displayDate()."</div>
						</div>
					</div>
				</div>";
			}
			////	AUCUN SUJET  /  MENU DE PAGINATION
			if(empty($subjectsDisplayed))  {echo "<div class='pageEmptyContent'>".Txt::trad("FORUM_noSubject")."</div>";}
			echo MdlForumSubject::menuPagination($subjectsTotalNb,"_idTheme");
		}

		////	SUJET SPECIFIQUE & MESSAGES ASSOCIES
		if($displayForum=="subjectMessages")
		{
			////SUJET COURANT
			$displayedTitle=(!empty($curSubject->title))  ?  $curSubject->title."<hr>"  :  null;
			echo $curSubject->divContainer("vSubjectContainer").$curSubject->contextMenu().
					"<div class='vSubjectCurrent objContent'>
						<div>".$displayedTitle."<div class='vSubjMessDescription'>".$curSubject->description.$curSubject->menuAttachedFiles()."</div></div>
						<div class='vSubjMessAutor'>
							<div>".$curSubject->displayAutor()."<br>".$curSubject->displayDate(true,"full")."</div>
							<div>".CtrlForum::autorImg($curSubject->_idUser)."</div>
						</div>
					</div>
				</div>";
			////MESSAGES DU SUJET
			foreach($messagesList as $tmpMessage)
			{
				//Init
				$displayedTitle=(!empty($tmpMessage->title))  ?  $tmpMessage->title."<hr>"  :  null;
				$quoteMessageLink=($curSubject->editContentRight())  ?  "<a href=\"javascript:lightboxOpen('".MdlForumMessage::getUrlNew()."&_idMessageParent=".$tmpMessage->_id."')\" title=\"".Txt::trad("FORUM_quoteMessage")."\" class='vSubjMessQuote'><img src='app/img/forum/quote.png'></a>"  :  null;
				$quotedMessage=(!empty($tmpMessage->_idMessageParent))  ?  "<div class='vMessageQuoted'><img src='app/img/forum/quote.png'>".Ctrl::getObj($tmpMessage::objectType,$tmpMessage->_idMessageParent)->title."<br>".Ctrl::getObj($tmpMessage::objectType,$tmpMessage->_idMessageParent)->description."</div>"  :  null;
				//Affichage
				echo $tmpMessage->divContainer("vMessageContainer objAlternate","data-treeLevel='".$tmpMessage->treeLevel."'").$tmpMessage->contextMenu().
						"<div class='vMessage objContent'>
							<div>".$quoteMessageLink.$displayedTitle."<div class='vSubjMessDescription'>".$quotedMessage.$tmpMessage->description.$tmpMessage->menuAttachedFiles()."</div></div>
							<div class='vSubjMessAutor'>
								<div>".$tmpMessage->displayAutor()."<br>".$tmpMessage->displayDate(true,"full")."</div>
								<div>".CtrlForum::autorImg($tmpMessage->_idUser)."</div>
							</div>
						</div>
					</div>";
			}
			////AUCUN SUJET
			if(empty($messagesNb))  {echo "<div class='pageEmptyContent'>".Txt::trad("FORUM_noMessage")."</div>";}
		}
		?>
	</div>
</div>