<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Modele des sujets du forum
 */
class MdlForumSubject extends MdlObject
{
	const moduleName="forum";
	const objectType="forumSubject";
	const dbTable="ap_forumSubject";
	const MdlObjectContent="MdlForumMessage";
	const htmlEditorField="description";
	const nbObjectsByPage=30;
	public static $requiredFields=array("description");
	public static $searchFields=array("title","description");
	public static $sortFields=array("dateLastMessage@@desc","dateLastMessage@@asc","dateCrea@@desc","dateCrea@@asc","dateModif@@desc","dateModif@@asc","_idUser@@asc","_idUser@@desc","title@@asc","title@@desc","description@@asc","description@@desc");

	/*
	 * Liste des messages d'un sujet
	 */
	public function getMessages($orderMode="line")
	{
		$sqlSort=($orderMode=="line")  ?  MdlForumMessage::sqlSort($this)  :  "ORDER BY dateCrea DESC";
		return Db::getObjTab("forumMessage", "SELECT * FROM ap_forumMessage WHERE _idContainer=".$this->_id." ".$sqlSort);
	}

	/*
	 * L'User courant recoit-il des notifications à l'ajout d'un nouveau message?
	 */
	public function curUserNotifyLastMessage()
	{
		return in_array(Ctrl::$curUser->_id,Txt::txt2tab($this->usersNotifyLastMessage));
	}

	/*
	 * L'User courant a-t-il consulté le dernier message?
	 */
	public function curUserLastMessageIsNew()
	{
		return !in_array(Ctrl::$curUser->_id,Txt::txt2tab($this->usersConsultLastMessage));
	}
	
	/*
	 * L'User courant a consulté le dernier message : MAJ DB
	 */
	public function curUserConsultLastMessageMaj()
	{
		if($this->curUserLastMessageIsNew()){
			$usersConsultLastMessage=array_merge([Ctrl::$curUser->_id], Txt::txt2tab($this->usersConsultLastMessage));
			Db::query("UPDATE ap_forumSubject SET usersConsultLastMessage=".Db::formatTab2txt($usersConsultLastMessage)." WHERE _id=".$this->_id);
		}
	}

	/*
	 * SURCHARGE : Droit d'ajouter un nouveau sujet
	 */
	public static function addRight()
	{
		return (Ctrl::$curUser->isAdminCurSpace() || (Ctrl::$curUser->isUser() && Ctrl::$curSpace->moduleOptionEnabled(self::moduleName,"ajout_sujet_admin")==false));
	}

	/*
	 * SURCHARGE : Url d'accès (dans un theme?)
	 */
	public function getUrl($display=null)
	{
		//Url simple / "container"
		if($display!="container")	{return parent::getUrl($display);}
		else{
			$urlBase="?ctrl=".static::moduleName;
			if(!empty($this->_idTheme))					{return $urlBase."&_idTheme=".$this->_idTheme;}//theme précis
			elseif(count(MdlForumTheme::getThemes())>0)	{return $urlBase."&_idTheme=undefinedTheme";}//theme "sans theme"
			else										{return $urlBase;}//accueil du forum
		}
	}
}