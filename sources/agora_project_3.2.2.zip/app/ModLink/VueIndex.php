<style>
.objBlocks .objContainer	{height:70px;}
.objLabelBg					{background-image:url(app/img/link/iconBg.png);}
.linkIcon					{float:left; padding:0px 8px 0px 0px;}
.linkAdress					{margin-top:5px; font-size:95%; font-weight:normal; color:#888;}
</style>

<div class="pageFull">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?= CtrlObject::folderTree() ?>
			<?php if(Ctrl::$curContainer->editContentRight()){ ?>
				<div class="menuLine sLink" onclick="lightboxOpen('<?= MdlLink::getUrlNew() ?>');"><div class="menuIcon"><img src="app/img/plus.png"></div><div><?= Txt::trad("LINK_ajouter_lien") ?></div></div>
				<?php if(Ctrl::$curContainer->addRight()){ ?><div class="menuLine sLink" onclick="lightboxOpen('?ctrl=object&action=FolderEdit&targetObjId=<?= Ctrl::$curContainer->getType()."&_idContainer=".Ctrl::$curContainer->_id ?>')"><div class="menuIcon"><img src="app/img/folderAdd.png"></div><div><?= Txt::trad("addFolder") ?></div></div><?php } ?>
				<hr>
			<?php } ?>
			<?= MdlLink::menuSelectObjects().MdlLink::menuDisplayMode().MdlLink::menuSort() ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/info.png"></div><div><?= Ctrl::$curContainer->folderContentDescription() ?></div></div>
		</div>
	</div>
	<div class="pageFullContent <?= (MdlLink::getDisplayMode()=="line"?"objLines":"objBlocks") ?>">
		<?php
		////	PATH & LISTE DES DOSSIERS
		echo CtrlObject::folderPath().$foldersList;
		////	LISTE DES LIENS
		foreach($linkList as $tmpLink){
			echo $tmpLink->divContainer().$tmpLink->contextMenu();
		?>
				<div class="objContent">
					<div class="objLabel objLabelBg">
						<a href="<?= $tmpLink->adress ?>" target="_blank">
							<img src="https://www.google.com/s2/favicons?domain=<?= $tmpLink->adress ?>" class="linkIcon">
							<?= !empty($tmpLink->description) ? "<div title=\"".$tmpLink->description."\">".Txt::reduce($tmpLink->description,80)."</div>" : null ?>
							<div class="linkAdress"><?= substr($tmpLink->adress,0,40) ?></div>
						</a>
					</div>
					<div class="objAutor"><?= $tmpLink->displayAutor() ?></div>
					<div class="objDate"><?= $tmpLink->displayDate(true,"date") ?></div>
				</div>
			</div>
		<?php } ?>
		<!--AUCUN CONTENU-->
		<?php if(empty($foldersList) && empty($linkList)){ ?><div class="pageEmptyContent"><?= Txt::trad("LINK_aucun_lien") ?></div><?php } ?>
	</div>
</div>