<script type="text/javascript">
lightboxWidth(600);//Resize
$(function(){
	//Masque le block des options?
	if($(".vTaskDetails2").html()=="")	{$(".vTaskDetails").hide();}
});
</script>

<style>
.vTaskDetails		{text-align:center;}
.percentBar			{margin:10px 15px 0px 0px;}/*Surcharge common.css*/
</style>

<div class="lightboxContent">
	<div class="lightboxObjTitle">
		<?php
		if($curObj->editRight())	{echo "<a href=\"javascript:lightboxOpen('".$curObj->getUrl("edit")."')\" class='lightboxObjEditIcon' title=\"".Txt::trad("modify")."\"><img src='app/img/edit.png'></a>";}
		echo $curObj->priority()." ".$curObj->title;
		?>
	</div>
	<?= !empty($curObj->description) ? "<hr>".$curObj->description : null ?>
	<div class="vTaskDetails">
		<hr><div class="vTaskDetails2"><?= $curObj->responsiblePersons(true).$curObj->budgetEngagedAvailable(true).$curObj->advancementHumanDayCharge(true).$curObj->dateBeginEnd(true) ?></div>
	</div>
	<?= $curObj->menuAttachedFiles("<hr>") ?>
</div>