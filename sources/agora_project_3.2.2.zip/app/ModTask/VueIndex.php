<script>
////	LARGEUR DE LA TIMELINE (GANTT)
$(window).on("resize load",function(){
	if($(".vTimelineBlock").exist()){
		$(".vTimelineBlock").css("display","none");
		$(".vTimelineBlock").outerWidth(Math.round($(".pageFullContent").width())).css("display","inline-block");
	}
});
</script>

<style>
.objBlocks .objContainer			{height:70px;}
.objLabelBg							{background-image:url(app/img/task/iconBg.png);}
.objBlocks .vObjTask .objDetails	{position:absolute; display:block; bottom:3px; right:3px;}
.objBlocks .vObjTask .objDetails img	{max-height:20px; margin-left:5px;}
.objLines .percentBar				{margin-left:10px;}
.vObjTask .objLabel a				{padding:5px;}

/*TIMELINE*/
.vTimelineBlock						{margin-top:30px; overflow-x:auto;}
.vTimelineBlock>table				{border-collapse:collapse;}
.vTimelineMonths, .vTimelineDays, .vTimelineTaskDays	{vertical-align:middle; width:18px; min-width:18px;}
.vTimelineMonths {min-width:100px!important;}
.vTimelineTitle						{padding:2px; white-space:nowrap; vertical-align:middle;}
.vTimelineTitle img[src*='edit']	{max-height:15px}
.vTimelineDays						{padding:2px;}
.vTimelineTaskDays					{padding:0px;}
.vTimelineDays						{font-weight:normal; font-size:85%;}
.vTimelineLeftBorder				{border-left:#ddd solid 1px;}
.vTimelineBlock .percentBar			{margin:0px;}/*surcharge*/
.vTimelineBlock .percentBarContent	{text-align:left; cursor:pointer;}
/*RESPONSIVE -> 400px!*/
@media screen and (max-width:400px){
	input[type=text], input[type=password], input[type=file], textarea, select, button	{height:30px; padding:3px;}
	.ui-datepicker-calendar .ui-state-default	{height:24px!important;}/*surcharge du datepicker*/
	.vTimelineMonths, .vTimelineDays, .vTimelineTaskDays	{width:14px; min-width:14px;}
	.vTimelineBlock .percentBar img		{display:none;}/*surcharge*/
}
</style>

<div class="pageFull">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?= CtrlObject::folderTree() ?>
			<?php if(Ctrl::$curContainer->editContentRight()){ ?>
				<div class="menuLine sLink" onclick="lightboxOpen('<?= MdlTask::getUrlNew() ?>');"><div class="menuIcon"><img src="app/img/plus.png"></div><div><?= Txt::trad("TASK_ajouter_tache") ?></div></div>
				<?php if(Ctrl::$curContainer->addRight()){ ?><div class="menuLine sLink" onclick="lightboxOpen('?ctrl=object&action=FolderEdit&targetObjId=<?= Ctrl::$curContainer->getType()."&_idContainer=".Ctrl::$curContainer->_id ?>')"><div class="menuIcon"><img src="app/img/folderAdd.png"></div><div><?= Txt::trad("addFolder") ?></div></div><?php } ?>
				<hr>
			<?php } ?>
			<!--FILTRE PAR PRIORITE-->
			<div class="menuLine sLink">
				<div class="menuIcon"><img src="app/img/task/priority<?= Req::getParam("filterPriority") ?>.png"></div>
				<div>
					<div id="vMenuPriority" class="contextMenu">
						<?php for($tmpPriority=0; $tmpPriority<=4; $tmpPriority++){
							if($tmpPriority==0)  {$tmpPriority=null;}
							echo "<div class='menuLine'>
									<div class='menuIcon'><img src='app/img/task/priority".$tmpPriority.".png'></div>
									<div><a onclick=\"redir('".Tool::getParamsUrl("filterPriority")."&filterPriority=".$tmpPriority."')\" ".($tmpPriority==Req::getParam("filterPriority")?"class='sLinkSelect'":null).">".(empty($tmpPriority)?Txt::trad("displayAll"):Txt::trad("TASK_priority".$tmpPriority))."</a></div>
								  </div>";
						} ?>
					</div>
					<span class="menuLaunch" for="vMenuPriority"><?= Txt::trad("TASK_priority")." ".(Req::getParam("filterPriority")>=1?Txt::trad("TASK_priority".Req::getParam("filterPriority")):null) ?></span>
				</div>
			</div>
			<?= MdlTask::menuSelectObjects().MdlTask::menuDisplayMode().MdlTask::menuSort() ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/info.png"></div><div><?= Ctrl::$curContainer->folderContentDescription() ?></div></div>
		</div>
	</div>
	<div class="pageFullContent <?= (MdlTask::getDisplayMode()=="line"?"objLines":"objBlocks") ?>">
		<!--CHEMIN DU DOSSIER & LISTE DES DOSSIERS-->
		<?= CtrlObject::folderPath().$foldersList ?>
		<!--LISTE DES TACHES-->
		<?php foreach($tasksList as $tmpTask){
			echo $tmpTask->divContainer().$tmpTask->contextMenu(); ?>
				<div class="objContentScroll">
					<div class="objContent vObjTask">
						<div class="objLabel objLabelBg"><a href="javascript:lightboxOpen('<?= $tmpTask->getUrl("vue") ?>')"><?= $tmpTask->priority()." ".$tmpTask->title ?></a></div>
						<div class="objDetails"><?= $tmpTask->responsiblePersons().$tmpTask->budgetEngagedAvailable().$tmpTask->advancementHumanDayCharge().$tmpTask->dateBeginEnd() ?></div>
						<div class="objAutor"><?= $tmpTask->displayAutor() ?></div>
						<div class="objDate"><?= $tmpTask->displayDate(true,"date") ?></div>
					</div>
				</div>
			</div>
		<?php } ?>
		<!--AUCUN CONTENU-->
		<?php if(empty($foldersList) && empty($tasksList)){ ?><div class="pageEmptyContent"><?= Txt::trad("TASK_aucune_tache") ?></div><?php } ?>

		<!--TIMELINE (GANTT)-->
		<?php if(!empty($timelineBegin)){ ?>
		<div class="sBlock vTimelineBlock objMain">
			<table>
			<?php
			//HEADER MOIS & JOURS
			$timelineHeaderMonths=$timelineHeaderDays=null;
			foreach($timelineDays as $tmpDay){
				if($tmpDay["newMonthLabel"])  {$timelineHeaderMonths.="<td colspan='".$tmpDay["newMonthColspan"]."' class='vTimelineMonths vTimelineLeftBorder'>".$tmpDay["newMonthLabel"]."</td>";}
				$timelineHeaderDays.="<td class='vTimelineDays ".$tmpDay["classBorderLeft"]."'>".$tmpDay["dayLabel"]."</td>";
			}
			echo "<tr><td class='vTimelineTitle'>&nbsp;</td>".$timelineHeaderMonths."</tr>
				  <tr><td class='vTimelineTitle'>&nbsp;</td>".$timelineHeaderDays."</tr>";
			//TIMELINE DE CHAQUE TACHE
			foreach($timelineTasks as $tmpTask)
			{
				$taskDateBegin=date("Y-m-d",$tmpTask->timeBegin);
				$tmpTaskCells="";
				foreach($timelineDays as $tmpDay){//Affiche les jours de la timeline (cellule du jour || cellule de la tache si le 1er jour de la tache || jour précédant la tache OU jour suivant la tache)
					$isTaskDateBegin=($taskDateBegin==$tmpDay["curDate"]) ? true : false;
					if($isTaskDateBegin==true || $tmpDay["timeBegin"]<$tmpTask->timeBegin || $tmpTask->timeEnd<$tmpDay["timeBegin"])
						{$tmpTaskCells.="<td class=\"vTimelineTaskDays ".$tmpDay["classBorderLeft"]."\" ".($isTaskDateBegin==true?"colspan='".$tmpTask->timelineColspan."'":null)." >".($isTaskDateBegin==true?$tmpTask->timelineBeginEnd():"&nbsp;")."</td>";}
				}
				echo "<tr class='sTableRow'>
						<td class='vTimelineTitle'><a href=\"javascript:lightboxOpen('".$tmpTask->getUrl("vue")."')\" title=\"".$tmpTask->title."\">".Txt::reduce($tmpTask->title,(Tool::isMobile()?25:35))."</a></td>".
						$tmpTaskCells.
					 "</tr>";
			}
			?>
			</table>
		</div>
		<?php } ?>
	</div>
</div>