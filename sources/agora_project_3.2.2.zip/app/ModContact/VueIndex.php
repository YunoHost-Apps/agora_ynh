<script>
////	Création d'un user à partir d'un contact
function contactAddUser(targetObjId)
{
	if(confirm("<?= Txt::trad("CONTACT_creer_user_infos") ?>"))
		{redir("?ctrl=contact&action=contactAddUser&targetObjId="+targetObjId);}
}
</script>

<style>
.objBlocks .objContainer	{height:110px;}
</style>

<div class="pageFull">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?= CtrlObject::folderTree() ?>
			<?php if(Ctrl::$curContainer->editContentRight()){ ?>
				<div class="menuLine sLink" onclick="lightboxOpen('<?= MdlContact::getUrlNew() ?>');"><div class="menuIcon"><img src="app/img/plus.png"></div><div><?= Txt::trad("CONTACT_ajouter_contact") ?></div></div>
				<?php if(Ctrl::$curContainer->addRight()){ ?><div class="menuLine sLink" onclick="lightboxOpen('?ctrl=object&action=FolderEdit&targetObjId=<?= Ctrl::$curContainer->getType()."&_idContainer=".Ctrl::$curContainer->_id ?>')"><div class="menuIcon"><img src="app/img/folderAdd.png"></div><div><?= Txt::trad("addFolder") ?></div></div><?php } ?>
				<?php if(Ctrl::$curUser->isUser()){ ?><div class="menuLine sLink" onclick="lightboxOpen('?ctrl=contact&action=EditPersonsImportExport&targetObjId=<?= Ctrl::$curContainer->_targetObjId ?>');"><div class="menuIcon"><img src="app/img/dataImportExport.png"></div><div><?= Txt::trad("import")."/".Txt::trad("export")." ".Txt::trad("importExport_contact") ?></div></div><?php } ?>
				<hr>
			<?php } ?>
			<?= MdlContact::menuSelectObjects().MdlContact::menuDisplayMode().MdlContact::menuSort() ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/info.png"></div><div><?= Ctrl::$curContainer->folderContentDescription() ?></div></div>
		</div>
	</div>
	<div class="pageFullContent <?= (MdlContact::getDisplayMode()=="line"?"objLines":"objBlocks") ?>">
		<!--CHEMIN DU DOSSIER & LISTE DES DOSSIERS-->
		<?= CtrlObject::folderPath().Ctrl::$curContainer->folders() ?>
		<!--LISTE DES CONTACTS-->
		<?php foreach($contactList as $tmpContact){ ?>
		<?= $tmpContact->divContainer().$tmpContact->contextMenu(); ?>
			<div class="objContentScroll">
				<div class="objContent objPerson">
					<div class="objIcon"><?= $tmpContact->getImg(true) ?></div>
					<div class="objLabel">
						<a href="javascript:lightboxOpen('<?= $tmpContact->getUrl("vue") ?>');"><?= $tmpContact->display("all") ?></a>
						<div class="objPersonDetails"><?= $tmpContact->getFields(MdlContact::getDisplayMode()) ?></div>
					</div>
					<div class="objAutor"><?= $tmpContact->displayAutor() ?></div>
					<div class="objDate"><?= $tmpContact->displayDate(true,"date") ?></div>
				</div>
			</div>
		</div>
		<?php } ?>
		<!--AUCUN CONTENU-->
		<?php if(empty($foldersList) && empty($contactList)){ ?><div class="pageEmptyContent"><?= Txt::trad("CONTACT_aucun_contact") ?></div><?php } ?>
	</div>
</div>