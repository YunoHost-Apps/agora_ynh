<script type="text/javascript">
lightboxWidth(400);//Resize
</script>

<style>
.objVueBg	{background-image:url('app/img/contact/iconBg.png');}
</style>

<div class="lightboxContent objVueBg">
	<div class="lightboxObjTitle">
		<?php
		if($curObj->editRight())	{echo "<a href=\"javascript:lightboxOpen('".$curObj->getUrl("edit")."')\" class='lightboxObjEditIcon' title=\"".Txt::trad("modify")."\"><img src='app/img/edit.png'></a>";}
		echo $curObj->display("all");
		?>
	</div>
	<hr>
	<div class="personVueImg"><?= $curObj->getImg() ?></div>
	<div class="personVueFields"><?= $curObj->getFields("profile") ?></div>
	<?= $curObj->menuAttachedFiles("<hr>") ?>
</div>