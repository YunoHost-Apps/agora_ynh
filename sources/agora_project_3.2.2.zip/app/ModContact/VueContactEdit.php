<script type="text/javascript">
lightboxWidth(520);//Resize
</script>

<form action="index.php" method="post" onsubmit="return finalFormControl()" enctype="multipart/form-data" class="lightboxContent">
	
	<!--IMAGE-->
	<div class="objField">
		<div class="fieldLabel personVueImg"><?= $curObj->getImg() ?></div>
		<div><?= $curObj->displayImgMenu() ?></div>
	</div>
	<hr>

	<!--CHAMPS PRINCIPAUX & MENU COMMUN-->
	<?php echo $curObj->getFields("edit").$curObj->menuEdit() ?>
</form>