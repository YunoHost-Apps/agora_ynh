<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Controleur pour les opérations diverses
 */
class CtrlMisc extends Ctrl
{
	/* Inexistant dans ce contexte: pas un module à part entière*/
	public static function actionDefault(){}

	/*
	 * Surcharge de l'init du controleur principal
	 */
	public static function initCtrl()
	{
		//Pas d'initialisation complete du controleur (controle de connexion, selection d'espace, etc)
		static::$initCtrlFull=false;
		//Appel le constructeur parent
		parent::initCtrl();
	}

	/*
	 * AJAX : Livecounters (principal/messenger) et Messages du messenger
	 */
	public static function actionLivecounterUpdate()
	{
		//Init
		$result["messengerPulsateUsers"]=[];
		$result["livecounterMain"]=$result["livecounterMessenger"]=$result["messengerMessages"]="";
		//Messenger activé?
		if(self::$curUser->messengerEnabled())
		{
			////	NOUVELLE SESSION : INIT LE MESSENGER
			if(!isset($_SESSION["messengerUsersConnected"]))
			{
				////	Init les users connectés et leur dates d'affichage
				$_SESSION["messengerUsersConnected"]=$_SESSION["messengerUsersDisplayTime"]=[];
				////	Supprime les vieux messages du messenger (12h) & livecounters des users déconnectés (30sec)
				Db::query("DELETE FROM ap_userMessengerMessage WHERE date < ".intval(time()-MESSENGER_TIMEOUT));
				Db::query("DELETE FROM ap_userLivecouter WHERE date < ".intval(time()-LIVECOUNTER_TIMEOUT));
				////	 Users ayant autorisé l'accès à leur messenger : Gardé en session!
				$idsUsers=[0];//pseudo user
				foreach(self::$curUser->usersVisibles() as $tmpUser)  {$idsUsers[]=$tmpUser->_id;}
				$messengerUsersSql=Db::getCol("SELECT _id FROM ap_user WHERE _id!=".self::$curUser->_id." AND _id IN (".implode(",",$idsUsers).") AND _id IN (select _idUserMessenger from ap_userMessenger where allUsers=1 or _idUser=".self::$curUser->_id.")");
				$_SESSION["messengerUsersSql"]=implode(",", array_merge($messengerUsersSql,[0]));//ajoute le pseudo user + implode()
			}

			////	INSERT/UPDATE LE LIVECOUNTER EN BDD DE L'USER COURANT  ("editObjId" : modif en cours d'un objet?)
			$sqlValues="_idUser=".(int)self::$curUser->_id.", ipAdress=".Db::format($_SERVER["REMOTE_ADDR"]).", editObjId=".Db::formatParam("editObjId").", date=".Db::format(time());
			Db::query("INSERT INTO ap_userLivecouter SET ".$sqlValues." ON DUPLICATE KEY UPDATE ".$sqlValues);

			////	LIVECOUNTERS : LISTE DES USERS
			//Verif si d'autres users se sont connectés/deconnectés
			$messengerUsersConnectedOld=$_SESSION["messengerUsersConnected"];
			$_SESSION["messengerUsersConnected"]=Db::getObjTab("user", "SELECT DISTINCT T1.* FROM ap_user T1, ap_userLivecouter T2 WHERE T1._id=T2._idUser AND T1._id IN (".$_SESSION["messengerUsersSql"].") AND T2.date > ".intval(time()-LIVECOUNTER_TIMEOUT));
			$result["livercountersLoad"]=(Req::isParam("livecounterInit") || count($messengerUsersConnectedOld)!=count($_SESSION["messengerUsersConnected"]))  ?  true  :  false;//"true" même si ya plus aucun users!
			//Affichage des users connectés
			if($result["livercountersLoad"]==true && !empty($_SESSION["messengerUsersConnected"]))
			{
				foreach($_SESSION["messengerUsersConnected"] as $tmpUser)
				{
					//Affichage des livecounters
					$boxId="messengerUserBox".$tmpUser->_id;//Check des box : géré en JavaScript!
					$userLabel=$tmpUser->display("firstName");
					$userImg=$tmpUser->hasImgThumb()  ?  "<img src=\"".$tmpUser->pathImgThumb()."\" class='vMessengerUserImg'>"  :  null;
					$userTitle=$tmpUser->display()."<br>".Txt::trad("MESSENGER_connectedSince")." ".date("H:i",$tmpUser->lastConnection);
					$result["livecounterMain"].="<label onclick='messengerToggle(".$tmpUser->_id.");' title=\"".$userTitle."\" data-idUser=".$tmpUser->_id.">".$userImg.$userLabel."</label>";
					$result["livecounterMessenger"].="<div class='vMessengerUser'>
														<input type='checkbox' name='messengerPostUsers' value='".$tmpUser->_id."' id='".$boxId."'>
														<label for='".$boxId."' title=\"".Txt::trad("select")." ".$userTitle."\">".$userImg.$userLabel."</label>
													  </div>";
					//L'user vient de se connecter : ajoute au "messengerUsersDisplayTime" pour pas avoir de pulsate si ya des messages d'une ancienne session..
					if(!in_array($tmpUser->_id,$_SESSION["messengerUsersDisplayTime"]))  {$_SESSION["messengerUsersDisplayTime"][$tmpUser->_id]=time();}
				}
			}

			////	MESSAGES DU MESSENGER
			if(!empty($_SESSION["messengerUsersConnected"]))
			{
				//Verif si ya des nouveaux messages (date du + ancien messenger affiché comme point de départ). Ignore les messages de l'user courant: absent de $_SESSION["messengerUsersDisplayTime"]
				if(Req::isParam("livecounterInit")==false){
					$displayUserTimeLast=0;
					foreach($_SESSION["messengerUsersDisplayTime"] as $displayUserTime)    {  if(empty($displayUserTimeLast) || $displayUserTime<$displayUserTimeLast)  {$displayUserTimeLast=$displayUserTime;}  }
					$newMessages=Db::getVal("SELECT count(*) FROM ap_userMessengerMessage WHERE _idUsers LIKE '%@".self::$curUser->_id."@%' AND _idUser!='".self::$curUser->_id."' AND date>".(int)$displayUserTimeLast);
				}
				//Affichage des messages (Init OU nouveaux messages)
				if(Req::isParam("livecounterInit") || !empty($newMessages))
				{
					foreach(Db::getTab("SELECT * FROM ap_userMessengerMessage WHERE _idUsers LIKE '%@".self::$curUser->_id."@%' ORDER BY date asc") as $message)
					{
						//Init l'affichage
						$objAutor=self::getObj("user",$message["_idUser"]);
						$autorLabelImg=$objAutor->hasImgThumb()  ?  "<img src=\"".$objAutor->pathImgThumb()."\" class='vMessengerUserImg' title=\"".$objAutor->display("firstName")."\">"  :  $objAutor->display("firstName");
						$destList=Txt::txt2tab($message["_idUsers"]);
						$destMultiple=(count($destList)>2)  ?  "**"  :  null;
						$destLabel=Txt::trad("MESSENGER_sendAt")." ";
						foreach($destList as $userId)    {if($userId!=$objAutor->_id)  {$destLabel.=self::getObj("user",$userId)->display().", ";}}
						//Affichage du message
						$result["messengerMessages"].="<div class='vMessengerMessage' title=\"".trim($destLabel,", ")."\" data-idUsers=\"".$message["_idUsers"]."\">
														<div>".date("H:i",$message["date"])." ".$autorLabelImg.$destMultiple."</div>
														<div data-idAutor=\"".$message["_idUser"]."\">".$message["message"]."</div>
													   </div>";
						//"pulsate" l'auteur du message (message n'a pas encore vu & user connecté & user pas encore dans "messengerPulsateUsers")
						$messengerDisplayUserLastTime=(isset($_SESSION["messengerUsersDisplayTime"][$message["_idUser"]]))  ?  $_SESSION["messengerUsersDisplayTime"][$message["_idUser"]]  :  0;
						if($message["date"]>$messengerDisplayUserLastTime && !in_array($objAutor->_id,$result["messengerPulsateUsers"]) && array_key_exists($objAutor->_id,$_SESSION["messengerUsersConnected"]))
							{$result["messengerPulsateUsers"][]=$objAutor->_id;}
					}
				}
			}

			////	RETOURNE LE RÉSULTAT (format JSON)
			echo json_encode($result);
		}
	}

	/*
	 * AJAX : Update la date d'affichage du messenger d'un user (gardé en session)
	 */
	public static function actionMessengerUsersDisplayTime()
	{
		$_SESSION["messengerUsersDisplayTime"][Req::getParam("displayIdUser")]=time();
	}

	/*
	 * AJAX : Post d'un message sur le messenger
	 */
	public static function actionMessengerPostMessage()
	{
		if(self::$curUser->messengerEnabled())
		{
			$usersIds=Req::getParam("messengerPostUsers");
			$usersIds[]=self::$curUser->_id;
			Db::query("INSERT INTO ap_userMessengerMessage SET _idUser=".self::$curUser->_id.", _idUsers=".Db::formatTab2txt($usersIds).", message=".Db::formatParam("message").", date=".Db::format(time()));
			$_SESSION["messengerPostUsers"]=$usersIds;
		}
	}

	/*
	 * AJAX : Verifie si un compte utilisateur existe dejà, avec un mail en parametre (exple:"?ctrl=misc&action=UserAccountExist&mail=test%40test.test")
	 */
	public static function actionUserAccountExist()
	{
		if(Req::isParam("mail") && Db::getVal("SELECT count(*) FROM ap_user WHERE mail=".Db::formatParam("mail")." OR login=".Db::formatParam("mail"))>0)
			{echo "true";}
	}

	/*
	 * VUE : Menu "captcha"
	 */
	public static function menuCaptcha()
	{
		return self::getVue(Req::commonPath."Vue/VueCaptcha.php");
	}

	/*
	 *  ACTION : Affiche l'image d'un menu "captcha"
	 */
	public static function actionCaptchaImg()
	{
		//Init
		$width=120;
		$height=28;
		$fontSize=20;
		$caracNb=4;
		$colorLines=array("#DD6666","#66DD66","#6666DD","#DDDD66","#DD66DD","#66DDDD","#666666");
		$colorFonts=array("#880000","#008800","#000088","#888800","#880088","#008888","#000000");
		$caracs="ABCDEFGHKMNPQRSTUVWXYZ2345689";
		//Creation de l'image
		$image=imagecreatetruecolor($width, $height);
		imagefilledrectangle($image, 0, 0, $width-1, $height-1, self::captchaColor("#FFFFFF"));
		//Dessine 20 lines en background
		for($i=0; $i < 20; $i++){
			imageline($image, mt_rand(0,$width-1), mt_rand(0,$height-1), mt_rand(0,$width-1), mt_rand(0,$height-1), self::captchaColor($colorLines[mt_rand(0,count($colorLines)-1)]));
		}
		//Dessine le texte
		$_SESSION["captcha"]="";
		$y=($height/2) + ($fontSize/2);
		for($i=0; $i < $caracNb; $i++)
		{
			// pour chaque caractere : Police + couleur + angulation
			$captchaFont="app/misc/captchaFonts/".mt_rand(1,4).".ttf";
			$color=self::captchaColor($colorFonts[mt_rand(0,count($colorFonts)-1)]);
			$angle=mt_rand(-20,20);
			// sélectionne le caractère au hazard
			$char=substr($caracs, mt_rand(0,strlen($caracs) - 1), 1);
			$x=(intval(($width/$caracNb) * $i) + ($fontSize / 2)) - 4;
			$_SESSION["captcha"] .= $char;
			imagettftext($image, $fontSize, $angle, $x, $y, $color, $captchaFont, $char);
		}
		// Captcha dans Session + affichage de l'image
		header("Content-Type: image/jpeg");
		imagejpeg($image);
	}

	/*
	 * Couleur au format hexadecimal pour un Captcha
	 */
	protected static function captchaColor($colors)
	{
		return preg_match("/^#?([\dA-F]{6})$/i",$colors,$rgb) ? hexdec($rgb[1]) : false;
	}

	/*
	 * AJAX : controle d'un captcha
	 */
	public static function actionCaptchaControl()
	{
		echo (Req::isParam("captcha") && Req::getParam("captcha")==$_SESSION["captcha"]) ? "true" : "false";
	}

	/*
	 * VUE : Renvoie l'initialisation de l'editeur TinyMCE (doit déjà y avoir un chanmp "textarea")
	 */
	public static function initHtmlEditor($fieldName)
	{
		$vDatas["fieldName"]=$fieldName;
		return self::getVue(Req::commonPath."Vue/VueHtmlEditor.php",$vDatas);
	}

	/*
	 * VUE : Affiche des personnes sur une carte (contacts/utilisateurs)
	 */
	public static function actionPersonsMap()
	{
		static::displayPage(Req::commonPath."Vue/VuePersonsMap.php");
	}

	/*
	 * VUE : menuWallpaper
	 */
	public static function menuWallpaper($curWallpaper)
	{
		//Wallpapers disponibles
		$vDatas["wallpaperList"]=array();
		$filesList=array_merge(scandir(PATH_WALLPAPER_DEFAULT),scandir(PATH_WALLPAPER_CUSTOM));
		foreach($filesList as $tmpFile){
			if($tmpFile!='.' && $tmpFile!='..' && File::controlType("imageBrowser",$tmpFile)){
				$path=(is_file(PATH_WALLPAPER_DEFAULT.$tmpFile))  ?  PATH_WALLPAPER_DEFAULT.$tmpFile  :  PATH_WALLPAPER_CUSTOM.$tmpFile;
				$value=(is_file(PATH_WALLPAPER_DEFAULT.$tmpFile))  ?  WALLPAPER_DEFAULT_PREFIX.$tmpFile  :  $tmpFile;
				$nameRacine=str_replace(File::extension($tmpFile),null,$tmpFile);
				$vDatas["wallpaperList"][]=array("path"=>$path, "value"=>$value, "name"=>$tmpFile, "nameRacine"=>$nameRacine);
			}
		}
		//Affiche le menu
		$vDatas["wallpaperList"]=Tool::sortArray($vDatas["wallpaperList"],"nameRacine");
		$vDatas["curWallpaper"]=$curWallpaper;
		return self::getVue(Req::commonPath."Vue/VueMenuWallpaper.php",$vDatas);
	}

	/*
	 * PATH D'UN WALLPAPER  (cf. Ctrl::$curSpace->wallpaper && Ctrl::$agora->wallpaper)
	 */
	public static function pathWallpaper($fileName=null)
	{
		//Récup le chemin et vérifie la présence du fichier
		if(!empty($fileName)){
			$pathWallpaper=(strstr($fileName,WALLPAPER_DEFAULT_PREFIX)) ? PATH_WALLPAPER_DEFAULT.trim($fileName,WALLPAPER_DEFAULT_PREFIX) : PATH_WALLPAPER_CUSTOM.$fileName;
			if(is_file($pathWallpaper))		{return $pathWallpaper;}
		}
		//Sinon retourne le wallpaper par défaut
		return PATH_WALLPAPER_DEFAULT."1.jpg";
	}
}