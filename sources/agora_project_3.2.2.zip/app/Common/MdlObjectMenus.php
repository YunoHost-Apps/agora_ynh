<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Menus des Objects
 */
trait MdlObjectMenus
{
	/*
	 * Balise ouvrante du block de l'objet : contient l'Url d'édition (pour le DblClick)  et l'id du menu contextuel (Click droit)
	 */
	public function divContainer($addClass=null, $addAttribute=null)
	{
		$urlEdit=($this->editRight())  ?  "data-urlEdit=\"".$this->getUrl("edit")."\""  :  null;
		return  "<div class=\"objContainer sBlock ".$addClass."\" ".$addAttribute." id=\"".$this->contextMenuId("block",true)."\" for=\"".$this->contextMenuId("menu")."\" ".$urlEdit.">";
	}

	/*
	 * Identifiant du menu contextuel : pour le "block" ou pour le "menu"
	 */
	public function contextMenuId($for, $reloadUniqid=false)
	{
		if(static::$contextMenuUniqId===null || $reloadUniqid==true)  {static::$contextMenuUniqId=uniqid();}//Id du menu
		$prefix=($for=="block")  ?  "objBlock_"  :  "objContextMenu_";//Préfixe de l'identifiant
		return $prefix.$this->_targetObjId."_".static::$contextMenuUniqId;
	}

	/*
	 * VUE : Menu contextuel (édition, droit d'accès, etc)
	 * $options => "deleteLabel" / "specificOptions"
	 */
	public function contextMenu($options=null)
	{
		////	INIT  &  DIVERSES OPTIONS (exple: "array('actionJs'=>'?ctrl=file&action=monAction','iconSrc'=>'app/img/plus.png','label'=>'mon option spécifique','tooltip'=>'mon tooltip')")
		$vDatas["curObj"]=$this;
		$vDatas["inlineLauncher"]=(!empty($options["inlineLauncher"])) ? true : false;
		$vDatas["specificOptions"]=(!empty($options["specificOptions"])) ? $options["specificOptions"] : array();
		////	OBJET USER
		if(static::objectType=="user")
		{
			////	MODIFIER ELEMENT  &  MODIF MESSENGER
			if($this->editRight()){
				$vDatas["editLabel"]=Txt::trad("USER_modify");
				$vDatas["editMessengerObjUrl"]="?ctrl=user&action=UserEditMessenger&targetObjId=".$this->_targetObjId;
			}
			////	SUPPRESSION DE L'ESPACE OU DEFINITIVE!
			if($this->deleteFromCurSpaceRight())	{$vDatas["deleteFromCurSpaceConfirmRedir"]="confirmRedir('".Txt::trad("USER_confirmDeleteFromSpace",true)."', '?ctrl=user&action=deleteFromCurSpace&targetObjects[".static::objectType."]=".$this->_id."')";}
			if($this->deleteRight()){
				$vDatas["deleteConfirmRedir"]="confirmRedir('".Txt::trad("confirmDelete",true)."', '".$this->getUrl("delete")."')";
				$vDatas["deleteLabel"]=Txt::trad("USER_deleteDefinitely");
			}
			////	ESPACE DE L'UTILISATEUR
			if(Ctrl::$curUser->isAdminGeneral()){
				$vDatas["userSpaceList"]=Txt::trad("USER_spaceList")." : ";
				if(count($this->getSpaces())==0)	{$vDatas["userSpaceList"].=Txt::trad("USER_spaceNoAffectation");}
				else								{ foreach($this->getSpaces() as $tmpSpace)  {$vDatas["userSpaceList"].="<br>".$tmpSpace->name;} }
			}
		}
		////	OBJET LAMBDA
		else
		{
			////	MODIFIER ELEMENT  &  CHANGER DE DOSSIER  &  LOGS/HISTORIQUE (auteur/admin espace)
			if($this->editRight()){
				$vDatas["editLabel"]=(static::hasAccessRight==true && $this->isIndependant())  ?  Txt::trad("modifyAndAccesRight")  :  Txt::trad("modify");
				if($this::isInArbo())										{$vDatas["moveObjectUrl"]="?ctrl=object&action=FolderMove&targetObjId=".$this->containerObj()->_targetObjId."&targetObjects[".static::objectType."]=".$this->_id;}
				if($this->isAutor() || Ctrl::$curUser->isAdminCurSpace())	{$vDatas["logUrl"]="?ctrl=object&action=logs&targetObjId=".$this->_targetObjId;}
			}
			////	SUPPRIMER
			if($this->deleteRight()){
				$deleteAjaxParams=(static::isFolder==true)  ?  ", '?ctrl=object&action=SubFoldersDeleteControl&targetObjId=".$this->_targetObjId."', '".Txt::trad("confirmDeleteFolder",true)."'"  :  null;
				$vDatas["deleteConfirmRedir"]="confirmRedir('".addslashes(Txt::trad("confirmDelete"))."', '".$this->getUrl("delete")."' ".$deleteAjaxParams.")";
				if(!empty($options["confirmDeleteDouble"]))  {$vDatas["deleteConfirmRedir"]="if(confirm('".addslashes($options["confirmDeleteDouble"])."')) ".$vDatas["deleteConfirmRedir"];}/*Double confirmation!*/
				$vDatas["deleteLabel"]=(!empty($options["deleteLabel"])) ? $options["deleteLabel"] : Txt::trad("delete");
			}
			////	INFOS DES DROITS D'ACCESS (AUX ESPACES, USERS, ETC)
			if(static::hasAccessRight==true)
			{
				if(Ctrl::$curUser->isUser() && $this->isIndependant())
				{
					//Init
					$vDatas["isPersoAccess"]=true;
					$vDatas["affectLabels"]=$vDatas["affectTooltips"]=["1"=>null,"1.5"=>null,"2"=>null];
					//Libellé des affectations (& Icone d'element Perso?)
					foreach($this->getAffectations() as $tmpAffect){
						if($tmpAffect["targetType"]!="user" || Ctrl::$curUser->_id!=$tmpAffect["targetId"]) {$vDatas["isPersoAccess"]=false;}
						$vDatas["affectLabels"][$tmpAffect["accessRight"]].=$tmpAffect["label"]."<br>";
					}
					foreach($vDatas["affectLabels"] as $affectRight=>$affectLabel)	{$vDatas["affectLabels"][$affectRight]=trim($affectLabel,", ");}//Enlève dernières virgules pour les affectation d'users
					//Tooltip des droits d'accès
					$affectAutor=(static::isContainer())  ?  "<hr>".$this->tradObject("autorPrivilege")  :  null;//"Seul l'auteur peut modifier les droits d'accès.."
					if(!empty($vDatas["affectLabels"]["1"]))	{$vDatas["affectTooltips"]["1"]=Txt::trad("readInfos");}
					if(!empty($vDatas["affectLabels"]["1.5"]))	{$vDatas["affectTooltips"]["1.5"]=$this->tradObject("readLimitInfos").$affectAutor;}
					if(!empty($vDatas["affectLabels"]["2"]))	{$vDatas["affectTooltips"]["2"]=(static::isContainer())  ?  $this->tradObject("writeInfosContainer").$affectAutor  :  Txt::trad("writeInfos");}//si c'est un conteneur : "possibilité de modifier tous les elements du dossier"
				}
			}
			////	AUTEUR ET DATE
			//Auteur/invité + date création (optionnelle)
			$vDatas["infosCrea"]["autor"]=$this->displayAutor();
			$vDatas["infosCrea"]["date"]=(!empty($this->dateCrea)) ? "<br>".$this->displayDate(true,"full") : null;
			//Auteur + date Modif
			if(!empty($this->_idUserModif)){
				$vDatas["infosModif"]["autor"]=$this->displayAutor(false);
				$vDatas["infosModif"]["date"]="<br>".$this->displayDate(false,"full");
			}
			//Nouvel objet (créé depuis la dernière connexion)
			$dateCreaTime=strtotime($this->dateCrea);
			$vDatas["newObjectSinceConnection"]=(Ctrl::$curUser->isUser() && ($dateCreaTime>Ctrl::$curUser->previousConnection || $dateCreaTime>(time()-86400)))  ?  true  :  false;
		}
		////	Affichage
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuContext.php",$vDatas);
	}

	/*
	 * VUE : Menu d'édition (droits d'accès, fichiers joints, etc)
	 */
	public function menuEdit()
	{
		//Init
		$vDatas["curObj"]=$this;
		$vDatas["WriteLimitInfos"]=$this->tradObject("readLimitInfos");
		$vDatas["extendToSubfolders"]=(static::isFolder==true && $this->_id>1 && Db::getVal("SELECT count(*) FROM ".static::dbTable." WHERE _idContainer=".$this->_id)>0) ? true : false;//dossier pas racine et pas nouveau, mais avec des sous-dossiers?
		////	Menu principal : droit d'accès / identification d'un invité
		$vDatas["mainMenu"]=false;
		if(static::hasAccessRight==true && Ctrl::$curUser->isUser() && $this->isIndependant() && empty($this->onlyNotifMenu)){
			$vDatas["mainMenu"]="accessRights";
			$vDatas["mainMenuLabel"]=(static::isContainer()) ? Txt::trad("EDIT_accessRightContent") : Txt::trad("EDIT_accessRight");
		}elseif(Ctrl::$curUser->isUser()==false){
			$vDatas["mainMenu"]="identification";
			$vDatas["mainMenuLabel"]=Txt::trad("EDIT_identification");
		}
		////	Droits d'accès
		if($vDatas["mainMenu"]=="accessRights")
		{
			////	Droits d'accès pour chaque espace ("targets")
			$vDatas["blocksAccessRight"]=[];
			foreach(Ctrl::$curUser->getSpaces() as $tmpSpace)
			{
				//Init
				$tmpSpace->targetsLines=[];
				$tmpSpace->curModuleEnabled=array_key_exists(static::moduleName,$tmpSpace->moduleList());//Module activé sur l'espaces?
				////	Tous les utilisateurs de l'espace
				$tmpSpace->targetsLines[]=["targetId"=>$tmpSpace->_id."_spaceUsers", "labelText"=>Txt::trad("EDIT_allUsers"), "tooltip"=>Txt::trad("EDIT_allUsersInfo"), "labelIcon"=>"user/icon.png"];
				////	Invités
				if($tmpSpace->public=="1")
					{$tmpSpace->targetsLines[]=["targetId"=>$tmpSpace->_id."_spaceGuests", "labelText"=>Txt::trad("EDIT_spaceGuests"), "labelIcon"=>"public.png", "disableWriteAccess"=>true];}
				////	Groupe d'utilisateurs de l'espace
				foreach(MdlUserGroup::getGroups($tmpSpace) as $tmpGroup)
					{$tmpSpace->targetsLines[]=["targetId"=>$tmpSpace->_id."_G".$tmpGroup->_id, "labelText"=>$tmpGroup->title, "labelIcon"=>"user/userGroup.png", "tooltip"=>$tmpGroup->usersLabel];}
				////	Chaque user de l'espace
				foreach($tmpSpace->getUsers() as $tmpUser)
				{
					$curUserEditAccess=($tmpSpace->userAccessRight($tmpUser)==2 || $tmpUser->_id==Ctrl::$curUser->_id) ? true : false;
					$tmpSpace->targetsLines[]=array(
						"targetId"=>$tmpSpace->_id."_U".$tmpUser->_id,
						"labelText"=>$tmpUser->display(),
						"labelIconBis"=>($curUserEditAccess==true?'dot.png':null),
						"tooltip"=>($tmpSpace->userAccessRight($tmpUser)==2 ? Txt::trad("EDIT_adminSpace") : null),
						"disableLimitedAccess"=>$curUserEditAccess
					);
				}
				////	Ajoute l'espace
				$vDatas["blocksAccessRight"][]=$tmpSpace;
			}
			////	Prépare les targets de chaque espace
			foreach($vDatas["blocksAccessRight"] as $tmpKey=>$tmpSpace)
			{
				foreach($tmpSpace->targetsLines as $targetKey=>$targetLine)
				{
					//Init les propriétés des checkboxes (pas de "class"!). Utilise des "id" pour une sélection rapide des checkboxes par jQuery
					$targetLine["boxProp"]["1"]		="value='".$targetLine["targetId"]."_1'		id='objectRightBox_".$targetLine["targetId"]."_1'";
					$targetLine["boxProp"]["1.5"]	="value='".$targetLine["targetId"]."_1.5'	id='objectRightBox_".$targetLine["targetId"]."_15'";//"_15" au lieu de "_1.5" (cf. selectors jQuery)
					$targetLine["boxProp"]["2"]		="value='".$targetLine["targetId"]."_2'		id='objectRightBox_".$targetLine["targetId"]."_2'";
					//Check les box?
					$objAffectations=$this->getAffectations();
					if(array_key_exists($targetLine["targetId"],$objAffectations)){
						$targetRight=$objAffectations[$targetLine["targetId"]]["accessRight"];
						$targetLine["boxProp"][$targetRight].=" checked";
					}elseif(!empty($targetLine["preCheckRight"])){
						$targetLine["boxProp"][$targetLine["preCheckRight"]].=" checked";
					}
					//Désactive les box?
					if(!empty($targetLine["disableLimitedAccess"]))	{$targetLine["boxProp"]["1"].=" disabled";  $targetLine["boxProp"]["1.5"].=" disabled";}
					if(!empty($targetLine["disableWriteAccess"]))	{$targetLine["boxProp"]["2"].=" disabled";}
					//Met à jour les propriétés de la target
					$vDatas["blocksAccessRight"][$tmpKey]->targetsLines[$targetKey]=$targetLine;
				}
			}
		}
		////	Option "Raccourci"
		if(static::hasShortcut==true && Ctrl::$curUser->isUser() && empty($this->onlyNotifMenu)){
			$vDatas["shortcut"]=true;
			$vDatas["shortcutChecked"]=(!empty($this->shortcut)) ? "checked" : null;
		}
		////	Option "Fichiers joints"
		if(static::hasAttachedFiles==true && Ctrl::$curUser->isUser() && empty($this->onlyNotifMenu)){
			$vDatas["attachedFiles"]=true;
			$vDatas["attachedFilesList"]=$this->getAttachedFileList();
		}
		////	Options notification par mail ET users visibles, autres que ceux de l'espace courant
		if(static::hasNotifMail==true && Ctrl::$curUser->isUser() && function_exists("mail")){
			$vDatas["notifMail"]=true;
			$vDatas["notifMailUsers"]=Ctrl::$curUser->usersVisibles("mail");
			$vDatas["notifMailCurSpaceUsersIds"]=Ctrl::$curSpace->getUsers("ids");
		}
		//Affiche la vue
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuEdit.php",$vDatas);
	}

	/*
	 * STATIC : Clé de préférence en Bdd ($prefDbKey) : objet passé en parametre / conteneur ou dossier courant / module courant
	 */
	public static function getPrefDbKey($containerObj)
	{
		if(is_object($containerObj))		{return $containerObj->_targetObjId;}
		elseif(!empty(Ctrl::$curContainer))	{return Ctrl::$curContainer->_targetObjId;}
		else								{return static::moduleName;}
	}

	/*
	 * VUE : Menu de sélection d'objets (menu contextuel flottant)
	 */
	public static function menuSelectObjects($containerObj=null)
	{
		$vDatas["containerObj"]=($containerObj==null && !empty(Ctrl::$curContainer)) ? Ctrl::$curContainer : $containerObj;//Conteneur/Dossier courant en référence?
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuSelection.php",$vDatas);
	}

	/*
	 * STATIC : Tri d'objets : Preference en Bdd / paramètre passé en Get
	 * exple: "firstName@@asc"
	 */
	private static function getSort($containerObj=null)
	{
		//Récupère la préférence en Bdd ou params GET/POST
		$objectsSort=Ctrl::prefUser("sort_".static::getPrefDbKey($containerObj), "sort");
		//Tri par défaut si aucune préférence n'est précisé ou le tri sélectionné n'est pas dispo pour l'objet courant 
		if(empty($objectsSort) || !in_array($objectsSort,static::$sortFields))    {$objectsSort=static::$sortFields[0];}
		//renvoie le tri
		return $objectsSort;
	}

	/*
	 * STATIC SQL : Tri Sql des objets (avec premier tri si besoin : news, subject, etc)
	 * exple: "ORDER BY firstName asc"
	 */
	public static function sqlSort($containerObj=null, $firstSort=null)
	{
		//Récupère la préférence de tri d'un objet (dossier ou autre)
		$curSortTab=Txt::txt2tab(self::getSort($containerObj));
		//Tri par extension (de fichier ou autre) ?
		$mainSort=($curSortTab[0]=="extension") ? "SUBSTRING_INDEX(name,'.',-1)" : $curSortTab[0];
		//Renvoie le tri Sql
		return "ORDER BY ".$firstSort." ".$mainSort." ".$curSortTab[1];
	}

	/*
	 * VUE : Menu de tri d'un type d'objet
	 */
	public static function menuSort($containerObj=null)
	{
		$vDatas["curSort"]=self::getSort($containerObj);
		$vDatas["curSortTab"]=Txt::txt2tab($vDatas["curSort"]);
		foreach(static::$sortFields as $tmpSort){
			$curSortTab=Txt::txt2tab($tmpSort);
			$vDatas["sortFields"][]=array("url"=>Tool::getParamsUrl("sort")."&sort=".$tmpSort, "sort"=>$tmpSort, "field"=>$curSortTab[0], "ascDesc"=>$curSortTab[1]);
		}
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuSort.php",$vDatas);
	}

	/*
	 * STATIC : Récupère le type d'affichage de la page
	 */
	public static function getDisplayMode($containerObj=null)
	{
		if(static::$_displayMode===null){
			static::$_displayMode=Ctrl::prefUser("displayMode_".static::getPrefDbKey($containerObj), "displayMode");
			if(empty(static::$_displayMode))  {static::$_displayMode=static::$displayModeOptions[0];}//Affichage par défaut
		}
		return static::$_displayMode;
	}

	/*
	 * VUE : Menu d'affichage des objets dans une page : Blocks / Lignes (cf. $displayModeOptions)
	 */
	public static function menuDisplayMode($containerObj=null)
	{
		$vDatas["displayModeOptions"]=static::$displayModeOptions;
		$vDatas["displayMode"]=static::getDisplayMode($containerObj);
		$vDatas["displayModeUrl"]=Tool::getParamsUrl("displayMode")."&displayMode=";
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuDisplayMode.php",$vDatas);
	}

	/*
	 * STATIC SQL : Filtrage de pagination
	 */
	public static function sqlPagination()
	{
		$offset=(Req::isParam("pageNb"))  ?  ((Req::getParam("pageNb")-1)*static::nbObjectsByPage)  :  "0";
		return "LIMIT ".static::nbObjectsByPage." OFFSET ".$offset;
	}

	/*
	 * VUE : Menu de filtre alphabétique (passe en parametre la requete sql pour récupérer les
	 */
	public static function menuPagination($displayedObjNb, $getParamKey=null)
	{
		$pageNbTotal=ceil($displayedObjNb/static::nbObjectsByPage);
		if($pageNbTotal>1)
		{
			//Nb de page et numéro de page courant
			$vDatas["pageNbTotal"]=$pageNbTotal;
			$vDatas["pageNb"]=$pageNb=Req::isParam("pageNb") ? Req::getParam("pageNb") : 1;
			//Url de redirection de base
			$vDatas["hrefBase"]="?ctrl=".Req::$curCtrl;
			if(!empty($getParamKey) && Req::isParam($getParamKey))	{$vDatas["hrefBase"].="&".$getParamKey."=".Req::getParam($getParamKey);}
			$vDatas["hrefBase"].="&pageNb=";
			//Page Précédente / Suivante
			$vDatas["previousAttr"]=($pageNb>1)  ?  "href=\"".$vDatas["hrefBase"].((int)$pageNb-1)."\""  :  "class='navMenuDisabled'";
			$vDatas["nextAttr"]=($pageNb<$pageNbTotal)  ?  "href=\"".$vDatas["hrefBase"].((int)$pageNb+1)."\""  :  "class='navMenuDisabled'";
			//Récupère le menu
			return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuPagination.php",$vDatas);
		}
	}

	/*
	 * Menu d'affectation aux espaces
	 * Thème de forum (T1) / Categories d'evenement (C1)
	 */
	public function menuSpaceAffectation()
	{
		$vDatas["curObj"]=$this;
		////	Liste des espaces
		$vDatas["spaceList"]=Ctrl::$curUser->getSpaces();
		//Pour chaque espace : check espace affecté (déjà affecté à l'objet OU nouvel objet + espace courant)
		foreach($vDatas["spaceList"] as $tmpSpace){
			$tmpSpace->checked=(in_array($tmpSpace->_id,$this->spaceIds) || ($this->isNew() && $tmpSpace->_id==Ctrl::$curSpace->_id))  ?  "checked"  :  null;
		}
		////	pseudo Espace "Tous les espaces"
		if(Ctrl::$curUser->isAdminGeneral()){
			$spaceAllSpaces=new MdlSpace();
			$spaceAllSpaces->_id="all";
			$spaceAllSpaces->name=Txt::trad("visibleAllSpaces");
			$spaceAllSpaces->checked=(Ctrl::$curUser->isAdminGeneral() && $this->isNew()==false && empty($this->spaceIds))  ?  "checked"  :  null;//Check "tous les utilisateurs"?
			array_unshift($vDatas["spaceList"],$spaceAllSpaces);
		}
		//Affiche le menu
		$vDatas["displayMenu"]=(Ctrl::$curUser->isAdminGeneral() && count($vDatas["spaceList"])>1) ? true : false;
		return Ctrl::getVue(Req::commonPath."Vue/VueObjMenuSpaceAffectation.php",$vDatas);
	}
}