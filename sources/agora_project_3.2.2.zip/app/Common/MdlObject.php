<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Classe principale des Objects
 */
class MdlObject
{
	//Utilise les menus d'objets
	use MdlObjectMenus;
	
	//Propriétés principales
	const moduleName=null;
	const objectType=null;
	const dbTable=null;
	const guestDefaultRight=1;
	//Propriétés de dépendance
	const MdlObjectContent=null;
	const MdlObjectContainer=null;
	const isFolder=false;
	const isFolderContent=false;
	//Propriésé bdd
	const hasAccessRight=true;
	const hasDateCrea=true;
	const hasAutor=true;
	const hasInfosModif=true;
	//Propriétés d'IHM
	const nbObjectsByPage=null;
	const isSelectable=false;
	const hasShortcut=true;
	const hasAttachedFiles=true;
	const hasNotifMail=true;
	const htmlEditorField=null;//Champ avec editeur Html
	public static $contextMenuUniqId=null;
	//Type d'affichage des objets de la page (ligne/block)
	public static $displayModeOptions=array();
	//Champs obligatoires, Champs de recherche et Champs de tri d'affichage
	public static $requiredFields=array();
	public static $searchFields=array();
	public static $sortFields=array();
	//Valeurs en cache (calculées qu'1 fois)
	private $_accessRight=null;
	private $_containerObj=null;
	private $_attachedFiles=null;
	private $_affectations=null;
	protected static $_displayMode=null;

	/*
	 * Init
	 */
	function __construct($objIdOrValues=null)
	{
		////	Par défaut
		$this->_id=0;
		////	Assigne des propriétés à l'objet : Objet déjà créé / Objet à créer
		if(!empty($objIdOrValues)){
			//Récupère les propriétés en bdd / propriétés déjà passées en paramètre
			$objValues=(is_numeric($objIdOrValues))  ?  Db::getLine("select * from ".static::dbTable." where _id=".(int)$objIdOrValues)  :  $objIdOrValues;
			//S'il y a des propriétés
			if(!empty($objValues)){
				foreach($objValues as $propertieKey=>$propertieVal)  {$this->$propertieKey=$propertieVal;}
			}
		}
		////	Identifiant + identifiant générique (exple : "fileFolder-19")
		$this->_id=(int)$this->_id;
		$this->_targetObjId=static::objectType."-".$this->_id;
	}

	/*
	 * Renvoie la valeur d'une propriété (ne renvoie rien si la propriete est inexistante)
	 */
	function __get($propertyName)
	{
		if(!empty($this->$propertyName))	{return $this->$propertyName;}
	}

	/*
	 * Renvoi le type de l'objet
	 */
	public function getType()
	{
		return static::objectType;
	}

	/*
	 * Vérifie si un objet est déjà créé et possède un _id
	 */
	public static function isObj($curObj=null)
	{
		return (!empty($curObj) && is_object($curObj) && !empty($curObj->_id));
	}

	/*
	 * Url d'accès à l'objet : "vue" de l'objet (lightbox) / Edition de l'objet / suppression de l'objet / conteneur de l'objet
	 */
	public function getUrl($display=null)
	{
		//Objet n'existe plus (supprimé depuis par un autre user?).
		if($this->isNew())	{return "?ctrl=".static::moduleName;}
		//Objet existe encore
		else
		{
			$urlBase="?ctrl=".static::moduleName."&targetObjId=";
			if($display=="vue")													{return $urlBase.$this->_targetObjId."&action=".static::objectType."Vue";}						//Affichage d'un objet : lightbox
			elseif($display=="edit" && static::isFolder==true)					{return "?ctrl=object&targetObjId=".$this->_targetObjId."&action=FolderEdit";}					//Edition d'un dossier : lightbox
			elseif($display=="edit")											{return $urlBase.$this->_targetObjId."&action=".static::objectType."Edit";}						//Edition d'un objet : lightbox
			elseif($display=="delete")											{return "?ctrl=object&targetObjects[".static::objectType."]=".$this->_id."&action=delete";}		//Suppression d'un objet : ctrl=object
			elseif($display=="container" && is_object($this->containerObj()))	{return $urlBase.$this->containerObj()->_targetObjId."&targetObjIdChild=".$this->_targetObjId;}	//Conteneur d'un objet (exple: dossier d'un fichier)
			else																{return $urlBase.$this->_targetObjId;}															//Cible l'objet lui même (exple : dossier)
		}
	}

	/*
	 * Url d'edition d'un nouvel objet
	 */
	public static function getUrlNew()
	{
		$url="?ctrl=".static::moduleName."&action=".static::objectType."Edit"."&targetObjId=".static::objectType;
		if(!empty(Ctrl::$curContainer))	{$url.="&_idContainer=".Ctrl::$curContainer->_id;}
		return $url;
	}

	/*
	 * VERIF : l'objet est un conteneur (dossier, agenda, sujet du forum) ?
	 */
	public static function isContainer(){
		return (static::MdlObjectContent!==null);
	}
	/*
	 * VERIF : l'objet est un contenu dans un conteneur (exple:fichier d'un dossier, evenement d'un agenda) ?
	 */
	public static function isContainersContent(){
		return (static::MdlObjectContainer!==null);
	}
	/*
	 * VERIF : l'objet se trouve dans une arborescence (exple: dossier ou fichier de dossier) ?
	 */
	public static function isInArbo(){
		return (static::isFolder==true || static::isFolderContent==true);
	}
	/*
	 * VERIF : l'objet est un dossier racine ?
	 */
	public function isRootFolder(){
		return (static::isFolder==true && $this->_id==1);
	}
	/*
	 * VERIF : Objet indépendant avec ses propres droits d'accès (ne dépendant pas d'un "conteneur" || "contenu" dans un dossier racine)
	 */
	public function isIndependant(){
		return (static::MdlObjectContainer===null || (static::isFolderContent==true && $this->containerObj()->isRootFolder()));
	}
	/*
	 * VERIF : User courant est l'auteur de l'objet ?
	 */
	public function isAutor(){
		return ($this->_idUser==Ctrl::$curUser->_id && Ctrl::$curUser->isUser());
	}
	/*
	 * VERIF : Objet nouveau
	 */
	public function isNew(){
		return (empty($this->_id));
	}
	/*
	 * VERIF : Objet nouvellement créé (dateCrea==-2sec)
	 */
	public function isNewlyCreated(){
		return ($this->isNew() || time()-strtotime($this->dateCrea)<2);
	}

	/*
	 * Liste les affectations de l'objet (Espaces/groupes/users)
	 */
	public function getAffectations()
	{
		if($this->_affectations===null)
		{
			//Init
			$this->_affectations=$tmpAffectations=array();
			////	Affectations en Bdd  OU  Affectations par défaut : nouvel objet
			if($this->isNew()==false)	{$tmpAffectations=Db::getTab("SELECT * FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id." ORDER BY target");}
			else
			{
				//Affectation à l'espace (ecriture limité pour un conteneur, sinon lecture)
				$spaceUsersRight=(static::isContainer())  ?  "1.5"  :  "1";
				$tmpAffectations[]=["_idSpace"=>Ctrl::$curSpace->_id, "target"=>"spaceUsers", "accessRight"=>$spaceUsersRight];
				//Affectation au public/guests?
				if(Ctrl::$curSpace->public==1)	{$tmpAffectations[]=["_idSpace"=>Ctrl::$curSpace->_id, "target"=>"spaceGuests", "accessRight"=>1];}
			}
			////	Formate les affectations
			foreach($tmpAffectations as $tmpAffect)
			{
				//Affectations détaillées
				if($tmpAffect["target"]=="allSpaces")			{$tmpAffect["targetType"]=$tmpAffect["target"];		$tmpAffect["targetId"]=null;											$tmpAffect["label"]=Txt::trad("EDIT_allSpaces");}												//"Tous les espaces"
				elseif($tmpAffect["target"]=="spaceGuests")		{$tmpAffect["targetType"]=$tmpAffect["target"];		$tmpAffect["targetId"]=$tmpAffect["_idSpace"];							$tmpAffect["label"]=Ctrl::getObj("space",$tmpAffect["targetId"])->name." (".Txt::trad("guests").")";}	//"Espace Bidule (invités)"
				elseif($tmpAffect["target"]=="spaceUsers")		{$tmpAffect["targetType"]=$tmpAffect["target"];		$tmpAffect["targetId"]=$tmpAffect["_idSpace"];							$tmpAffect["label"]=Ctrl::getObj("space",$tmpAffect["targetId"])->name." (".Txt::trad("all").")";}		//"Espace Bidule (tous)"
				elseif(substr($tmpAffect["target"],0,1)=="G")	{$tmpAffect["targetType"]="group";					$tmpAffect["targetId"]=(int)str_replace('G','',$tmpAffect["target"]);	$tmpAffect["label"]=Ctrl::getObj("userGroup",$tmpAffect["targetId"])->title;}							//"Groupe Bidule"
				elseif(substr($tmpAffect["target"],0,1)=="U")	{$tmpAffect["targetType"]="user";					$tmpAffect["targetId"]=(int)str_replace('U','',$tmpAffect["target"]);	$tmpAffect["label"]=Ctrl::getObj("user",$tmpAffect["targetId"])->display();}							//"Jean Dupont"
				//Ajoute l'affectation
				$targetKey=(int)$tmpAffect["_idSpace"]."_".$tmpAffect["target"];
				$this->_affectations[$targetKey]=$tmpAffect;
			}
		}
		return $this->_affectations;
	}

	/*
	 * Affectation des droits d'accès provenant (cf."menuEdit()"). Par défaut : accès en lecture à l'espace courant
	 */
	public function setAffectations($specificAccessRight=null)
	{
		if($this->isIndependant())
		{
			//Init
			$sqlInsertBase="INSERT INTO ap_objectTarget SET objectType='".static::objectType."', _idObject=".$this->_id.", ";
			////	Objet créé par un "Guest"
			if(Ctrl::$curUser->isUser()==false){
				Db::query($sqlInsertBase." _idSpace=".Ctrl::$curSpace->_id.", target='spaceGuests', accessRight=".Db::format(static::guestDefaultRight));
				Db::query($sqlInsertBase." _idSpace=".Ctrl::$curSpace->_id.", target='spaceUsers', accessRight=".Db::format(static::guestDefaultRight));
			}
			////	Objet créé par un user && droit d'accès spécifiés
			elseif(Req::isParam("objectRight") || !empty($specificAccessRight))
			{
				//Réinitialise les droits, uniquement sur les espaces auxquels l'user courant a accès
				if($this->isNew()==false){
					$sqlSpaces="_idSpace IN (".implode(",",Ctrl::$curUser->getSpaces("ids")).")";
					if(Ctrl::$curUser->isAdminGeneral())	{$sqlSpaces="(".$sqlSpaces." OR _idSpace is null)";}
					Db::query("DELETE FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id." AND ".$sqlSpaces);
				}
				//Ajoute les nouveaux droits d'accès : passés en paramètre / provenant du formulaire
				$newAccessRight=(Req::isParam("objectRight"))  ?  Req::getParam("objectRight")  :  $specificAccessRight;
				foreach($newAccessRight as $tmpRight){
					$tmpRight=explode("_",$tmpRight);//exple :  "5_U3_2"  devient ["_idSpace"=>"5","target"=>"U3","accessRight"=>"2"]  correspond à droit "2" sur l'user "3" de l'espace "5"
					Db::query($sqlInsertBase." _idSpace=".Db::format($tmpRight[0]).", target=".Db::format($tmpRight[1]).", accessRight=".Db::format($tmpRight[2]));
				}
			}
		}
	}

	/*
	 * Récupère les droits d'accès à l'objet  (conteneur=dossier,agenda,sujet,etc / contenu=actualité,fichier,taches,etc / ecriture=ajout-modif-suppr)
	 *		3	[total]					sur un conteneur -> ecriture du conteneur + ecriture du contenu de premier niveau(*) + suppression de TOUTE l'arborescence
	 *									sur un contenu	 -> ecriture
	 *		2	[ecriture]				sur un conteneur -> lecture du conteneur + ecriture du contenu de premier niveau(*)
	 *									sur un contenu	 -> ecriture
	 *		1.5	[ecriture limité]		sur un conteneur -> lecture du conteneur + ecriture du contenu qu'on a créé (pour les invités, on limite uniquement à l'ajout de nouveau contenu: pas de modif!)
	 *									sur un contenu	 -> -non disponible-
	 *		1	[lecture]				sur un conteneur -> lecture
	 *									sur un contenu	 -> lecture
	 *		(*) les éléments des sous-dossiers sont soumis au droit d'accès de leur dossier conteneur
	 */
	public function accessRight()
	{
		if($this->_accessRight===null)
		{
			//Init
			$this->_accessRight=0;
			//ACCES TOTAL  =>  Auteur de l'objet  ||  Nouvel objet et addRight()==True  ||  Admin général
			if($this->isAutor() || ($this->_id==0 && static::addRight()) || Ctrl::$curUser->isAdminGeneral())	{$this->_accessRight=3;}
			//DROITS NORMAL
			elseif(static::hasAccessRight==true)
			{
				//ACCES TOTAL  =>  Admin d'espace  &&  accessRightAdminSpacePrivilege()==true  &&  RootFolder()==false  (..et objet pas affecté à d'autres espaces)
				if(Ctrl::$curUser->isAdminCurSpace() && $this->accessRightAdminSpacePrivilege() && $this->isRootFolder()==false){
					$nbSpaceAffect=Db::getVal("SELECT count(distinct _idSpace) FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id." AND (_idSpace!=".Ctrl::$curSpace->_id." or _idSpace is null)");
					if($nbSpaceAffect==0)	{$this->_accessRight=3;}
				}
				//ACCES A CALCULER  =>  User lambda
				if(empty($this->_accessRight))
				{
					//DROITS D'ACCES DU CONTENEUR => objet est dépendant d'un dossier, etc   ||   DROITS D'ACCES CALCULE  =>  DROIT D'AFFECTATION LE PLUS IMPORTANT !
					if(!empty($this->_idContainer) && $this->isIndependant()==false)	{$this->_accessRight=$this->containerObj()->accessRight();}
					else																{$this->_accessRight=Db::getVal("SELECT max(accessRight) FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id." AND (_idSpace=".Ctrl::$curSpace->_id." or _idSpace is null) AND target IN (".static::sqlTargets().")");}
					//DROIT PAR DEFAUT DU DOSSIER RACINE, SI TOUJOURS PAS SPECIFIES
					if(empty($this->_accessRight) && $this->isRootFolder())  {$this->_accessRight=Ctrl::$curUser->isUser()?2:1;}
				}
			}
		}
		return $this->_accessRight;
	}

	/*
	 * Privilège de droits d'accès pour l'admin général (surchargé). Activé par défaut
	 */
	public function accessRightAdminSpacePrivilege()
	{
		return true;
	}

	/*
	 * Droit de lecture sur un objet
	 */
	public function readRight()
	{
		return ($this->accessRight()>0);
	}

	/*
	 * Droit d'ajouter un nouvel objet sur le module (surchargée). Interdit aux guests sur les conteneurs
	 */
	public static function addRight()
	{
		return (static::isContainer()==false || Ctrl::$curUser->isUser());
	}

	/*
	 * Conteneur : Droit d'ajouter du contenu et éditer le contenu que j'ai créé
	 */
	public function editContentRight()
	{
		return (static::isContainer() && $this->accessRight()>1);//1.5 aussi!
	}

	/*
	 * Conteneur : Droit d'éditer tout le contenu
	 */
	public function editFullContentRight()
	{
		return (static::isContainer() && $this->accessRight()>=2);
	}

	/*
	 * Droit d'édition d'un objet (frequement surchargée)  =>  "fullRight()"  OU  droit sup. à "2" pour les objets qui ne sont pas des conteneurs
	 */
	public function editRight()
	{
		return ($this->fullRight() || (static::isContainer()==false && $this->accessRight()>=2));
	}

	/*
	 * Droit de suppression d'un objet (surchargée).
	 */
	public function deleteRight()
	{
		return ($this->editRight() && $this->isNew()==false);
	}

	/*
	 * Droit complet sur l'objet
	 */
	public function fullRight()
	{
		return ($this->accessRight()==3);
	}

	/*
	 * Pas accès en lecture : exit()
	 */
	public function controlRead()
	{
		if($this->accessRight()==false || $this->accessRight()==0)	{Ctrl::noAccessExit();}
	}

	/*
	 * Controle l'édition de l'objet
	 */
	public function controlEdit()
	{
		//Controle le droit d'accès en écriture
		if($this->editRight()==false)	{Ctrl::noAccessExit();}
		//Controle si l'objet n'est pas en cour d'édition par un autre user (dans la dernières minute)
		$_idUserEditSameObj=Db::getVal("SELECT _idUser FROM ap_userLivecouter WHERE _idUser!=".Ctrl::$curUser->_id." AND editObjId=".Db::formatParam("targetObjId")." AND date>".(time()-60));
		if($this->isNew()==false && !empty($_idUserEditSameObj))	{Ctrl::addNotif(Txt::trad("warning")." !<br>".Txt::trad("elemEditedByAnotherUser")." ".Ctrl::getObj("user",$_idUserEditSameObj)->display());}
	}

	/*
	 * Recupère l'objet conteneur de l'objet courant (ex: dossier d'un fichier)
	 */
	public function containerObj()
	{
		if($this->_containerObj===null && static::isContainersContent() && !empty($this->_idContainer)){
			$MdlObjectContainer=static::MdlObjectContainer;
			$this->_containerObj=Ctrl::getObj($MdlObjectContainer::objectType,$this->_idContainer);
		}
		return $this->_containerObj;
	}

	/*
	 * Suppression d'un objet
	 */
	public function delete()
	{
		if($this->deleteRight())
		{
			//Supprime les fichiers joints
			if(static::hasAttachedFiles==true){
				foreach($this->getAttachedFileList() as $tmpFile)	{$this->deleteAttachedFile($tmpFile);}
			}
			//Ajoute le log de suppression
			Ctrl::addLog("delete",$this);
			//Suppr les droits d'accès & l'objet lui-même!
			Db::query("DELETE FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id);
			Db::query("DELETE FROM ".static::dbTable." WHERE _id=".$this->_id);
		}
	}

	/*
	 * Déplace un objet (dossier?) dans un autre dossier
	 */
	public function folderMove($newFolderId)
	{
		////	Ancien et nouveau dossier
		$oldFolder=$this->containerObj();
		$newFolder=Ctrl::getObj($oldFolder::objectType, $newFolderId);
		////	Objet pas dans une arbo? Droit d'accès pas ok? || dossier de destination inaccessible sur le disque? || Déplace un dossier à l'interieur de lui même?
		if(static::isInArbo()==false || $this->accessRight()<2 || $newFolder->accessRight()<2 || (static::objectType=="fileFolder" && is_dir($newFolder->folderPath("real"))==false))    {Ctrl::addNotif(Txt::trad("inaccessibleElem")." : ".$this->name.$this->title);}
		elseif(static::isFolder && $this->isInFolderTree($newFolderId))    {Ctrl::addNotif(Txt::trad("NOTIF_folderMove")." : ".$this->name);}
		else
		{
			////	Change le dossier conteneur
			Db::query("UPDATE ".static::dbTable." SET _idContainer=".(int)$newFolderId." WHERE _id=".$this->_id);
			//Contenu de dossier : change les droits d'accès?
			if(static::isFolder==false)
			{
				//Réinitialise les droits d'accès
				Db::query("DELETE FROM ap_objectTarget WHERE objectType='".static::objectType."' AND _idObject=".$this->_id);
				//Déplace à la racine : récupère les droits d'accès de l'ancien dossier conteneur
				if($newFolder->isRootFolder()){
					foreach(Db::getTab("SELECT * FROM ap_objectTarget WHERE objectType='".$oldFolder::objectType."' AND _idObject=".$oldFolder->_id) as $oldFolderAccessRight){
						Db::query("INSERT INTO ap_objectTarget SET objectType='".static::objectType."', _idObject=".$this->_id.", _idSpace=".$oldFolderAccessRight["_idSpace"].", target='".$oldFolderAccessRight["target"]."', accessRight='".$oldFolderAccessRight["accessRight"]."'");
					}
				}
			}
			////	Reload l'objet (et du cache)
			$reloadedObj=Ctrl::getObj(static::objectType, $this->_id, true);
			////	Déplace un fichier sur le disque
			if(static::objectType=="file"){
				//Deplace chaque version du fichier
				foreach(Db::getTab("SELECT * FROM ap_fileVersion WHERE _idFile=".$this->_id) as $tmpFileVersion){
					rename($oldFolder->folderPath("real").$tmpFileVersion["realName"], $newFolder->folderPath("real").$tmpFileVersion["realName"]);
				}
				//Déplace la vignette
				if($this->hasThumb()){
					rename($oldFolder->folderPath("real").$this->getThumbName(), $newFolder->folderPath("real").$this->getThumbName());
				}
			}
			////	Déplace un dossier sur le disque (du chemin actuel : $this,  vers le nouveau chemin : $reloadedObj)
			elseif(static::objectType=="fileFolder"){
				rename($this->folderPath("real"), $reloadedObj->folderPath("real"));
			}
			////	Ajoute aux logs
			Ctrl::addLog("edit", $reloadedObj, Txt::trad("changeFolder"));
			return true;
		}
	}

	/*
	 * Envoi d'un mail de notification (cf. "menuEdit")
	 */
	public function sendMailNotif($message, $attachedFiles=null, $specificAffectUserIds=null, $addedUserIds=null)
	{
		//Notification demandé par l'auteur de l'objet  OU  users ajoutés automatiquement
		if(Req::isParam("notifMail") || !empty($addedUserIds))
		{
			////	Sujet ("Nouvel element créé par boby SMITH : Actualité")
			$tradObjectType=(static::isFolder) ? "OBJECTfolder" : "OBJECT".static::objectType;
			$subject=(strtotime($this->dateCrea)>(time()-10) || empty($this->dateCrea)) ? Txt::trad("MAIL_elemCreatedBy") : Txt::trad("MAIL_elemModifiedBy");//"Element modifié par" / "Nouvel element créé par" (10 secondes max precedant la notif)
			$subject.=" ".Ctrl::$curUser->display()." (".Txt::trad($tradObjectType).")";//" boby SMITH (Actualité)"
			////	Message
			$targetObjUrl=Req::getSpaceUrl()."/?ctrl=offline&_idSpaceAccess=".Ctrl::$curSpace->_id."&notifSpaceAccess=1&targetObjUrl=".urlencode($this->getUrl("container"));
			$message=str_replace(PATH_DATAS, Req::getSpaceUrl()."/".PATH_DATAS, $message);//Remplace les chemins relatifs dans le message (=> conserver?)
			$message=$subject.", ".Txt::trad("MAIL_elemOnSpace")." <i>".Ctrl::$curSpace->name."</i> :<br><br>".$message."<br><br><a href=\"".$targetObjUrl."\" target='_blank'>".Txt::trad("MAIL_elemAccessLink")."</a>";//Ajoute "Créé sur l'espace 'Bidule'" ...
			////	Users (id) à destination de la notif
			$notifUsersIds=[];
			if(Req::isParam("notifMail"))
			{
				if(Req::isParam("notifMailUsers"))		{$notifUsersIds=Req::getParam("notifMailUsers");}	//Selection de l'auteur de l'objet 
				elseif(!empty($specificAffectUserIds))	{$notifUsersIds=$specificAffectUserIds;}			//Users spécifiquement affectées à l'objet (exple: evts dans plusieurs agendas)
				else{																						//Users affectées à l'objet
					$refObject=($this->isIndependant()) ? $this : $this->containerObj();//Objet de référence pour les affectations
					foreach($refObject->getAffectations() as $tmpAffect){
						if($tmpAffect["targetType"]=="spaceUsers")	{$notifUsersIds=array_merge($notifUsersIds, Ctrl::getObj("space",$tmpAffect["targetId"])->getUsers("ids"));}
						elseif($tmpAffect["targetType"]=="group")	{$notifUsersIds=array_merge($notifUsersIds, Ctrl::getObj("userGroup",$tmpAffect["targetId"])->userIds);}
						elseif($tmpAffect["targetType"]=="user")	{$notifUsersIds[]=$tmpAffect["targetId"];}
					}
				}
			}
			////	Ajoute des users à la notification (exple: notif automatiques des messages de forum) 
			if(!empty($addedUserIds)){
				if(Req::isParam("notifMail")==false)	{$addedOptions="noSendNotif";}//Pas de demande explicite de l'user courant : on affiche pas de rapport d'envoi
				$notifUsersIds=array_merge($notifUsersIds,$addedUserIds);
			}
			////	Envoi du message
			if(!empty($notifUsersIds))
			{
				$options="objectEditNotif";
				if(Req::isParam("hideRecipients"))	{$options.=",hideRecipients";}
				if(Req::isParam("receptionNotif"))	{$options.=",receptionNotif";}
				if(!empty($addedOptions))			{$options.=",".$addedOptions;}
				Tool::sendMail(array_unique($notifUsersIds), $subject, $message, $options, $attachedFiles);
			}
		}
	}

	/*
	 * Ajout/Modif d'objet
	 */
	public function createUpdate($sqlProperties)
	{
		if($this->editRight())
		{
			////	Enleve espace et virgule en fin
			$sqlProperties=trim(trim($sqlProperties),",");
			////	Date & Auteur créa  +  Date & Auteur modif
			if($this->isNew() && static::hasDateCrea==true)				{$sqlProperties.=", dateCrea=".Db::dateNow();}
			if($this->isNew() && static::hasAutor==true)				{$sqlProperties.=", _idUser=".Db::format(Ctrl::$curUser->_id);}
			if($this->isNew()==false && static::hasInfosModif==true)	{$sqlProperties.=", dateModif=".Db::dateNow().", _idUserModif=".Ctrl::$curUser->_id;}
			////	Propriétés optionnelles "_idContainer", "guest", "shortcut" (attention au decochage)
			if(Req::isParam("_idContainer"))	{$sqlProperties.=", _idContainer=".Db::formatParam("_idContainer");}
			if(Req::isParam("guest"))			{$sqlProperties.=", guest=".Db::formatParam("guest");}
			if(static::hasShortcut==true)		{$sqlProperties.=", shortcut=".Db::formatParam("shortcut");}
			////	LANCE L'INSERT/UPDATE !!
			if($this->isNew())	{$_id=(int)Db::query("INSERT INTO ".static::dbTable." SET ".$sqlProperties, true);}
			else{
				Db::query("UPDATE ".static::dbTable." SET ".$sqlProperties." WHERE _id=".$this->_id);
				$_id=$this->_id;
			}
			////	Reload l'objet (update cache)  & Ajoute les droits d'accès (si ya)  & Ajoute les fichiers joints (si ya)  & Ajoute aux Logs
			$reloadedObj=Ctrl::getObj(static::objectType, $_id, true);
			$reloadedObj->setAffectations();
			$reloadedObj->addAttachedFiles();
			Ctrl::addLog("edit",$reloadedObj);
			////	renvoie l'objet rechargé et remis en chache!
			return $reloadedObj;
		}
	}

	/*
	 * STATIC SQL : Selection d'objets en fonction des droits d'accès ("targets")
	 * "targets" => "allSpaces" / "spaceGuests" / "spaceUsers" / "U1" / "G1"
	 */
	public static function sqlTargets()
	{
		// Objets des invités ou des utilisateurs
		$sqlTarget="'spaceGuests'";
		if(Ctrl::$curUser->isUser()){
			$sqlTarget.=",'spaceUsers','allSpaces','U".Ctrl::$curUser->_id."'";
			foreach(Ctrl::$curUserCurSpaceGroups as $tmpGroup)	{$sqlTarget.=",'G".$tmpGroup->_id."'";}
		}
		return $sqlTarget;
	}

	/*
	 * STATIC SQL : Selection d'objets à afficher
	 * En fonction de l'espace courant & "displayAdmin" & eventuellement du conteneur
	 */
	public static function sqlDisplayedObjects($containerObj=null, $keyId="_id")
	{
		$sqlConditions=[];
		////	Selectionne les objets en fonction de leurs droits d'accès (uniquement les objets indépendants)
		if(static::isContainersContent()==false  ||  (static::isFolderContent && (empty($containerObj) || $containerObj->isRootFolder()))){
			$sqlTargets=(empty($_SESSION["displayAdmin"]))  ?  "and target in (".static::sqlTargets().")"  :  null;//"displayAdmin": pas de sélection en fonction des droits d'accès (prend tous les obj. affectés à l'espace)
			$sqlConditions[]=$keyId."  IN  (select _idObject as ".$keyId." from ap_objectTarget where objectType='".static::objectType."' and (_idSpace=".Ctrl::$curSpace->_id." or _idSpace is null) ".$sqlTargets.")";
		}
		////	Selectionne les objets dans un conteneur (dossier ou autre)
		if(is_object($containerObj))	{$sqlConditions[]="_idContainer=".$containerObj->_id;}
		////	FINALISE LA SÉLECTION
		$sqlDisplayedObjects=(!empty($sqlConditions))  ?  "(".implode(" AND ",$sqlConditions).")"  :  $keyId." is null";//fusionne la sélection : "AND" || aucune sélection : "is null"
		////	Selection de plugins (cf. "getPluginObjects()") : on ajoute les objets dans les conteneurs que l'on peut afficher (elements de dossiers / messages du forum / etc)
		if(empty($containerObj) && static::isContainersContent()){
			$MdlObjectContainer=static::MdlObjectContainer;
			$sqlDisplayedObjects="(".$sqlDisplayedObjects." OR ".$MdlObjectContainer::sqlDisplayedObjects(null,"_idContainer").")";//Appel récursif avec "_idContainer" comme $keyId
		}
		return $sqlDisplayedObjects;
	}

	/*
	 * STATIC SQL : Recupère les objets pour un affichage "plugins" ("dashboard"/"shortcut"/"search")
	 */
	public static function getPluginObjects($pluginParams)
	{
		$returnObjects=[];
		if(isset($pluginParams["type"]))
		{
			//Recupere les elements du plugin!
			$returnObjects=Db::getObjTab(static::objectType, "SELECT * FROM ".static::dbTable." WHERE ".static::sqlPluginObjects($pluginParams)." AND ".static::sqlDisplayedObjects()." ORDER BY dateCrea desc");
			//Ajoute si besoin les plugins "current" du Dashboard (ayant lieu entre aujourd'hui et la fin de la periode selectionné)
			if($pluginParams["type"]=="dashboard" && (static::objectType=="calendarEvent" || static::objectType=="task"))
			{
				$pluginParams["type"]="current";
				$returnObjectsCurrent=Db::getObjTab(static::objectType, "SELECT * FROM ".static::dbTable." WHERE ".static::sqlPluginObjects($pluginParams)." AND ".static::sqlDisplayedObjects()." ORDER BY dateCrea desc");
				foreach($returnObjectsCurrent as $tmpObj){
					$tmpObj->pluginIsCurrent=true;
					$returnObjects[$tmpObj->_id]=$tmpObj;//écrase / ajoute l'objet du tableau
				}
			}
		}
		return $returnObjects;
	}

	/*
	 * STATIC SQL : Selection d'objets en fonction du type de plugin
	 * $pluginParams["type"] => "dashboard": cree dans la periode selectionné / "shortcut": ayant un raccourci / "search": issus d'une recherche
	 */
	public static function sqlPluginObjects($pluginParams)
	{
		if($pluginParams["type"]=="current")		{return "((dateBegin between ".Db::format($pluginParams["dateTimeBegin"])." and ".Db::format($pluginParams["dateTimeEnd"]).")  OR  (dateEnd between ".Db::format($pluginParams["dateTimeBegin"])." and ".Db::format($pluginParams["dateTimeEnd"]).")  OR  (dateBegin < ".Db::format($pluginParams["dateTimeBegin"])." and dateEnd > ".Db::format($pluginParams["dateTimeEnd"])."))";}
		elseif($pluginParams["type"]=="dashboard")	{return "dateCrea between '".$pluginParams["dateTimeBegin"]."' AND '".$pluginParams["dateTimeEnd"]."'";}
		elseif($pluginParams["type"]=="shortcut")	{return "shortcut=1";}
		elseif($pluginParams["type"]=="search")
		{
			$sqlReturned="";
			//Recherche dans tous les champs de l'objet ou uniquement ceux demandés
			$objectSearchFields=(!empty($pluginParams["searchFields"])) ? array_intersect(static::$searchFields,$pluginParams["searchFields"]) : static::$searchFields;
			//Recherche l'expression exacte  (title LIKE 'mot1 mot2')
			if($pluginParams["searchMode"]=="exactPhrase"){
				foreach($objectSearchFields as $tmpField)	{$sqlReturned.=$tmpField." LIKE ".Db::format($pluginParams["searchText"])." OR "; }
			}
			//Recherche un des mots || tous les mots  ("title like '%mot1%' or title like '%mot2%'"  <=>  "title like '%mot1%' and title like '%mot2%'")
			else{
				$searchWords=explode(" ",$pluginParams["searchText"]);
				$linkOperator=($pluginParams["searchMode"]=="allWords")  ?  " and "  :  " or ";//garder les espaces
				foreach($objectSearchFields as $tmpField){
					$sqlSubSearch="";
					foreach($searchWords as $tmpWord)	{$sqlSubSearch.=$tmpField." like ".Db::format($tmpWord,"likeSearch").$linkOperator;}
					$sqlReturned.="(".rtrim($sqlSubSearch,$linkOperator).") OR ";//"rtrim" plutôt que "trim" (car bouffe la première lettre du $sqlSubSearch..)
				}
			}
			//Sélection de base
			$sqlReturned="(".rtrim($sqlReturned," OR ").")";
			//Recherche aussi sur la date de creation
			if($pluginParams["creationDate"]!="all"){
				$nbDays=array("day"=>1,"week"=>7,"month"=>31,"year"=>365);
				$beginDate=time()-(86400*$nbDays[$pluginParams["creationDate"]]);
				$sqlReturned="(".$sqlReturned." AND dateCrea BETWEEN '".date("Y-m-d 00:00",$beginDate)."' and '".date("Y-m-d 23:59")."')";
			}
			//retourne le résultat
			return $sqlReturned;
		}
	}

	/*
	 * Infos sur un fichier joint
	 */
	public static function getAttachedFile($fileInfos)
	{
		//Récup les infos en bdd (si besoin)
		if(is_numeric($fileInfos))
			{$fileInfos=Db::getLine("SELECT * FROM ap_objectAttachedFile WHERE _id=".(int)$fileInfos);}
		//Ajoute le nom, le chemin et l'objet conteneur
		$fileInfos["path"]=PATH_OBJECT_ATTACHMENT.$fileInfos["_id"].".".File::extension($fileInfos["name"]);
		$fileInfos["name"]=$fileInfos["name"];
		$fileInfos["containerObj"]=Ctrl::getObj($fileInfos["objectType"],$fileInfos["_idObject"]);
		return $fileInfos;
	}

	/*
	 * Fichiers joints de l'objet
	 */
	public function getAttachedFileList()
	{
		if($this->_attachedFiles===null)
		{
			$this->_attachedFiles=array();
			if(static::hasAttachedFiles==true){
				foreach(Db::getTab("SELECT * FROM ap_objectAttachedFile WHERE objectType='".static::objectType."' AND _idObject=".$this->_id)  as  $fileKey=>$tmpFile)
					{$this->_attachedFiles[$fileKey]=self::getAttachedFile($tmpFile);}//ajoute le "path"+"name"
			}
		}
		return $this->_attachedFiles;
	}

	/*
	 * Menu des fichiers joints de l'objet (menu contextuel ou description)
	 */
	public function menuAttachedFiles($separator="<hr>")
	{
		if(count($this->getAttachedFileList())>0)
		{
			$menuAttachedFiles=$separator;
			foreach($this->getAttachedFileList() as $tmpFile)
				{$menuAttachedFiles.="<div class='menuAttachedFile sLink' title=\"".Txt::trad("download")."\" onclick=\"redir('?ctrl=object&action=downloadAttachedFile&_id=".$tmpFile["_id"]."');\"><img src='app/img/attachment.png'> ".$tmpFile["name"]."</div>";}
			return $menuAttachedFiles;
		}
	}

	/*
	 * Ajoute un fichier joint dans la description (image/video/audio/flash) : via une requete Sql OU l'editeur html
	 */
	public static function attachedFileInsert($_idFile, $editorInsert=true)
	{
		//Récupère l'image ou le player du média
		$insertText=null;
		$curFile=self::getAttachedFile($_idFile);
		$displayPath="?ctrl=object&action=DisplayAttachedFile&_id=".$curFile["_id"]."&name=".$curFile["name"];
		if(File::controlType("imageBrowser",$curFile["path"]))		{$insertText="<img src='".$displayPath."' style='max-width:100%;'>";}//garder le "style" pour tinyMce..
		elseif(File::controlType("mp3",$curFile["path"]))			{$insertText=File::getMediaPlayer($displayPath);}
		elseif(File::controlType("videoBrowser",$curFile["path"]))	{$insertText=File::getMediaPlayer($curFile["path"]);}//affichage direct
		//Retourne le résultat
		if(!empty($insertText)){
			$insertText="<div id='tagAttachedFile".$curFile["_id"]."' title='".str_replace("'",null,$curFile["name"])."'>".$insertText."</div>";
			return ($editorInsert==true)  ?  "onclick=\"tinymce.activeEditor.setContent(tinymce.activeEditor.getContent()+'".addslashes(str_replace("\"","'",$insertText))."');\""  :  $insertText;
		}
	}

	/*
	 * Ajoute les fichiers joints (cf. "menuEdit()")
	 */
	public function addAttachedFiles()
	{
		if(static::hasAttachedFiles==true)
		{
			$curDatasFolderSize=File::datasFolderSize();
			foreach($_FILES as $inputId=>$curFile)
			{
				if(stristr($inputId,"addAttachedFile"))
				{
					////	Pas assez d'espace disque?  /  Fichier bien telechargé?
					if(($curDatasFolderSize+$curFile["size"]) > limite_espace_disque)	{Ctrl::addNotif("NOTIF_diskSpace");  break;}//sort de la boucle..
					elseif($curFile["error"]==0)
					{
						//Ajoute le fichier en Bdd et dans le dossier de destination
						$attachedFileId=Db::query("INSERT INTO ap_objectAttachedFile SET name=".Db::format($curFile["name"]).", objectType='".static::objectType."', _idObject=".$this->_id, true);
						$fileDestPath=PATH_OBJECT_ATTACHMENT.$attachedFileId.".".File::extension($curFile["name"]);
						$isMoved=move_uploaded_file($curFile["tmp_name"], $fileDestPath);
						if($isMoved!=false)
						{
							//Optimise le fichier
							if(File::controlType("imageResize",$fileDestPath))	{File::imageResize($fileDestPath,$fileDestPath,1200);}
							File::setChmod($fileDestPath);
							//Ajoute l'image/vidéo/Mp3 dans la description
							$insertCheckboxId=str_replace("addAttachedFile","addAttachedFileInsert",$inputId);
							if(static::htmlEditorField!=null && Req::isParam($insertCheckboxId) && File::controlType("attachedFileInsert",$curFile["name"])){
								$newEditorValue=Db::getVal("SELECT ".static::htmlEditorField." FROM ".static::dbTable." WHERE _id=".$this->_id).self::attachedFileInsert($attachedFileId,false);
								Db::query("UPDATE ".static::dbTable." SET ".static::htmlEditorField."=".Db::format($newEditorValue,"editor")." WHERE _id=".$this->_id);
							}
							$curDatasFolderSize+=$curFile["size"];
						}
					}
				}
			}
			File::datasFolderSize(true);//Recalcule $_SESSION["datasFolderSize"]
		}
	}

	/*
	 * Supprime un fichier joint
	 */
	public function deleteAttachedFile($curFile)
	{
		if($this->editRight() && is_array($curFile)){
			File::rm($curFile["path"]);
			if(!is_file($curFile["path"])){
				Db::query("DELETE FROM ap_objectAttachedFile WHERE _id=".(int)$curFile["_id"]);
				return true;
			}
		}
	}

	/*
	 * Affiche l'auteur de l' objet
	 */
	public function displayAutor($creaAutor=true, $tradAutor=false)
	{
		$labelAutor=($tradAutor==true) ? Txt::trad("autor")." : ": null;
		if(!empty($this->guest))			{return $labelAutor.$this->guest." (".Txt::trad("guest").")";}				//Invité
		elseif($creaAutor==true)			{return $labelAutor.Ctrl::getObj("user",$this->_idUser)->display();}		//Créateur
		elseif(!empty($this->_idUserModif))	{return $labelAutor.Ctrl::getObj("user",$this->_idUserModif)->display();}	//Dernier user modif.
	}

	/*
	 * Affiche la date de création OU modif
	 */
	public function displayDate($getDateCrea=true, $format="normal")
	{
		if($getDateCrea==true)	{return Txt::displayDate($this->dateCrea,$format);}
		else					{return Txt::displayDate($this->dateModif,$format);}
	}

	/*
	 * Traduction avec changement des libelles -ELEMENT- et -CONTENEUR- par ceux des objets concernés
	 */
	public function tradObject($tradKey)
	{
		//Traduction de base
		$tradBase=Txt::trad($tradKey);
		//Traduction des "-ELEMENT-"
		if(static::isContainer()==false)	{$tradBase=str_replace("-ELEMENT-",Txt::trad("OBJECTelement"),$tradBase);}
		else{
			$MdlObjectContent=static::MdlObjectContent;
			if(Txt::isTrad("OBJECT".$MdlObjectContent::objectType))	{$tradBase=str_replace("-ELEMENT-",Txt::trad("OBJECT".$MdlObjectContent::objectType),$tradBase);}
		}
		//Traduction des "-CONTENEUR-"
		if(static::isFolder)								{$tradBase=str_replace("-CONTENEUR-", Txt::trad("OBJECTfolder"), $tradBase);}
		elseif(Txt::isTrad("OBJECT".static::objectType))	{$tradBase=str_replace("-CONTENEUR-", Txt::trad("OBJECT".static::objectType), $tradBase);}
		else												{$tradBase=str_replace("-CONTENEUR-", Txt::trad("OBJECTcontainer"), $tradBase);}
		// Retour
		return $tradBase;
	}
}