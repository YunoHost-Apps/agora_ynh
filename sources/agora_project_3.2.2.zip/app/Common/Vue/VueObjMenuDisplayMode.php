<div class="menuLine">
	<div class="menuIcon"><img src="app/img/display<?= ucfirst($displayMode) ?>.png"></div>
	<div>
		<span class="menuLaunch" for="vMenuDisplayMode"><?= Txt::trad("displayMode")." ".Txt::trad("displayMode_".$displayMode) ?></span>
		<div  class="contextMenu" id="vMenuDisplayMode">
			<?php foreach($displayModeOptions as $tmpDisplay){ ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/display<?= ucfirst($tmpDisplay) ?>.png"></div><div><a onclick="redir('<?= $displayModeUrl.$tmpDisplay ?>')" <?= $displayMode==$tmpDisplay?"class='sLinkSelect'":null ?>><?= Txt::trad("displayMode_".$tmpDisplay) ?></a></div></div>
			<?php } ?>
		</div>
	</div>
</div>