<?php
////	LAUNCHER INLINE/BLOCK
if(!empty($inlineLauncher))  {echo "<img src='app/img/menuSmall.png' class='menuLaunch' for=\"".$curObj->contextMenuId("menu")."\">";}
else
{
	echo "<div class='menuLaunch menuLaunchObj' for=\"".$curObj->contextMenuId("menu")."\">";
		echo "<label><img src='app/img/menu.png'></label>";
		if($curObj::isSelectable)				{echo "<input type='checkbox' name='targetObjects[]' value=\"".$curObj->_targetObjId."\" id=\"".$curObj->contextMenuId("block")."_selectBox\">";}//BOX DE SELECTION D'OBJET
		if(!empty($isPersoAccess))				{echo "<br><img src='app/img/user/accesPerso.png' title=\"".Txt::trad("personalAccess")."\">";}//ACCES PERSO
		if(!empty($newObjectSinceConnection))	{echo "<br><img src='app/img/newObj.png'>";}//NOUVEL OBJET
	echo "</div>";
}

////	MENU
echo "<div id=\"".$curObj->contextMenuId("menu")."\" class='contextMenu'>";

	////	SELECTION/DESELECTION
	if($curObj::isSelectable && $curObj::objectType!="user" && empty($inlineLauncher) && Tool::isMobile()==false)
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"objSelect('".$curObj->contextMenuId("block")."')\"><div class='menuIcon'><img src='app/img/check.png'></div><div>".Txt::trad("selectUnselect")."</div></div>";}

	////	MODIFIER
	if(!empty($editLabel))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".$curObj->getUrl("edit")."')\"><div class='menuIcon'><img src='app/img/edit.png'></div><div>".$editLabel."</div></div>";}

	////	USER : MODIF MESSENGER
	if(!empty($editMessengerObjUrl))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".$editMessengerObjUrl."')\"><div class='menuIcon'><img src='app/img/messenger.png'></div><div>".Txt::trad("USER_editMessenger")."</div></div>";}

	////	CHANGER DE DOSSIER
	if(!empty($moveObjectUrl))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".$moveObjectUrl."')\"><div class='menuIcon'><img src='app/img/folderMove.png'></div><div>".Txt::trad("changeFolder")."</div></div>";}
	
	////	HISTORIQUE/LOGS
	if(!empty($logUrl))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".$logUrl."')\"><div class='menuIcon'><img src='app/img/log.png'></div><div>".Txt::trad("objHistory")."</div></div>";}

	////	USER : SUPPRIMER DE L'ESPACE
	if(!empty($deleteFromCurSpaceConfirmRedir))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"".$deleteFromCurSpaceConfirmRedir."\"><div class='menuIcon'><img src='app/img/delete.png'></div><div>".Txt::trad("USER_deleteFromSpace")."</div></div>";}

	////	SUPPRIMER
	if(!empty($deleteLabel))
		{$mainMenu=true;	echo "<div class='menuLine sLink' onclick=\"".$deleteConfirmRedir."\"><div class='menuIcon'><img src='app/img/delete.png'></div><div>".$deleteLabel."</div></div>";}

	////	SEPARATEUR
	if(!empty($mainMenu))	{echo "<hr>";}

	////	DIVERSES OPTIONS (MENU PRINCIPAL)
	foreach($specificOptions as $tmpOption){
		$actionJsTmp=(!empty($tmpOption["actionJs"])) ?  'onclick="'.$tmpOption["actionJs"].'"'  :  null;
		$tooltipTmp =(!empty($tmpOption["tooltip"]))  ?  'title="'.$tmpOption["tooltip"].'"'  :  null;
		$iconSrcTmp =(!empty($tmpOption["iconSrc"]))  ?  '<div class="menuIcon"><img src="app/img/'.$tmpOption["iconSrc"].'"></div>'  :  null;
		if(empty($iconSrcTmp))  {$tmpOption["label"]="<span class='menuLineSpecificLabel'>".$tmpOption["label"]."</span>";}
		echo "<div class='menuLine sLink' ".$actionJsTmp." ".$tooltipTmp.">".$iconSrcTmp."<div>".$tmpOption["label"]."</div></div>";
	}

	////	SEPARATEUR
	if(!empty($specificOptions))	{echo "<hr>";}

	////	DOSSIER : CONTENU (nombre d'elements + taille (module fichiers))
	if($curObj::isFolder==true)
		{echo "<div class='menuLine'><div class='menuTxtLeft'>".Txt::trad("folderContent")."</div><div>".$curObj->folderContentDescription()."</div></div><hr>";}

	////	USER : ESPACES AFFECTES A L'UTILISATEUR
	if(!empty($userSpaceList))
		{echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/space.png'></div><div>".$userSpaceList."</div></div>";}

	////	USER : USER/ADMIN
	if($curObj::objectType=="user" && $curObj->isAdminCurSpace()){
		if($curObj->isAdminGeneral())	{echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/user/adminGeneral.png'></div><div>".Txt::trad("USER_adminGeneral")."</div></div>";}
		else							{echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/user/adminSpace.png'></div><div>".Txt::trad("USER_adminSpace")."</div></div>";}
	}

	////	AFFECTATIONS
	if(!empty($affectLabels["2"]))		{echo "<div class='menuLine sAccessWrite cursorHelp' title=\"".$affectTooltips["2"]."\"><div class='menuTxtLeft'>".Txt::trad("accessWrite")."</div><div>".$affectLabels["2"]."</div></div>";}
	if(!empty($affectLabels["1.5"]))	{echo "<div class='menuLine sAccessWriteLimit cursorHelp' title=\"".$affectTooltips["1.5"]."\"><div class='menuTxtLeft'>".Txt::trad("accessWriteLimit")."</div><div>".$affectLabels["1.5"]."</div></div>";}
	if(!empty($affectLabels["1"]))		{echo "<div class='menuLine sAccessRead cursorHelp' title=\"".$affectTooltips["1"]."\"><div class='menuTxtLeft'>".Txt::trad("accessRead")."</div><div>".$affectLabels["1"]."</div></div>";}

	////	SEPARATEUR
	if(!empty($affectLabels))  {echo "<hr>";}

	////	AUTEUR & DATE
	if(!empty($infosCrea))
	{
		echo "<div class='menuLine sLink' ".(!empty($curObj->_idUser) ? Ctrl::getObj("user",$curObj->_idUser)->displayUserVue() : null).">
				<div class='menuTxtLeft'>".Txt::trad("creation")."</div>
				<div>".$infosCrea["autor"].$infosCrea["date"].(!empty($newObjectSinceConnection)?"<br><abbr title=\"".Txt::trad("objNewInfos")."\">".Txt::trad("objNew")." <img src='app/img/newObj.png'></abbr>":null)."</div>
			  </div>";
	}

	////	MODIF & DATE
	if(!empty($infosModif))
		{echo "<div class='menuLine sLink' ".Ctrl::getObj("user",$curObj->_idUserModif)->displayUserVue()."><div class='menuTxtLeft'>".Txt::trad("modification")."</div><div>".$infosModif["autor"].$infosModif["date"]."</div></div>";}

	////	FICHIERS JOINTS
	echo $curObj->menuAttachedFiles();

echo "</div>";