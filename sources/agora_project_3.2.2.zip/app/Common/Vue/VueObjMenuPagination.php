<div class="navContainer">
	<div class="navMenu sBlock">
		<?php
		////	PRECEDENT / NUMÉROS DE PAGE / SUIVANT
		echo "<a ".$previousAttr."><img src='app/img/navPrevious.png'></a>";
		for($pageNbTmp=1; $pageNbTmp<=$pageNbTotal; $pageNbTmp++)
			{echo "<a href=\"".$hrefBase.$pageNbTmp."\" class=\"".($pageNb==$pageNbTmp?"sLinkSelect":"sLink")."\" title=\"".Txt::trad("goToPage")." ".$pageNbTmp."\">".$pageNbTmp."</a>";}
		echo "<a ".$nextAttr."><img src='app/img/navNext.png'></a>";
		?>
	</div>
</div>