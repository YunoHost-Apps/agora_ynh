<script type="text/javascript">
$(function(){
	////	ONGLETS / OPTIONS (chaque onglet ".objMenuLabel" doit avoir un "for" correspondant à l'Id de son div)
	if($("#objMenuLabels").exist())
	{
		//Change de menu
		$(".objMenuLabel").click(function(){
			//Réinit les autres menus
			$(".objMenuLabel").not(this).each(function(){
				$("#"+$(this).attr("for")).hide();
				$(this).addClass("objMenuLabelUnselect");
			});
			//Affiche le block sélectionné
			$("#"+$(this).attr("for")).show();//affichage direct, pas "fadeIn" (cf. "lightboxResize()")
			$(this).removeClass("objMenuLabelUnselect");
		});
		//Affiche le menu du premier onglet
		$(".objMenuLabel:first-child").trigger("click");
	}
	
	////	AFFECTATIONS : CLICK DE LABEL
	$("[id^='spaceBlock']:visible .vSpaceLabel").click(function(){
		//Init
		var boxRead		 ="#objectRightBox_"+this.id+"_1";
		var boxWriteLimit="#objectRightBox_"+this.id+"_15";
		var boxWrite	 ="#objectRightBox_"+this.id+"_2";
		var boxToCheck=null;
		//Bascule les checkbox : lecture / ecriture limité / écriture
		if(!$(boxRead).prop("disabled") && !$(boxRead).prop("checked") && !$(boxWriteLimit).prop("checked") && !$(boxWrite).prop("checked"))	{boxToCheck=boxRead;}		//"1" actif && tout est décochées
		else if(!$(boxWriteLimit).prop("disabled") && !$(boxWriteLimit).prop("checked") && !$(boxWrite).prop("checked"))						{boxToCheck=boxWriteLimit;}	//"1.5" actif && "1.5" décoché && "2" décoché
		else if(!$(boxWrite).prop("disabled")  &&  !$(boxWrite).prop("checked")  &&  ( ($(boxRead).prop("disabled") && $(boxWriteLimit).prop("disabled")) || ($(boxRead).prop("checked") && $(boxWriteLimit).prop("disabled")) || $(boxWriteLimit).prop("checked")))	{boxToCheck=boxWrite;}	//"2" actif && "2" décoché &&  ( ("1" inatif & "1.5" inatif) || ("1" coché & "1.5" inactif) || "1.5" coché)
		//Check la box sélectionnée (avec trigger sur la box)  OU  Uncheck toutes les boxes et Stylise toute la sélection
		if(boxToCheck!=null)	{$(boxToCheck).prop("checked",true).trigger("change");}
		else					{$("[id^='objectRightBox_"+this.id+"']").prop("checked",false);  labelStyleRightControl();}
	});

	////	AFFECTATIONS : CLICK DE CHECKBOX
	$("[id^='spaceBlock']:visible [id^='objectRightBox']").change(function(){
		var objectRight=$(this).val();
		var targetId=objectRight.slice(0, objectRight.lastIndexOf("_"));//exple "1_U2_1.5" => "1_U2"
		$("[id^='objectRightBox_"+targetId+"']").not(this).prop("checked",false);//"uncheck" les autres checkbox du "target"
		labelStyleRightControl(this.id);//Style des labels & Controle des droits
	});

	////	SELECTIONNE UN NOUVEAU FICHIER JOINT
	$("input[name^='addAttachedFile']").change(function(){
		//Fichier OK : affiche l'input suivant et affiche au besoin "insertion dans le text" (+ Check par défaut)
		if($(this).isEmpty()==false && this.files[0].size < <?= File::uploadMaxFilesize() ?>)
		{
			var cptFile=Math.round(this.name.replace("addAttachedFile",""));
			var fileExtension=extension($(this).val());
			$("#addAttachedFile"+(cptFile+1)).fadeIn();
			if($("#addAttachedFileOptions"+cptFile).exist() && $.inArray(fileExtension,['<?= implode("','",File::fileTypes("attachedFileInsert")) ?>'])!==-1){
				$("#addAttachedFileOptions"+cptFile).css("display","inline-block");
				$("#addAttachedFileInsert"+cptFile+":not(:checked)").trigger("click");
			}
		}
	});

	////	AFFICHE/MASQUE LES BLOCKS D'ESPACES
	//Masque les espaces sans affectations (sauf espace courant)
	$("[id^='spaceBlock']").each(function(){
		if(this.id!="spaceBlock<?= Ctrl::$curSpace->_id ?>" && $("#"+this.id+" [name='objectRight[]']:checked").length==0)	{$(this).css("display","none");}
	});
	//montre "Afficher tous les espaces"?
	if($("[id^='spaceBlock']:hidden").length>0)  {$("#showAllSpaces").fadeIn().effect("pulsate",{times:4},4000);}
	//Click sur "Afficher tous les espaces"
	$("#showAllSpaces").click(function(){
		$("#showAllSpaces").css("display","none");
		$("[id^='spaceBlock']").fadeIn();
	});

	////	INIT LA PAGE
	//Masque et désactive les droits "boxWriteLimit"
	<?php if($curObj::isContainer()==false){ ?>
		$("[name='objectRight[]'][value$='_1.5']").prop("disabled",true);
		$(".vSpaceWriteLimit").css("display","none");
	<?php } ?>
	//Init le style des labels
	labelStyleRightControl();
	//Fixe la hauteur minimum : évite à "lightboxResize()" de jouer si on passe d'un gros menu à un plus petit..
	$("#objMenuBlocks").css("min-height",$("#objMenuBlocks").height());
	//Focus sur le premier champ obligatoire (fin de text)
	<?php if(!empty($curObj::$requiredFields) && Tool::isMobile()==false)  {echo "$('input[name=".$curObj::$requiredFields[0]."]').focus().val($('input[name=".$curObj::$requiredFields[0]."]').val());";} ?>
});

////	STYLISE LES LABELS ET CONTROLE LES DROITS D'ACCÈS
function labelStyleRightControl(boxId)
{
	notifFullAccess=null;
	//Réinitialise les class des lignes et labels
	$("[id^='spaceBlock']:visible .vSpaceLabel").removeClass("sAccessRead sAccessWriteLimit sAccessWrite");
	$("[id^='spaceBlock']:visible [id^=targetLine]").removeClass("sTableRowSelect");
	//Stylise les labels des checkbox sélectionnées
	$(":checkbox[name='objectRight[]']:checked").each(function(){
		//Récupère le droit de la checkbox && l'id du label correspondant
		var targetRight=this.id.split('_').pop();
		var targetLabelId=this.id.substring(0, this.id.lastIndexOf('_')).replace('objectRightBox_','');
		//Stylise le label
		if(targetRight=="1")		{$("#"+targetLabelId).addClass("sAccessRead");}
		else if(targetRight=="15")	{$("#"+targetLabelId).addClass("sAccessWriteLimit");}
		else if(targetRight=="2")	{$("#"+targetLabelId).addClass("sAccessWrite");}
		//Ligne sélectionnée : surligne
		$("#targetLine"+targetLabelId).addClass("sTableRowSelect");
		//Sujet du forum : affiche si besoin "Le droit en écriture permet d'effacer tous les messages du sujet!"
		if("<?= $curObj::objectType ?>"=="forumSubject" && notifFullAccess==null && targetRight=="2" && targetLabelId!="2_U<?= Ctrl::$curUser->_id ?>")
			{notifFullAccess=true;  notify("<?= Txt::trad("EDIT_notifWriteAdvice") ?>");}
	});
	//Control Ajax d'une affectation (droit d'accès) pour un sous dossier
	<?php if($curObj::isFolder && $curObj->containerObj()->isRootFolder()==false){ ?>
	if(typeof boxId!="undefined" && $("#"+boxId).prop("checked"))
	{
		var ajaxUrl="?ctrl=object&action=AccessRightParentFolder&targetObjId=<?= Ctrl::getObj($curObj::objectType,$curObj->_idContainer)->_targetObjId ?>&objectRight="+$("#"+boxId).val();
		$.ajax({url:ajaxUrl,dataType:"json"}).done(function(ajaxResult){
			if(typeof ajaxResult.error!="undefined")	{notify(ajaxResult.message);}
		});
	}
	<?php } ?>
}

////	SUPPRESSION D'UN FICHIER JOINT
function deleteAttachedFile(_id)
{
	if(confirm("<?= Txt::trad("confirmDelete") ?>")){
		var ajaxUrl="?ctrl=object&action=deleteAttachedFile&_id="+_id;
		var ajaxResult=$.ajax({url:ajaxUrl,async:false}).responseText;//Attend la réponse Ajax pour passer à la suite (async:false)
		if(find("true",ajaxResult)){
			$("#menuAttachedFile"+_id).fadeOut();
			tinymce.activeEditor.dom.remove("tagAttachedFile"+_id);//pas besoin de "#" pour select l'id
		}
	}
}

////	CONTROLE FINAL DU FORMULAIRE
function finalFormControl()
{
	//Init
	var validForm=true;
	////	Verif des champs obligatoires (s'ils sont spécifiés)
	var notifRequiredFields="";
	<?php foreach($curObj::$requiredFields as $tmpField){?>
	var isEmptyField=<?= ($tmpField==$curObj::htmlEditorField)  ?  "isEmptyEditor('".$curObj::htmlEditorField."');"  :  "$(\"[name='".$tmpField."']\").isEmpty();" ?>//champs tinyMce OU input "text"
	if($("[name='<?= $tmpField ?>']").exist() && isEmptyField==true){
		validForm=false;
		notifRequiredFields+="<br><?= Txt::trad($tmpField) ?>";
		$("[name='<?= $tmpField ?>']").focusRed();
	}
	<?php } ?>
	////	Notif pour les champs obligatoires vides
	if(notifRequiredFields.length>0)	{notify("<?= Txt::trad("requiredFields") ?> : "+notifRequiredFields);}
	////	Controle le formatage des dates
	$(".dateInput,.dateBegin,.dateEnd").each(function(){
		if(this.value.length>0){
			var dateMatch=/^\d{2}\/\d{2}\/\d{4}$/.exec(this.value);
			if(dateMatch==null)   {validForm=false;  notify("<?= Txt::trad("dateFormatError") ?>");}
		}
	});
	////	Controle d'un invité
	if($("[name='guest']").exist()){
		if($("[name='guest']").isEmpty())	{validForm=false;  notify("<?= Txt::trad("EDIT_notifGuest") ?>");}
		else if(captchaControl()==false)	{validForm=false;}
	}
	////	Controle les affectations
	if($("[name='objectRight[]']").length>0)
	{
		//Aucune affectation : false
		if($(":checked[name='objectRight[]']").length==0)	{validForm=false;  notify("<?= Txt::trad("EDIT_notifNoSelection") ?>");}
		//Sujet du forum et uniquement des accès en lecture : false!
		if("<?= $curObj::objectType ?>"=="forumSubject" && $(":checked[name='objectRight[]'][value$='_1.5'], :checked[name='objectRight[]'][value$='_2']").length==0)
			{validForm=false;  notify("<?= Txt::trad("EDIT_notifWriteAccess") ?>");}
		//Aucun accès pour l'user courant?
		var nbCurUserAccess=$(":checked[name='objectRight[]'][value*='spaceGuests'], :checked[name='objectRight[]'][value*='spaceUsers'], :checked[name='objectRight[]'][value*='allSpaces'], :checked[name='objectRight[]'][value*='_U<?= Ctrl::$curUser->_id ?>_']").length;
		if(nbCurUserAccess==0 && confirm("<?= Txt::trad("EDIT_notifNoPersoAccess") ?>")==false)	{validForm=false;}
	}
	////	Controle un mail (si besoin)
	if($("input[name='mail']").isEmpty()==false && !isMail($("input[name='mail']").val()))   {validForm=false;  notify("<?= Txt::trad("mailInvalid"); ?>");}
	////	Controle OK
	if(validForm==true)  {$(".loadingImg").css("display","block");}
	return validForm;
}
</script>

<style>
/*OPTIONS D'EDITION (ex 'fieldset')*/
[id^='blockOpt']			{text-align:left;}
#objMenuBlocks				{text-align:left;}
#objMenuLabels				{display:table; width:100%; margin:22px 0px -22px 0px;}
.objMenuLabel				{display:table-cell; padding:6px 4px 6px 4px; text-align:center; cursor:pointer; border-radius:3px 3px 0px 0px;}
.objMenuLabel:not(.objMenuLabelUnselect)	{border-bottom:none!important;}
.objMenuLabelUnselect		{opacity:0.7;}
.objMenuLabel img			{max-height:18px;}
.objMenuLabel img[src*='check']	{max-height:15px; float:right;}
/*RESPONSIVE -> 490px!*/
@media screen and (max-width:490px){
	.objMenuLabel img	{display:none;}
}

/*DROITS D'ACCÈS*/
#objMenuMain				{text-align:center;}
[id^='spaceBlock']			{max-height:165px; overflow-y:auto;}
.vSpaceTable				{display:inline-table; vertical-align:middle;}
.vSpaceTable img			{max-height:15px;}
.vSpaceTable>div			{display:table-row;}
.vSpaceTable>div>div		{display:table-cell; padding:2px;}
.vSpaceTable .vSpaceLabel	{min-width:220px; cursor:pointer; text-align:left;}
.vSpaceTitle>div			{cursor:help; padding-bottom:8px!important;}
.vSpaceRead, .vSpaceWrite, .vSpaceWriteLimit	{width:80px; text-align:center;}
.vSpaceWriteLimit			{width:130px;}
.vSpaceTarget img[src*='dot']		{max-height:12px;}
.vSpaceWriteLimit img[src*='edit']	{opacity:0.6;}
.vRightsOptions				{margin:10px;}
#showAllSpaces				{display:none; cursor:pointer; text-align:center; margin-top:10px;}
/*RESPONSIVE -> 490px!*/
@media screen and (max-width:490px){
	.vSpaceTable				{width:100%; font-size:95%;}
	.vSpaceTable .vSpaceLabel	{min-width:160px;}
	.vSpaceTitle img			{display:none;}
	.vSpaceRead, .vSpaceWrite, .vSpaceWriteLimit	{width:60px!important;}
}

/*FICHIERS JOINTS*/
[id^='addAttachedFile']				{display:none; margin:5px;}
[id^='addAttachedFile']:first-child	{display:block;}
[id^='addAttachedFileOptions']		{display:none;}
[id^='menuAttachedFile']			{margin:10px;}

/*NOTIFICATION PAR MAIL*/
#notifMailUsersPlus, #notifMailUsersPlusList, .notifMailUserPlusHidden, .notifMailOptions	{display:none;}
.notifMailOptions	{float:right; text-align:right;}
</style>


<?php
////	INITIALISE L'EDITEUR HTML D'UN CHAMP (description ou autre) ?
if($curObj::htmlEditorField!==null)  {echo CtrlMisc::initHtmlEditor($curObj::htmlEditorField);}

////	CONTENU DES MENUS
if(!empty($mainMenu) || !empty($attachedFiles) || !empty($notifMail) || !empty($shortcut))
{
	////	ONGLETS DES MENUS
	echo "<div id='objMenuLabels'>";
		if($mainMenu!=false)		{echo "<div class='objMenuLabel noSelect' for='objMenuMain'><img src='app/img/edit.png'> ".$mainMenuLabel." ".($curObj::isContainer()?"<img src='app/img/info.png' title=\"".$curObj->tradObject("autorPrivilege")."\">":null)."</div>";}
		if(!empty($notifMail))		{echo "<div class='objMenuLabel noSelect' for='objMenuNotifMail' title=\"".Txt::trad("EDIT_notifMailInfo")."\"><img src='app/img/mail.png'> ".Txt::trad("EDIT_notifMail")."</div>";}
		if(!empty($attachedFiles))	{echo "<div class='objMenuLabel noSelect' for='objMenuAttachedFiles' title=\"".Txt::trad("EDIT_attachedFileInfo")."\"><img src='app/img/attachment.png'> ".Txt::trad("EDIT_attachedFile").(!empty($attachedFilesList)?"<img src='app/img/check.png'>":null)."</div>";}
		if(!empty($shortcut))		{echo "<div class='objMenuLabel noSelect' for='objMenuShortcut' title=\"".Txt::trad("EDIT_shortcutInfo")."\"><img src='app/img/shortcut.png'> ".Txt::trad("EDIT_shortcut").(!empty($shortcutChecked)?"<img src='app/img/check.png'>":null)."</div>";}
	echo "</div>";

	////	OPTIONS D'EDITION
	echo "<div id='objMenuBlocks' class='lightboxBlock'>";

		////	MENU PRINCIPAL : DROITS D'ACCES
		if(!empty($mainMenu))
		{
			echo "<div id='objMenuMain'>";
				//MENU GUEST : IDENTIFICATION
				if($mainMenu=="identification")  {echo Txt::trad("EDIT_guest")." <input type='text' name='guest' onkeyup=\"this.value=this.value.slice(0,150)\"><hr>".CtrlMisc::menuCaptcha();}

				//MENU USER : (OBJETS INDEPENDANTS)
				if($mainMenu=="accessRights")
				{
					//DROIT D'ACCES DES BLOCK D'ESPACES
					foreach($blocksAccessRight as $spaceCpt=>$tmpSpace)
					{
						echo "<div id='spaceBlock".$tmpSpace->_id."'>".($spaceCpt>0?"<hr>":null);
							echo "<div class='vSpaceTable'>";
								//ENTETE DE L'ESPACE
								if($tmpSpace->curModuleEnabled==false)	{$tmpSpace->name=$tmpSpace->name." <img src='app/img/important.png' title=\"".Txt::trad("EDIT_spaceNoModule")."\">";}
								echo "<div class='vSpaceTitle'>
										<div class='vSpaceLabel' title=\"".$tmpSpace->description."\">".$tmpSpace->name."</div>
										<div class='vSpaceRead' title=\"".Txt::trad("readInfos")."\">".Txt::trad("accessRead")." <img src='app/img/eye.png'></div>
										<div class='vSpaceWriteLimit' title=\"".$WriteLimitInfos."\">".Txt::trad("accessWriteLimit")." <img src='app/img/edit.png'></div>
										<div class='vSpaceWrite' title=\"".Txt::trad("writeInfos")."\">".Txt::trad("accessWrite")." <img src='app/img/edit.png'></div>
									  </div>";
								//TARGETS DE L'ESPACE (NE PAS AJOUTER D'ID AU CHECKBOXES. CF. "boxProp")
								foreach($tmpSpace->targetsLines as $tmpTarget)
								{
									$tmpTarget["tooltip"]=(!empty($tmpTarget["tooltip"]))  ?  "title=\"".Txt::reduce($tmpTarget["tooltip"],400)."\""  :  null;
									$tmpTarget["labelIcon"]=(!empty($tmpTarget["labelIcon"]))  ?  "<img src='app/img/".$tmpTarget["labelIcon"]."'>"  :  null;
									$tmpTarget["labelIconBis"]=(!empty($tmpTarget["labelIconBis"]))  ?  "<img src='app/img/".$tmpTarget["labelIconBis"]."'>"  :  null;
									echo "<div class='vSpaceTarget sTableRow sAccessDefault' id=\"targetLine".$tmpTarget["targetId"]."\">
											<div class='vSpaceLabel' id=\"".$tmpTarget["targetId"]."\" ".$tmpTarget["tooltip"].">".$tmpTarget["labelIcon"]." ".$tmpTarget["labelText"]." ".$tmpTarget["labelIconBis"]."</div>
											<div class='vSpaceRead' title=\"".Txt::trad("readInfos")."\"><input type='checkbox' name='objectRight[]' ".$tmpTarget["boxProp"]["1"]."></div>
											<div class='vSpaceWriteLimit' title=\"".$WriteLimitInfos."\"><input type='checkbox' name='objectRight[]' ".$tmpTarget["boxProp"]["1.5"]."></div>
											<div class='vSpaceWrite' title=\"".Txt::trad("writeInfos")."\"><input type='checkbox' name='objectRight[]' ".$tmpTarget["boxProp"]["2"]."></div>
										  </div>";
								}
							echo "</div>";
						echo "</div>";
					}
					////	"AFFICHER TOUS LES ESPACES"
					if(count($blocksAccessRight)>1)  {echo "<div id='showAllSpaces'>".Txt::trad("EDIT_mySpaces")." <img src='app/img/arrowBottom.png'></div>";}
					////	ETENDRE LES DROITS AUX SOUS-DOSSIERS / INFOS SUR LES DROITS D'ACCES DES SUJETS
					if(!empty($extendToSubfolders))  {echo "<hr><div class='vRightsOptions'><label for='extendToSubfolders' title=\"".Txt::trad("EDIT_accessRightSubFolders_info")."\">".Txt::trad("EDIT_accessRightSubFolders")."</label><input type='checkbox' name='extendToSubfolders' id='extendToSubfolders' value='1'></div>";}
					if($curObj::objectType=="forumSubject")  {echo "<hr><div class='vRightsOptions'><img src='app/img/important.png'> ".Txt::trad("FORUM_accessRightInfos")."</div>";}
				}
			echo "</div>";
		}

		////	MENU FICHIER JOINTS
		if(!empty($attachedFiles))
		{
			echo "<div id='objMenuAttachedFiles'>";
				//Fichiers à ajouter (10 maxi)
				for($cptFile=1; $cptFile<=10; $cptFile++){
					$attachedFileOptions=($curObj::htmlEditorField!==null)  ?  "<div id=\"addAttachedFileOptions".$cptFile."\" title=\"".Txt::trad("EDIT_fileInsertInfo")."\"><img src='app/img/arrowRight.png'> <label for=\"addAttachedFileInsert".$cptFile."\">".Txt::trad("EDIT_fileInsert")."</label><input type='checkbox' name=\"addAttachedFileInsert".$cptFile."\" id=\"addAttachedFileInsert".$cptFile."\" value='1'><img src='app/img/attachmentInsertText.png'></div>"  :  null;
					echo "<div id=\"addAttachedFile".$cptFile."\"><input type='file' name=\"addAttachedFile".$cptFile."\">".$attachedFileOptions."</div>";
				}
				//Fichiers déjà enregistrés
				if(!empty($attachedFilesList))	{echo "<hr>";}
				foreach($attachedFilesList as $tmpFile){
					$deleteOrInsertText="<img src='app/img/delete.png' class='sLink' title=\"".Txt::trad("delete")."\" onclick=\"deleteAttachedFile(".$tmpFile["_id"].");\">&nbsp;";
					if($curObj::htmlEditorField!==null && File::controlType("attachedFileInsert",$tmpFile["name"]))   {$deleteOrInsertText.="<img src='app/img/attachmentInsertText.png' class='sLink' title=\"".Txt::trad("EDIT_fileInsertInfo")."\" ".MdlObject::attachedFileInsert($tmpFile["_id"],true).">&nbsp;";}
					echo "<div id=\"menuAttachedFile".$tmpFile["_id"]."\">".$deleteOrInsertText." ".$tmpFile["name"]."</div>";
				}
			echo "</div>";
		}

		////	MENU NOTIFICATIONS PAR MAIL
		if(!empty($notifMail))
		{
			echo "<div id='objMenuNotifMail'>
					<label for='boxNotifMail' title=\"".Txt::trad("EDIT_notifMailInfo")."\"> ".Txt::trad("EDIT_notifMail2")."</label>
					<input type='checkbox' name='notifMail' id='boxNotifMail' value='1' onChange=\"$('#notifMailUsersPlus,.notifMailOptions').slideToggle();\">
					<img src='app/img/plus.png' id='notifMailUsersPlus' class='sLink' title=\"".Txt::trad("EDIT_notifMailSelect")."\" onclick=\"$('#notifMailUsersPlusList').slideToggle();\">";
				//OPTIONS DU MAIL
				echo "<div class='notifMailOptions'>";
					//MONTRER LES DESTINATAIRES DANS LE MESSAGE
					echo "<div>
							<label for='boxhideRecipients' title=\"".Txt::trad("MAIL_hideRecipientsInfo")."\">".Txt::trad("MAIL_hideRecipients")."</label>
							<input type='checkbox' name='hideRecipients' id='boxhideRecipients' value='1'>
						  </div>";
					//ACCUSE DE RECEPTION
					echo "<div>
							<label for='boxReceptionNotif' title=\"".Txt::trad("MAIL_receptionNotifInfo")."\">".Txt::trad("MAIL_receptionNotif")."</label>
							<input type='checkbox' name='receptionNotif' id='boxReceptionNotif' value='1'>
						  </div>";
					//JOINDRE L'OBJET FICHIER A LA NOTIFICATION ?
					if($curObj::objectType=="file" && $curObj->_id==0){
						echo "<div>
								<label for='boxNotifMailAddFiles' title=\"".Txt::trad("FILE_fileSizeLimit")." ".File::displaySize(File::mailMaxFilesSize)."\">".Txt::trad("EDIT_notifMailAddFiles")."</label>
								<input type='checkbox' name='notifMailAddFiles' id='boxNotifMailAddFiles' value='1'>
							</div>";
					}
				echo "</div>";
				//LISTE DETAILLE DES UTILISATEURS (masque d'abord les users absent de l'espace courant)
				echo "<div id='notifMailUsersPlusList'>";
					foreach($notifMailUsers as $tmpUser){
						$tmpClassMail=(!in_array($tmpUser->_id,$notifMailCurSpaceUsersIds))  ?  "class='notifMailUserPlusHidden'"  :  null;
						echo "<div id=\"divNotifMailUser".$tmpUser->_id."\" ".$tmpClassMail."><input type='checkbox' name='notifMailUsers[]' value=\"".$tmpUser->_id."\" id=\"boxNotifMailUsers".$tmpUser->_id."\"><label for=\"boxNotifMailUsers".$tmpUser->_id."\" title=\"".$tmpUser->mail."\">".$tmpUser->display()."</label></div>";
					}
					if(count($notifMailUsers)>count($notifMailCurSpaceUsersIds))	{echo "<p onclick=\"$('[id^=divNotifMailUser]').fadeIn();$(this).fadeOut();\" class='sLink'>".Txt::trad("EDIT_notifMailMoreUsers")."</p>";}
				echo "</div>";
			echo "</div>";
		}

		////	MENU RACCOURCIS
		if(!empty($shortcut)){
			echo "<div id='objMenuShortcut'>
					<label for='boxShortcut'><img src='app/img/shortcut.png'> ".Txt::trad("EDIT_shortcutInfo")."</label>
					<input type='checkbox' name='shortcut' id='boxShortcut' value='1' ".$shortcutChecked.">
				  </div>";
		}
	echo "</div>";
}

////	VALIDATION & INPUTS HIDDEN DU FORMULAIRE & ICONE "LOADING"
echo Txt::formValidate();
if(!empty($curObj->_idContainer))	{echo "<input type='hidden' name='_idContainer' value=\"".$curObj->_idContainer ."\">";}
echo "<div class='loadingImg'><img src='app/img/loading.gif'></div>";
?>