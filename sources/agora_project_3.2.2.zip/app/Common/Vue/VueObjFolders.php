<style>
.folderContentDescription	{display:inline-block; line-height:25px; margin-left:20px;}
</style>

<?php foreach($foldersList as $tmpFolder){ ?>
	<?= $tmpFolder->divContainer($objContentCenterClass).$tmpFolder->contextMenu(); ?>
		<div class="objContent">
			<div class="objIcon"><a href="<?= $tmpFolder->getUrl() ?>"><img src="app/img/folder.png"></a></div>
			<div class="objLabel"><a href="<?= $tmpFolder->getUrl() ?>" title="<?= $tmpFolder->description ?>"><?= Txt::reduce($tmpFolder->name,70) ?></a></div>
			<div class="objDetails"><?= $tmpFolder->folderOtherDetails() ?><div class="folderContentDescription"><?= $tmpFolder->folderContentDescription() ?></div></div>
		</div>
	</div>
<?php } ?>