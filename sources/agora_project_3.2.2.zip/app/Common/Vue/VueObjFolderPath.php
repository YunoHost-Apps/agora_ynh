<div class="folderPath sBlock noSelect">
	<img src="app/img/folderSmall.png">
	<?php
	foreach(Ctrl::$curContainer->folderPath("object") as $tmpFolder){
		$arrowRight=(!empty($tmpFolder->_idContainer))  ?  "<img src='app/img/arrowRight.png'>"  :  null;
		echo "<a href=\"".$tmpFolder->getUrl()."\" title=\"".$tmpFolder->name."<br>".$tmpFolder->description."\">".$arrowRight." ".Txt::reduce($tmpFolder->name,30)."</a>";
	}
	?>
</div>
<br>