<div class="menuLine sLink">
	<div class="menuIcon"><img src="app/img/sort.png"></div>
	<div>
		<span class="menuLaunch" for="vMenuSort"><?= Txt::trad("sortBy")." ".Txt::trad("SORT_".$curSortTab[0]) ?> <img src="app/img/sort<?= ucfirst($curSortTab[1])?>.png"></span>
		<div  class="contextMenu" id="vMenuSort">
			<?php
			foreach($sortFields as $tmpSort)
			{
				echo "<div class='menuLine'><div><a ".($curSort==$tmpSort["sort"]?"class='sLinkSelect'":null)." onclick=\"redir('".$tmpSort["url"]."')\">".
						Txt::trad("SORT_".$tmpSort["field"]).
						" <img src='app/img/sort".ucfirst($tmpSort["ascDesc"]).".png' title=\"".Txt::trad($tmpSort["ascDesc"]=="asc"?"tri_ascendant":"tri_descendant")."\">
					  </a></div></div>";
			}
			?>
		</div>
	</div>
</div>