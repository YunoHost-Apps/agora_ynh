<script>
////	Resize
<?php if($context=="move"){ ?>
lightboxWidth(450);
<?php } ?>

////	Init l'affichage de l'arborescnce
$(function(){
	$(".vTreeFolder").each(function(){
		var folderTreeLevel=Math.round($(this).attr("data-treeLevel"));
		var folderId=Math.round($(this).attr("data-folderId"));
		var folderIdContainer=Math.round($(this).attr("data-folderIdContainer"));
		var curFolderPath=[<?= implode(",",Ctrl::$curContainer->folderPath("id")) ?>];
		//Ajoute un padding de gauche en fonction du niveau du dossier (niveau 2 minimum car on prend en compte la largeur de "vTreeFolderDep")
		if(folderTreeLevel>1)  {$(this).find(".vTreeFolderIcon").css("padding-left",((folderTreeLevel-1)*15)+"px");}
		//Affiche les dossiers : au niveau 0 et 1  avec un dossier conteneur dans l'arborescence courante
		if(folderTreeLevel<=1 || $.inArray(folderIdContainer,curFolderPath)!==-1)  {$(this).css("display","table");}
		//Masque le "open.png" des sous-dossiers qui n'ont pas de sous-dossiers  OU  Affiche le "open.png" des dossiers du "path" courant
		var curFolderSelector=".vTreeFolder[data-folderId='"+folderId+"']";
		var subFoldersSelector=".vTreeFolder[data-folderIdContainer='"+folderId+"']";
		if($(subFoldersSelector).exist()==false)		{$(curFolderSelector+" .vIconOpen").css("display","none");}
		else if($.inArray(folderId,curFolderPath)!==-1)	{$(curFolderSelector+" .vIconOpen").addClass("vIconOpened");}
	});
});

////	Ouvre/Ferme un dossier
function folderTreeDisplay(folderId, init)
{
	var curFolderSelector=".vTreeFolder[data-folderId='"+folderId+"']";
	var subFoldersSelector=".vTreeFolder[data-folderIdContainer='"+folderId+"']";
	//Ouvre: affiche le premier niveau de sous-dossiers & modifie "open.png" (rotate)
	if(init==true && $(subFoldersSelector).css("display")=="none"){
		$(subFoldersSelector).slideDown();
		setTimeout(function(){ $(curFolderSelector+" .vIconOpen").addClass("vIconOpened"); },100);
	}
	//Ferme: ferme tous les sous-dossiers & modifie "open.png" (rotate)
	else{
		$(subFoldersSelector).each(function(){  folderTreeDisplay($(this).attr("data-folderId"));  });
		$(subFoldersSelector).slideUp();
		$(curFolderSelector+" .vIconOpen").removeClass("vIconOpened");
	}
}

////	Déplacement d'objet(s) dans un autre dossier
function folderMove(newFolderId)
{
	//Réinitialise sous les dossiers
	$(".vTreeFolder>div:last-child").each(function(){  $(this).removeClass("sLinkSelect");  });
	$(".vTreeFolder input[name='newFolderId']").each(function(){  $(this).prop("checked",false);  });
	//Sélectionne le dossier
	$(".vTreeFolder[data-folderId='"+newFolderId+"']>div:last-child").addClass("sLinkSelect");
	$(".vTreeFolder[data-folderId='"+newFolderId+"'] input[name='newFolderId']").prop("checked",true);
}

////	Réactive les input "newFolderId" à la validation du formulaire de changement de dossier
function formControl(){
	$(".vTreeFolder input[name='newFolderId']").each(function(){ $(this).prop("disabled",false); });
}
</script>

<style>
.vTreeFolders		{margin:5px;}
.vTreeFolder		{display:none;}
.vTreeFolder>div	{display:table-cell; padding:2px; vertical-align:top;}
.vTreeFolderIcon	{white-space:nowrap;}/*cellule des icones*/
.vTreeFolder .vTreeFolderDep				{margin-left:5px; margin-right:-7px;}/*icone des dépendance*/
.vTreeFolder:first-child .vTreeFolderDep	{display:none;}/*dossier root : pas d'icone de dépendance*/
.vTreeFolderIcon .vIconOpen		{position:absolute; margin-top:5px; margin-left:-8px;}
.vIconOpened					{transform:rotate(45deg);}
</style>

<?php if($context=="move")  {echo "<form action='index.php' method='post' onsubmit=\"return formControl()\" class='lightboxContent'>";} ?>

<div class="vTreeFolders noSelect">
	<!--AFFICHE CHAQUE DOSSIER-->
	<?php foreach($folderTree as $tmpFolder){ ?>
		<div class="vTreeFolder" data-folderId="<?= $tmpFolder->_id ?>" data-folderIdContainer="<?= $tmpFolder->_idContainer ?>" data-treeLevel="<?= $tmpFolder->treeLevel ?>" title="<?= ($tmpFolder->isRootFolder() && Ctrl::$curUser->isAdminCurSpace()?Txt::trad('rootFolderEditInfo'):$tmpFolder->name)."<br>".$tmpFolder->description ?>">
			<div class="vTreeFolderIcon" onclick="folderTreeDisplay(<?= $tmpFolder->_id ?>,true)">
				<span class="vTreeFolderDep"><img src="app/img/open.png" class="vIconOpen sLink"><img src="app/img/folderDependance.png"></span>
				<img src='app/img/folderSmall.png' class='vIconFolder'>
			</div>
			<div class="sLink <?= $tmpFolder->_id==Ctrl::$curContainer->_id?"sLinkSelect":null ?>" onclick="<?= $context=="nav"?"redir('".$tmpFolder->getUrl()."')":"folderMove(".$tmpFolder->_id.")" ?>">
				<?= Txt::reduce($tmpFolder->name,60) ?>
				<?php if($context=="move"){ ?><input type="checkbox" name="newFolderId" value="<?= $tmpFolder->_id ?>" <?= $tmpFolder->_id==Ctrl::$curContainer->_id?"checked":null ?> disabled><?php }?>
			</div>
		</div>
	<?php }?>
	<!--FORMULAIRE DE DEPLACEMENT DE DOSSIER-->
	<?php
	if($context=="move"){
		foreach(Req::getParam("targetObjects") as $objType=>$objIds)  {echo "<input type='hidden' name=\"targetObjects[".$objType."]\" value=\"".$objIds."\">";}
		echo Txt::formValidate();
	}
	?>
</div>

<?= $context=="move" ?  "</form>"  : "<hr>"  ?>