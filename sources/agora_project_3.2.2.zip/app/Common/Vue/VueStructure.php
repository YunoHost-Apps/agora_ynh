<!doctype html>
<html lang="<?= Txt::trad("HEADER_HTTP") ?>">
	<head>
		<!-- AGORA-PROJECT :: UNDER THE GENERAL PUBLIC LICENSE V2 :: http://www.gnu.org -->
		<meta charset="UTF-8">
		<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
		<meta http-equiv="content-language" content="<?= Txt::trad("HEADER_HTTP") ?>">
		<title><?= !empty(Ctrl::$agora->name) ? Ctrl::$agora->name : "Agora-Project" ?></title>
		<meta name="Description" content="<?= !empty(Ctrl::$agora->description) ? Ctrl::$agora->description : "Agora-Project" ?>">
		<meta name="application-name" content="Agora-Project">
		<meta name="application-url" content="https://www.agora-project.net">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=Edge"><!--mode compatibilité IE-->
		<link rel="icon" type="image/gif" href="app/img/favicon.png" />
		<!-- JQUERY & JQUERY-UI & JQUERY MOBILE -->
		<script src="app/js/jquery-2.1.4.min.js"></script>
		<script src="app/js/jquery-ui/jquery-ui.min.js"></script>
		<link rel="stylesheet" href="app/js/jquery-ui/<?= $skinCss=="white"?"smoothness":"ui-darkness" ?>/jquery-ui.css">
		<script src="app/js/jquery-ui/datepicker-<?= Txt::trad("DATEPICKER") ?>.js"></script><!--lang du jquery-ui datepicker-->
		<?php if(Tool::isMobile()){ ?>
		<script src="app/js/jquery-mobile/jquery.mobile.custom.min.js"></script><!--swipe and co-->
		<?php } ?>
		<!-- JQUERY LIGHTBOX/FANCYBOX (thumbnail + mousewheel plugins) -->
		<script type="text/javascript" src="app/js/fancybox/source/jquery.fancybox.pack.js?v=2.1.5"></script>
		<link rel="stylesheet" type="text/css" href="app/js/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
		<link rel="stylesheet" type="text/css" href="app/js/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
		<script type="text/javascript" src="app/js/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
		<script type="text/javascript" src="app/js/fancybox/lib/jquery.mousewheel.pack.js?v=3.1.3"></script>
		<!-- JQUERY PLUGINS -->
		<script type="text/javascript" src="app/js/tooltipster/jquery.tooltipster.min.js"></script>
		<link rel="stylesheet" type="text/css" href="app/js/tooltipster/tooltipster.css">
		<link rel="stylesheet" type="text/css" href="app/js/tooltipster/tooltipster-shadow.css">
		<script type="text/javascript" src="app/js/toastmessage/jquery.toastmessage.js"></script>
		<link rel="stylesheet" type="text/css" href="app/js/toastmessage/toastmessage.css">
		<script src="app/js/timepicker/jquery.timepicker.min.js"></script>
		<link rel="stylesheet" type="text/css" href="app/js/timepicker/jquery.timepicker.css">
		<!-- JS & CSS DE L'AGORA -->
		<script src="app/js/common-3.2.2.js"></script><!--toujours après Jquery & plugins Jquery !!-->
		<link href="app/css/common-3.2.2.css" rel="stylesheet" type="text/css">
		<link href="app/css/<?= $skinCss ?>.css?v<?= VERSION_AGORA ?>" rel="stylesheet" type="text/css">

		<!-- Parametrage Javascript, Notifications, Triggers JS, etc -->
		<script type="text/javascript">
		//navigateur obsolète (tjs en premier. faire simple "alert()")
		if(isObsoleteIE())	{alert("<?= Txt::trad("ieObsolete") ?>");}
		langDatepicker="<?= Txt::trad("DATEPICKER") ?>";
		labelConfirmCloseLightbox="<?= Txt::trad("confirmCloseLightbox") ?>";
		labelSpecifyLoginPassword="<?= Txt::trad("SpecifyLoginPassword") ?>";
		labelDateBeginEndControl="<?= Txt::trad("beginEndError") ?>";
		labelEvtConfirm="<?= Txt::trad("CALENDAR_evtIntegrate") ?>";
		labelEvtConfirmNot="<?= Txt::trad("CALENDAR_evtNotIntegrate") ?>";
		labelUploadMaxFilesize="<?= File::uploadMaxFilesize("error") ?>";
		valueUploadMaxFilesize=<?= File::uploadMaxFilesize() ?>;
		<?php if(defined("HOST_DOMAINE"))  {Host::footerJs();} ?>
		$(function(){
			<?php
			//Affiche les Notifs & Lance les Triggers JS (parent.reload, etc)
			foreach($msgNotif as $tmpNotif)		{echo "notify(\"".addslashes($tmpNotif["message"])."\", \"".$tmpNotif["type"]."\");";}
			foreach($jsTriggers as $tmpTrigger)	{echo $tmpTrigger;}
			?>
		});
		</script>

		<style>
		/*Background image & Lightbox & Footer*/
		#backgroundImg		{position:fixed; z-index:-10; left:0px; top:0px; width:100%; height:100%;}
		#pageFooterHtml, #pageFooterIcon	{position:fixed; bottom:0px; z-index:20; display:inline-block; font-weight:normal;}
		#pageFooterHtml		{left:0px; padding-right:10px; color:#eee; text-shadow:0px 0px 9px #000;}
		#pageFooterIcon		{right:2px; bottom:3px;}
		#pageFooterIcon img	{max-height:50px; max-width:200px;}
		#pageFooterSpecial	{display:inline-block; margin:0px 0px -7px -7px; background-color:rgba(0,0,0,0.7); border-radius:5px; padding:8px; color:#c00; font-weight:bold;}/*host*/
		/*RESPONSIVE*/
		@media screen and (max-width:1024px){
			#pageFooterIcon	{display:none;}
		}
		/*IMPRESSION*/
		@media print{
			[id^='pageFooter']	{display:none!important;}
		}
		</style>
	</head>

	<body>
		<!--PAGE PRINCIPALE : WALLPAPER & CONTENU DES LIGHTBOX & MENU RESPONSIVE-->
		<?php if(Ctrl::$isMainPage==true){ ?>
			<img src="<?= Tool::isMobile() ? "app/img/respBg.jpg" : $pathWallpaper ?>" id="backgroundImg" class="noPrint">
			<div id="respMenuBg"></div>
			<div id="respMenuMain"><div id="respMenuClose"><img src="app/img/closeResp.png"></div><div id="respMenuContent"></div></div>
		<?php } ?>

		<!--HEADER MENU & CORPS DE LA PAGE-->
		<?= $headerMenu.$mainContent.$messengerLivecounter ?>

		<!--ICONE AGORA DU FOOTER & FOOTER PERSONNALISE (script de stats, etc)-->
		<?php if(Ctrl::$isMainPage==true && !empty(Ctrl::$agora)){ ?>
		<div id="pageFooterHtml"><?= !empty(Ctrl::$agora->footerHtml) ? Ctrl::$agora->footerHtml : null ?></div>
		<div id="pageFooterIcon"><a href="<?= $pathLogoUrl ?>" target="_blank" title="<?= $pathLogoTitle ?>"><img src="<?= Ctrl::$agora->pathLogoFooter() ?>"></a></div>
		<?php } ?>
	</body>
</html>