<div class="lightboxTitle"><?= Txt::trad("searchOnSpace") ?></div>

<script type="text/javascript">
////	Resize et sé"lection par défaut du champ de recherche
lightboxWidth(600);
$(function(){
	$("[name='searchText']").focus();
});


////	Contrôle du formulaire
function formControl()
{
	//champ de recherche
	if($("[name=searchText]").val().length<3)
		{notify("<?= Txt::trad("searchSpecifyText") ?>");  return false;}
	//Recherche avancée
	if($("[name=advancedSearch]").val()==1 && ($("input[name='searchModules[]']:checked").isEmpty() || $("input[name='searchFields[]']:checked").isEmpty()))
		{notify("<?= Txt::trad("fillAllFields") ?>");  return false;}
}

////	Recherche avancée
function displayAdvancedSearch()
{
	$(".advancedSearchBlock").toggle();
	if($("[name=advancedSearch]").val()==1)	{$("[name=advancedSearch]").val(0);}
	else									{$("[name=advancedSearch]").val(1);}
}
</script>

<style>
input[name="searchText"]	{width:220px; margin-right:5px;}
button[type="submit"]		{margin-right:20px;}
#advancedSearchLabel		{display:inline-block;}
.advancedSearchBlock		{display:<?= Req::getParam("advancedSearch")?"block":"none" ?>;}
.vAdvancedSearchTab			{display:table; margin-top:15px;}
.vAdvancedSearchTab>div		{display:table-cell;}
.vAdvancedSearchTab>div:first-child	{width:110px;}
.vAdvancedSearchOption		{display:inline-block; width:32%; float:left; padding:3px; font-size:95%;}
.vModHeader					{text-align:right;}
.vModHeader hr				{margin-top:20px;}
.vModHeader img				{max-height:30px; margin-top:-5px; margin-bottom:-10px;}
.vSearchResult				{display:table;}
.vSearchResult>div			{display:table-cell; padding:5px;}
.vSearchResult img			{max-height:25px;}
.vSearchResultWord			{color:#900; text-decoration:underline;}

/*RESPONSIVE -> 400px!*/
@media screen and (max-width:400px){	
	input[name="searchText"]	{width:150px; margin-right:5px;}
	#advancedSearchLabel		{display:block; margin-top:15px;}
	.vAdvancedSearchOption		{width:48%;}
}
</style>

<form action="index.php" method="post" OnSubmit="return formControl()" class="lightboxContent">

	<div id="searchMainField">
		<?= Txt::trad("keywords") ?>
		<input type="text" name="searchText" value="<?= Req::getParam("searchText") ?>">
		<?= Txt::formValidate("search",false) ?>
		<div id="advancedSearchLabel">
			<label onclick="displayAdvancedSearch();" class="noSelect sLink"><?= Txt::trad("advancedSearch") ?> <img src="app/img/plusSmall.png"></label>
			<input type="hidden" name="advancedSearch" value="<?= Req::getParam("advancedSearch") ?>">
		</div>
	</div>

	<div class="advancedSearchBlock">
		<!--MODE DE RECHERCHE-->
		<div class="vAdvancedSearchTab">
			<div><?= Txt::trad("search") ?></div>
			<div>
				<select name="searchMode">
					<?php foreach(["someWords","allWords","exactPhrase"] as $tmpOption)	{echo "<option value=\"".$tmpOption."\" ".(Req::getParam("searchMode")==$tmpOption?'selected':null).">".Txt::trad("advancedSearch".ucfirst($tmpOption))."</option>";} ?>
				</select>
			</div>
		</div>
		<!--DATE DE CREATION-->
		<div class="vAdvancedSearchTab">
			<div><?= Txt::trad("searchDateCrea") ?></div>
			<div>
				<select name="creationDate">
					<option value="all"><?= Txt::trad("all") ?></option>
					<?php foreach(["day","week","month","year"] as $tmpOption)	{echo "<option value=\"".$tmpOption."\" ".(Req::getParam("creationDate")==$tmpOption?'selected':null).">".Txt::trad("searchDateCrea".ucfirst($tmpOption))."</option>";} ?>
				</select>
			</div>
		</div>
		<!--SELECTION DE MODULES-->
		<div class="vAdvancedSearchTab">
			<div><?= Txt::trad("listModules") ?></div>
			<div>
				<?php
				foreach(self::$curSpace->moduleList() as $tmpModule){
					if(method_exists($tmpModule["ctrl"],"plugin")){
						$moduleChecked=(Req::isParam("searchModules")==false || in_array($tmpModule["moduleName"],Req::getParam("searchModules")))  ?  "checked='checked'"  :  "";
						$moduleInputId="searchModules".$tmpModule["moduleName"];
						$moduleName=Txt::trad(strtoupper($tmpModule["moduleName"])."_headerModuleName");
						echo "<div class='vAdvancedSearchOption'><input type='checkbox' name='searchModules[]' value='".$tmpModule["moduleName"]."' id='".$moduleInputId."' ".$moduleChecked."><label for='".$moduleInputId."'>".$moduleName."</label></div>";
					}
				}
				?>
			</div>
		</div>
		<!--SELECTION DES CHAMPS DE RECHERCHE-->
		<div class="vAdvancedSearchTab">
			<div><?= Txt::trad("listFields") ?></div>
			<div>
				<?php
				foreach($searchFields as $fieldName=>$fieldParams){
					$fieldTitle=Txt::trad("listFieldsElems")." :<br>".$fieldParams["title"];
					$fieldInputId="searchFields".$fieldName;
					echo "<div class='vAdvancedSearchOption' title=\"".$fieldTitle."\"><input type='checkbox' name=\"searchFields[]\" value=\"".$fieldName."\" id='".$fieldInputId."' ".$fieldParams["checked"]."><label for='".$fieldInputId."'>".Txt::trad($fieldName)."</label></div>";
				}
				?>
			</div>
		</div>
	</div>
</form>

<!--RESULTATS DE LA RECHERCHE-->
<?php
if(Req::isParam("searchText"))
{
	//Résultats à afficher
	$searchTexts=explode(" ",Req::getParam("searchText"));
	foreach($pluginsSearchResult as $pluginObj)
	{
		//Entête du module courant
		if(empty($curModule) || (isset($pluginObj->pluginModule) && $curModule!=$pluginObj->pluginModule)){
			echo "<hr><div class='vModHeader'><img src=\"app/img/".$pluginObj->pluginModule."/icon.png\"></div>";
			$curModule=$pluginObj->pluginModule;
		}
		//ligne de l'element de résultat
		$pluginObj->pluginIcon=(!empty($pluginObj->pluginIsFolder)) ? "folder.png" : "arrowRight.png";
		foreach($searchTexts as $searchText)	{$pluginObj->pluginLabel=preg_replace("/".$searchText."/i", "<span class='vSearchResultWord'>".$searchText."</span>", $pluginObj->pluginLabel);}
		echo "<div class='vSearchResult sLink'>
				<div onclick=\"".$pluginObj->pluginJsIcon."\"><img src='app/img/".$pluginObj->pluginIcon."'></div>
				<div title=\"".$pluginObj->pluginTitle."\" onclick=\"".$pluginObj->pluginJsLabel."\">".$pluginObj->pluginLabel."</div>
			  </div>";
	}
	//Aucun résultat à afficher
	if(empty($pluginsSearchResult))	{echo "<div class='pluginEmpty'>".Txt::trad("noResults")."</div>";}
}