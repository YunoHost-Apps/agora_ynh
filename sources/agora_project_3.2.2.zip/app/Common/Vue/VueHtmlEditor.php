<script type="text/javascript" src="app/js/tinymce/tinymce.min.js"></script>

<script type="text/javascript">
////	Options de la "toolbar" de l'éditeur
if(isMobile()){
	optionsToolbar1="undo redo | alignleft aligncenter | bullist | emoticons";
	optionsToolbar2="bold italic underline forecolor fontsizeselect";
}else{
	optionsToolbar1="undo redo | bullist numlist | paste removeformat | table charmap emoticons media image";
	optionsToolbar2="bold italic underline | alignleft aligncenter alignjustify | fontsizeselect forecolor link";
}
////	Initialise l'editeur html
tinymce.init({
	//parametrage général
	width: "100%",
	language: <?= Txt::trad("HTML_EDITOR")==""  ? "null"  :  "\"".Txt::trad("HTML_EDITOR")."\"" ?>,//ne pas mettre de valeur vide (exple : "")
	selector: "textarea[name='<?= $fieldName ?>']",//selecteur du textarea
	statusbar: false,
	//forced_root_block: "div",//Remplace les balises "<p>"
	entity_encoding: "raw",//"All characters will not be stored as html entities, except : &amp; &lt; &gt; &quot;"
	content_style: "p {margin:0px; padding:2px; font-size:13px;}",//style des balises <p> : cf. 'app/css/common.css'
	//charge les plugins. Pas de "contextmenu" pour pouvoir afficher copier/coller si "paste" est bloqué par le browser. Autre plugins : print preview hr anchor pagebreak wordcount fullscreen insertdatetime
	plugins: ["autoresize advlist autolink lists link image charmap visualblocks visualchars media nonbreaking table directionality emoticons paste textcolor colorpicker textpattern"],
	//barres de menu (Attention a l'affichage sur un width minimum. cf. modTask)
	menubar: false,
	toolbar1: optionsToolbar1,
	toolbar2: optionsToolbar2,
	//parametrage des plugins
	fontsize_formats: "13px 16px 20px 24px",//Taille des caractères en "px" (plus fiable que %)
	media_alt_source: false,//désactive le champ alternatif de saisie de source dans la boîte de dialogue des médias
	media_poster: false,//désactive l'envoi de fichier dans la boîte de dialogue des médias
	image_description: false,
	image_title: true,
	//Un fois l'éditeur initialisé :
	setup: function(editor){
		//Init : Modif le style du menu && Focus sur l'éditeur?
		editor.on('init',function(){
			$(".mce-btn button").css("box-shadow","none");
			$(".mce-toolbar:first-child").css("border-bottom","1px solid #ccc");
			//Focus sur l'éditeur s'il est visible && aucun input n'a déjà le focus && pas en mobile
			if($(editor.getBody()).is(":visible") && $("input:focus").length==0 && isMobile()==false)	{editor.focus();}
			//Init la hauteur du lightbox si besoin
			lightboxResize(true);
		});
		//Resize le lightbox si le contenu agrandit l'éditeur
		editor.on("change keyup",function(){
			lightboxResize(true);
			$(document).find("body").trigger("click");//cf. "confirmCloseLightbox"
		});
	}
});

////	Contenu de l'editeur est vide ?
function isEmptyEditor()
{
	var content=tinymce.activeEditor.getContent({format:'text'});
	if($.trim(content).length==0)	{return true;}
}
</script>