<script type="text/javascript">	
////	Affiche les livecounters (footer & messenger)
$(function(){
	//Lance le livecounter
	livecounterUpdate(true);
	//Resize le messenger : MAJ la hauteur de "messengerContent" en fonction de "messengerContainer" (cf. "overflow" scroll)
	$("#messengerContainer").resize(function(){
		$("#messengerContent,#messengerContent>div>div").outerHeight( $("#messengerContainer").height()-$("#messengerPostForm").outerHeight(true));
	});
});

////	Update les livecounters (principal/messenger) && Messages du messenger
function livecounterUpdate(livecounterInit)
{
	//Init le son d'alerte
	if(typeof messengerAlert=="undefined"){
		messengerAlert=new Audio("app/misc/messengerAlert.mp3");
		messengerAlert.loop=false;
	}
	//Params ajax de base
	var updateParams="";
	if(livecounterInit==true)	{updateParams+="&livecounterInit=true";}//Init le livecounter
	if($(".fancybox-iframe").exist() && find("Edit",$(".fancybox-iframe").prop("src")))  {updateParams+="&editObjId="+getUrlParam("targetObjId",$(".fancybox-iframe").prop("src"));}//Control de double modif d'un objet
	//Lance la requete AJAX
	$.ajax({url:"?ctrl=misc&action=LivecounterUpdate"+updateParams,dataType:"json"}).done(function(ajaxResult){
		////	LIVECOUNTERS
		if(ajaxResult.livercountersLoad==true)
		{
			//Livecounter principal
			if(ajaxResult.livecounterMain.length==0)	{$("#livecounterMain").hide();  $("#pageFooterHtml").show();}
			else{
				$("#livecounterMainUsers").html("<span id='livecounterMainUsersTitle'><?= Txt::trad("MESSENGER_connected") ?> <img src='app/img/arrowRight.png'></span>"+ajaxResult.livecounterMain);
				$("#livecounterMain").show();
				$("#pageFooterHtml").hide();//VueStructure.php
			}
			//Livecounter du messenger
			var oldCheckedUsers=messengerUsersChecked();//Retient les users dejà sélectionnés (tableau)
			$("#messengerUsersAjax").html(ajaxResult.livecounterMessenger);	//Affiche les users
			for(var tmpKey in oldCheckedUsers)	{$("#messengerUserBox"+oldCheckedUsers[tmpKey]).prop("checked",true);}//Attention : Recoche uniquement les users déjà sélectionnés avant affichage du nouveau livecounter
		}
		////	MESSAGES
		if(ajaxResult.messengerMessages.length>0)
		{
			//Affiche les derniers messages PUIS Style du messenger pour un user spécifique  & Scroll jusqu'au dernier message (bas de liste) 
			$("#messengerMessagesAjax").html(ajaxResult.messengerMessages);
			initTooltips();//Réactive après un "html()"
			if(typeof messengerDisplayLastIdUser=="undefined")  {messengerDisplayLastIdUser=null;}
			messengerUserStyle(messengerDisplayLastIdUser);
			scrollToLastMessages();
			//Pulsate et Alerte sonore si ya de nouveaux messages (relancé à chaque "livecounterUpdate" si le messenger n'est tjs pas affiché)
			if(ajaxResult.messengerPulsateUsers.length>0)
			{
				//Fait clignoter les auteurs des derniers messages sur le livecounter principal
				for(var tmpKey in ajaxResult.messengerPulsateUsers){
					var pulsateIdUser=ajaxResult.messengerPulsateUsers[tmpKey];
					if(messengerVisible(pulsateIdUser))		{messengerPulsateTimes=3;	messengerPulsateDuration=1500;	messengerDisplayTime(pulsateIdUser);}//pulsate court & MAJ Ajax du "messengerDisplayTime"
					else									{messengerPulsateTimes=40;	messengerPulsateDuration=40000;}//pulsate long
					$("#livecounterMainUsers label[data-idUser='"+pulsateIdUser+"']").stop(true).css("opacity","1").effect("pulsate",{times:messengerPulsateTimes},messengerPulsateDuration);//Lance/Relance le pulsate
				}
				//Alerte sonore si ya de nouveaux messages (X2)
				messengerAlert.play();
				setTimeout(function(){ messengerAlert.play(); },1000);
			}
		}
		//Relance après x secondes (microtime)
		if(typeof livecounterUpdateTimeout!="undefined")  {clearTimeout(livecounterUpdateTimeout);}//Annule le dernier "setTimeout" (pas de cumul)
		livecounterUpdateTimeout=setTimeout(function(){ livecounterUpdate(); },<?= LIVECOUNTER_REFRESH*1000 ?>);
	});
}

////	Affichage / masquage du messenger (displayIdUser => "all" users / "_idUser" specifique / "close")
function messengerToggle(displayIdUser)
{
	//Masque le messenger s'il est déjà affiché
	if(messengerVisible(displayIdUser))  {displayIdUser="close";}
	//Pas d'affichage "all" en mode mobile
	if(isMobile() && displayIdUser=="all")	{return false;}
	//Masque/Affiche le messenger
	if(displayIdUser=="close")  {$("#messengerContainer").fadeOut();}
	else
	{
		//Sélection d'un user spécifique / premier user de la liste
		$("[id^='messengerUserBox']").prop("checked",false);//reinit
		if(displayIdUser!="all" && $("#messengerUserBox"+displayIdUser).exist())	{$("#messengerUserBox"+displayIdUser).prop("checked",true).trigger("change");}//"trigger" pour "checkboxLabel()"
		// Affichage mobile (toute hauteur/largeur)  /  Affichage normal (Redimensionnable des 4 cotés) 
		if(isMobile())	{$("#messengerContainer").outerHeight(Math.round($(window).height()-$("#livecounterMain").height())).outerWidth($(window).width()).trigger("resize");}
		else				{$("#messengerContainer").resizable({handles:"n,e,s,w"});}
		//Messenger : Positions left/top & Update la hauteur du contenu scrollable (Trigger "Resize") & Affichage final
		var newLeft  =(isMobile())  ?  0  :  Math.round(($(window).width()/2) - ($("#messengerContainer").outerWidth(true)/2));
		var newBottom=(isMobile())  ?  $("#livecounterMain").outerHeight()  :    $("#livecounterMain").outerHeight()+20;
		$("#messengerContainer").css("left",newLeft).css("bottom",newBottom).fadeIn().trigger("resize");
		//Actions diverses (après affichage!)
		messengerDisplayLastIdUser=displayIdUser;						//Update le dernier user affiché
		scrollToLastMessages();											//Affiche les derniers messages
		messengerAlert.pause();											//Fin de son d'alerte
		$("#livecounterMainUsers label").stop(true).css("opacity","1");	//Fin de "pulsate"
		messengerDisplayTime(displayIdUser);							//MAJ Ajax du "time" de l'user affiché
		//Input text : remplace le "placeholer" & focus?
		var placeholderText=(displayIdUser=="all")  ?  "<?= Txt::trad("MESSENGER_addMessageToSelection") ?>"  :  "<?= Txt::trad("MESSENGER_addMessageTo") ?> "+$("#livecounterMainUsers label[data-idUser='"+displayIdUser+"']").text();
		$("#messengerPostMessage").attr("placeholder",placeholderText);
		if(!isMobile())  {$("#messengerPostMessage").focus();}
	}
	//Style du messenger
	messengerUserStyle(displayIdUser);
}

////	Style du messenger : user spécifique / tous les users
function messengerUserStyle(displayIdUser)
{
	//Réinit l'affichage des livecounters et de tous les messages
	$("#messengerUsersAjaxDiv,.vMessengerMessage").hide();
	$("#livecounterMainUsers label[data-idUser]").removeClass("vLivecounterMainUsersLabelSelect");
	//Tous les users : affiche la sélection d'users et tous les messages
	if(displayIdUser=="all")	{$("#messengerUsersAjaxDiv,.vMessengerMessage").show();}
	//User spécifique : Affiche uniquement les messages de l'user & Surligne l'user dans le "livecounterMain"
	else if(displayIdUser!="close" && messengerVisible(displayIdUser)){
		$(".vMessengerMessage[data-idUsers*='@"+displayIdUser+"@']").show();
		$("#livecounterMainUsers label[data-idUser='"+displayIdUser+"']").addClass("vLivecounterMainUsersLabelSelect");
	}
}

////	MAJ Ajax du "time" de l'user affiché
function messengerDisplayTime(displayIdUser)
{
	$.ajax({url:"?ctrl=misc&action=MessengerUsersDisplayTime&displayIdUser="+displayIdUser});
}

////	Verif si le messenger est affiché
function messengerVisible(displayIdUser)
{
	return ($("#messengerContainer").is(":visible") && displayIdUser==messengerDisplayLastIdUser);
}

////	Affiche les derniers messages (en bas de "messengerMessagesAjax")
function scrollToLastMessages()
{
	setTimeout(function(){ $("#messengerMessagesAjax").scrollTop($("#messengerMessagesAjax").prop("scrollHeight")); },200);
}

////	Users sélectionnés : renvoi un tableau
function messengerUsersChecked()
{
	return $("[name='messengerPostUsers']:checked").map(function(){ return $(this).val(); }).get();
}

////	Controle & post du message du messenger (note: pb de scroll sous chrome apres lancement de "messengerPost()")
function messengerPost()
{
	//Vérif du message et user spécifié
	if($("#messengerPostMessage").isEmpty())  {notify("<?= Txt::trad("MESSENGER_addMessageNotif") ?>");  return false;}
	var checkedUsers=messengerUsersChecked();
	if(checkedUsers.length==0)  {notify("<?= Txt::trad("selectUser") ?>");  return false;}
	// On poste le message, relance l'affichage des messages et récupère les messages
	$.ajax({url:"?ctrl=misc&action=MessengerPostMessage", data:{message:$("#messengerPostMessage").val(),messengerPostUsers:checkedUsers}, type:"POST"}).done(function(){
		$("#messengerPostMessage").val("");
		if(!isMobile())  {$("#messengerPostMessage").focus();}
		livecounterUpdate(true);//"true": pour que "$newMessages" reste null
	});
}
</script>


<style>
/*Common*/
.vMessengerUserImg	{border-radius:50%; margin:0px 5px 0px 5px;}

/*Livecounter Main*/
#livecounterMain			{display:none; position:fixed; z-index:20; bottom:0px; left:0px; width:100%; text-align:center;}
#livecounterMainContent		{position:relative; display:inline-block; color:#fff; background-color:rgba(0,0,0,0.6); padding:7px; padding-left:40px; border-radius:5px 5px 0px 0px;}
#livecounterMainIcon		{position:absolute; left:-10px; top:-2px; cursor:pointer;}
#livecounterMainUsersTitle	{margin-right:5px;}
#livecounterMainUsers label	{padding:7px 7px 7px 0px; margin:0px 5px 0px 5px; color:#fff !important;}/*cf. "actionLivecounterUpdate()"*/
.vLivecounterMainUsersLabelSelect			{border:solid 1px #888; border-radius:3px; background-color:rgba(0,0,0,0.3);}
#livecounterMainUsers .vMessengerUserImg	{width:35px; height:35px;}/*cf. "actionLivecounterUpdate()"*/

/*Messenger*/
#messengerContainer			{display:none; position:fixed; z-index:23; min-width:330px; width:430px; min-height:200px; height:450px; border-radius:5px; padding:15px; background-color:rgba(0,0,0,0.75);}
#messengerContainer .vMessengerUserImg	{width:24px; height:24px;}/*cf. "actionLivecounterUpdate()"*/
#messengerClose				{position:absolute; top:-10px; right:-10px;}
#messengerPostForm			{padding-top:20px; text-align:center; vertical-align:bottom;}
#messengerPostMessage		{width:280px; font-weight:bold; border-radius:3px;}
#messengerContent			{display:table; width:100%; background-color:#fff; border-radius:3px;}
#messengerContent>div		{display:table-cell;}
#messengerContent>div:first-child	{width:120px; background:linear-gradient(to bottom,#eee,#fff);}
#messengerUsersAjax, #messengerMessagesAjax	{overflow-y:auto;}
#messengerUsersAjax>div		{margin:5px;}
#messengerMessagesAjax		{background-image:url(app/img/messengerBig.png); background-repeat:no-repeat; background-position:right bottom;}
.vMessengerMessage			{display:table;}
.vMessengerMessage>div		{display:table-cell; padding:5px; cursor:help; vertical-align:middle;}
.vMessengerMessage>div:first-child								{min-width:70px; color:#aaa;}/*heure/auteur du message*/
.vMessengerMessage [data-idAutor='<?= Ctrl::$curUser->_id?>']	{font-style:italic;}/*text du "curUser"*/

/*RESPONSIVE*/
@media screen and (max-width:1024px)
{
	#livecounterMain			{text-align:left;}
	#livecounterMainContent		{width:100%; background-color:rgba(0,0,0,9); padding:5px 0px 5px 0px; border-radius:0px; text-align:right;}/*padding left & right à zero car width=100%*/
	#livecounterMainIcon		{left:0; top:18px; opacity:0.7;}
	#livecounterMainUsersTitle	{display:none;}/*masque "connectés:"*/
	#livecounterMainUsers label	{text-transform:uppercase;}
	#livecounterMainUsers .vMessengerUserImg	{width:45px; height:45px;}
	#messengerContainer			{padding:8px; border-radius:0px; background-color:rgba(0,0,0,0.9);}
	#messengerPostForm			{padding-top:10px;}
	#messengerPostMessage		{height:33px; width:230px;}
	#messengerPostButton		{height:33px; font-size:90%;}
	#messengerClose				{top:0px; right:0px;}
	#messengerClose img			{content:url(app/img/closeResp.png);}/*chrome et ie uniquement*/
}
</style>

<!--LIVECOUNTER PRINCIPAL + ICONE MESSENGER-->
<div id="livecounterMain">
	<span id="livecounterMainContent">
		<img src="app/img/messenger.png" id="livecounterMainIcon" onclick="messengerToggle('all');" title="<?= Txt::trad("MESSENGER_messenger") ?>">
		<span id="livecounterMainUsers"></span>
	</span>
</div>

<!--MESSENGER-->
<div id="messengerContainer" onMouseOver="$(this).draggable({handle:'#messengerPost,#messengerMessagesAjax',opacity:0.9});">
	<!--FERME-->
	<a id="messengerClose" onclick="messengerToggle('close');" title="<?= Txt::trad("close") ?>"><img src="app/img/close.png"></a>
	<!--USERS & MESSAGES-->
	<div id="messengerContent">
		<div id="messengerUsersAjaxDiv"><div id="messengerUsersAjax">&nbsp;</div></div>
		<div id="messengerMessagesAjaxDiv"><div id="messengerMessagesAjax">&nbsp;</div></div>
	</div>
	<!--POST MESSAGE & CO-->
	<div id="messengerPostForm">
		<input type="text" name="message" id="messengerPostMessage" maxlength="500" onkeyup="if(event.keyCode==13){messengerPost();}">
		<button id="messengerPostButton" onclick="messengerPost();"><?= Txt::trad("send") ?> <img src="app/img/paperPlane.png"></button>
	</div>
</div>