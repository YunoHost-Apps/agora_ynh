<style>
/*HEADER BAR*/
.headerBarCell					{width:1%; white-space:nowrap; padding:0px 5px 0px 5px;}/*surcharge. 'width' & 'white-space' : largeur de cell = largeur du contenu*/
.vHeaderLogo					{width:50px; vertical-align:middle; padding-left:2px;}
.vHeaderLogoMain				{float:right; margin-top:10px;}
.vHeaderLogo					{width:50px; vertical-align:middle; padding-left:2px;}
.headerBarCell img[src*='arrowBottom']	{margin-left:2px;}
.vHeaderSpaceList				{padding:0px 0px 3px 35px;}
.vHeaderModulesCell				{width:auto; text-align:right; padding:0px;}/*'width:auto' prends le max de largeur*/
.vHeaderModulesTab				{display:inline-table; height:100%;}
.vHeaderModuleCell				{display:table-cell; vertical-align:middle; padding:0px 5px 0px 5px; border:solid 1px transparent;}
.vHeaderModuleCell:hover		{border:solid 1px #ccc;}
.vHeaderModuleCell label		{<?= Ctrl::$agora->moduleLabelDisplay=="hide"?"display:none;":null; ?>}
#guestConnectForm				{margin-bottom:20px!important;}
#guestConnectForm *				{display:block!important; width:220px!important; height:30px!important; margin:15px 0px 15px 0px!important;}
#headerModuleResp				{display:none;}
#modMenuResp					{display:none;}

/*RESPONSIVE*/
@media screen and (max-width:1024px)
{
	.headerBar							{font-size:110%; text-align:right; padding-top:8px;}
	.headerBarCell:not(.vHeaderLogo)	{display:inline-block; width:auto; white-space:normal; padding:8px 10px 8px 0px;}
	.headerModuleSelect, .vHeaderModuleCell, .vHeaderModuleCell:hover	{border:none!important; background:none;}
	.vHeaderModuleCell					{display:none;}/*menu masqué par défaut : copié dans le menu responsive !*/
	#respMenuMain .vHeaderModuleCell	{display:block; padding:8px 5px 8px 5px;}/*menu masqué par défaut : copié dans le menu responsive !*/
	.vHeaderModuleCell label			{display:inline;}/*affiche tjs le label (cf. 'moduleLabelDisplay')*/
	.vHeaderModuleCell img				{margin-right:10px;}
	.vHeaderModuleIcon					{max-height:24px !important;}
	#headerModuleResp					{display:inline; text-transform:uppercase;}
	#headerModuleResp img[src*='arrowBottom']	{margin-left:-3px;}
	#modMenuResp						{display:inline-block;}
}
</style>


<!--BARRE DE MENU-->
<div class="headerBar noPrint">

	<!--LOGO AGORA : MENU PRINCIPAL + MENU ADMIN GENERAL-->
	<div class="headerBarCell vHeaderLogo">
		<img src="app/img/logo.png" class="menuLaunch" for="headerMainMenu">
		<div id="headerMainMenu" class="contextMenu">
			<?php if(Ctrl::$curUser->isAdminGeneral()){ ?>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/paramsGeneral.png"></div><div><a href="?ctrl=agora"><?= Txt::trad("AGORA_generalSettings") ?></a></div></div>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/space.png"></div><div><a href="?ctrl=space" title="<?= Txt::trad("SPACE_moduleInfo") ?>"><?= Txt::trad("SPACE_manageSpaces") ?></a></div></div>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/user/icon.png"></div><div><a href="?ctrl=user&displayUsers=all"><?= Txt::trad("USER_allUsersManage") ?></a></div></div>
				<hr>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/log.png"></div><div><a href="?ctrl=log"><?= Txt::trad("LOG_moduleDescription") ?></a></div></div>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/diskSpace<?= $diskSpaceAlert==true?"Alert":null ?>.png"></div><div class="cursorHelp" title="<?= $diskSpacePercent. " % ".Txt::trad("from")." ".File::displaySize(limite_espace_disque) ?>"><?= Txt::trad("diskSpaceUsed")." : ".File::displaySize(File::datasFolderSize()) ?></div></div>
			<?php } ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/info.png"></div><div><a onclick="lightboxOpen('docs/DOCUMENTATION_<?= Txt::trad("CURLANG")=="fr"?"FR":"EN"?>.pdf');"><?= Txt::trad("HEADER_documentation") ?></a></div></div>
			<a href="<?= AGORA_PROJECT_URL ?>" target="_blank" title="<?= AGORA_PROJECT_URL2 ?>" class="vHeaderLogoMain"><img src="app/img/headerLogo<?= defined("HOST_DOMAINE")?"O":"AP"?>.png"></a>
		</div>
	</div>

	<!--USER / INVITE-->
	<div class="headerBarCell">
		<div id="headerUserMenu" class="contextMenu">
			<?php
			////	INVITE : FORMULAIRE DE CONNEXION  ||  USER : EDIT PROFILE + MESSENGER & AFFICHAGE ADMIN & DECONNEXION
			if(Ctrl::$curUser->isUser()==false)  {echo "<form action='index.php' method='post' id='guestConnectForm' OnSubmit=\"return controlConnect()\"><input type='text' name='connectLogin' placeholder=\"".Txt::trad("placeholderLogin")."\"><input type='password' name='connectPassword' placeholder=\"".Txt::trad("password")."\">".Txt::formValidate("connect",false)."</form>";}
			else
			{
				echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/edit.png'></div><div><a onclick=\"lightboxOpen('".Ctrl::$curUser->getUrl("edit")."');\">".Txt::trad("USER_modifyProfil")."</a></div></div>";
				if(Ctrl::$curUser->messengerEdit())  {echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/messenger.png'></div><div><a onclick=\"lightboxOpen('?ctrl=user&action=UserEditMessenger&targetObjId=".Ctrl::$curUser->_targetObjId."');\" title=\"".Txt::trad("USER_livecounterVisibility")."\">".Txt::trad("USER_editMyMessenger")."</a></div></div>";}
				if(Ctrl::$curUser->isAdminCurSpace()){
					$displayAdminClass=(!empty($_SESSION["displayAdmin"]))  ?  "sLinkSelect"  :  null;
					$displayAdminSwitchUrl="?ctrl=".Req::$curCtrl."&displayAdmin=".(empty($_SESSION["displayAdmin"])?"1":"0")."&targetObjId=".Req::getParam("targetObjId");//$_SESSION["displayAdmin"] => "o" ou "1" uniquement!
					echo "<div class='menuLine' title=\"".Txt::trad("HEADER_displayAdminInfo")."\"><div class='menuIcon'><img src='app/img/eye.png'></div><div><a href=\"".$displayAdminSwitchUrl."\" class=\"abbr ".$displayAdminClass."\">".Txt::trad("HEADER_displayAdmin")."</a></div></div>";
				}
			}
			?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/logout.png"></div><div><a href="?disconnect=1"><?= Txt::trad("HEADER_disconnet") ?></a></div></div>
		</div>
		<label class="menuLaunch <?= @$displayAdminClass ?>" for="headerUserMenu"><?= Ctrl::$curUser->isUser() ? Ctrl::$curUser->display()  :  Txt::trad("connect") ?><img src="app/img/arrowBottom.png"></label>
	</div>

	<!--SPACE-->
	<div class="headerBarCell">
		<div id="headerSpaceMenu" class="contextMenu">
			<?php if(Ctrl::$curUser->isAdminCurSpace()){ ?><div class="menuLine"><div class="menuIcon"><img src="app/img/params.png"></div><div><a onclick="lightboxOpen('<?= Ctrl::$curSpace->getUrl("edit"); ?>');"><?= Txt::trad("SPACE_config") ?></a></div></div><?php } ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/search.png"></div><div><a onclick="lightboxOpen('?ctrl=object&action=Search');"><?= Txt::trad("HEADER_searchElem") ?></a></div></div>
			<?php if(Ctrl::$curUser->sendInvitationRight()){ ?><div class="menuLine"><div class="menuIcon"><img src="app/img/mail.png"></div><div><a onclick="lightboxOpen('?ctrl=user&action=SendInvitation');" title="<?= Txt::trad("USER_sendInvitationInfo") ?>"><?= Txt::trad("USER_sendInvitation") ?></a></div></div><?php } ?>
			<?php if(count(Ctrl::$curUser->getSpaces())>1){ ?>
				<div class="menuLine"><div class="menuIcon"><img src="app/img/space.png"></div><div><?= Txt::trad("HEADER_displaySpace") ?> :</div></div>
				<?php foreach(Ctrl::$curUser->getSpaces() as $tmpSpace)  {echo "<div class='vHeaderSpaceList'><img src='app/img/arrowRight.png'><a href=\"?_idSpaceAccess=".$tmpSpace->_id."\"  ".($tmpSpace->_id==Ctrl::$curSpace->_id?"class='sLinkSelect'":null)." title=\"".$tmpSpace->description."\"> ".$tmpSpace->name."</a></div>";} ?>
			<?php } ?>
		</div>
		<label class="menuLaunch" for="headerSpaceMenu"><?= Ctrl::$curSpace->name ?><img src="app/img/arrowBottom.png"></label>
	</div>

	<!--SHORTCUTS-->
	<?php if(count($pluginsShortcut)>0){ ?>
	<div class="headerBarCell">
		<div id="headerShortcutMenu" class="contextMenu">
			<?php foreach($pluginsShortcut as $tmpPlugin){ ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/<?= $tmpPlugin->pluginIcon ?>"></div><div title="<?= @$tmpPlugin->pluginTitle ?>" onclick="<?= $tmpPlugin->pluginJsLabel ?>"><a><?= $tmpPlugin->pluginLabel ?></a></div></div>
			<?php }?>
		</div>
		<label class="menuLaunch" for="headerShortcutMenu"><?= Txt::trad("HEADER_shortcuts") ?></label> <img src="app/img/shortcut.png">
	</div>
	<?php } ?>

	<!--VALIDE L'INSCRIPTION D'UTILISATEURS-->
	<?php if(Ctrl::$curUser->isAdminCurSpace() && Db::getVal("SELECT count(*) FROM ap_userInscription WHERE _idSpace=".(int)Ctrl::$curSpace->_id)>0){ ?>
	<div class="headerBarCell">
		<a id="headerRegisterUser" title="<?= Txt::trad("usersInscriptionValidateInfo") ?>" onclick="lightboxOpen('?ctrl=user&action=registerUser');"><?= Txt::trad("usersInscriptionValidate") ?> <img src="app/img/check.png"></a>
		<script> $("#headerRegisterUser").effect("pulsate",{times:10},10000); </script>
	</div>
	<?php } ?>

	<!--MODULES-->
	<div class="headerBarCell vHeaderModulesCell">
		<!--MODULES-->
		<div id="headerModules" class="vHeaderModulesTab">
			<?php
			////	Liste les modules
			foreach($moduleList as $tmpModule)
			{
				$tmpModuleSelect=($tmpModule["isCurModule"]==true)  ?  "headerModuleSelect sLinkSelect"  :  "sLink";
				$tmpModuleIcon=(Ctrl::$agora->moduleLabelDisplay=="hide")  ?  "icon"  :  "iconSmall";
				echo "<div class=\"".$tmpModuleSelect." vHeaderModuleCell\" onclick=\"redir('".$tmpModule["url"]."')\" title=\"".$tmpModule["description"]."\">
						<img src='app/img/".$tmpModule["moduleName"]."/".$tmpModuleIcon.".png' class='vHeaderModuleIcon'>
						<label>".$tmpModule["label"]."</label>
					  </div>";
			}
			?>
		</div>
		<!--MENU LAUNCHER (responsive)-->
		<div id="headerModuleResp" class="menuLaunch" for="pageModMenu"></div>
	</div>

	<!-- LAUNCHER DU MENU RESPONSIVE DU MODULE-->
	<div class="headerBarCell menuLaunch" id="modMenuResp" for="headerModules"><img src="app/img/menuBig.png"></div>
</div>