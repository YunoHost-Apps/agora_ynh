<script type="text/javascript">
////	Captcha toujours en majuscule
$(function(){
	$("input[name='captcha']").on("change keyup",function(){
		$(this).val(this.value.toUpperCase());
	});
});

////	Controle du captcha
function captchaControl()
{
	if($(".vCaptchaText").isEmpty())  {notify("<?=Txt::trad("captchaSpecify") ?>");  return false;}
	var ajaxUrl="?ctrl=misc&action=CaptchaControl&captcha="+encodeURIComponent($(".vCaptchaText").val());
	var ajaxResult=$.ajax({url:ajaxUrl,async:false}).responseText;//Attend la réponse Ajax pour passer à la suite (async:false)
	if(ajaxResult!="true")	{notify("<?=Txt::trad("captchaError") ?>");  return false;}
	else					{return true;}
}
</script>

<style>
.vCaptchaLabel,.vCaptchaInput	{vertical-align:middle; display:inline-block;}
.vCaptchaReload		{cursor:pointer; width:15px; margin-right:10px;}
.vCaptchaArrow		{margin-left:5px; margin-right:5px;}
.vCaptchaText		{text-transform:uppercase; width:50px !important;}
</style>

<span title="<?= Txt::trad("captchaInfo") ?>">
	<div class="vCaptchaLabel">
		<?= Txt::trad("captcha") ?>
		<img src="app/img/reload.png" class="vCaptchaReload" title="reload !" onclick="$('.vCaptchaImg').attr('src','?ctrl=misc&action=CaptchaImg&rand='+Math.random())">
	</div>
	<div class="vCaptchaLabel">
		<img src="?ctrl=misc&action=CaptchaImg" class="vCaptchaImg">
		<img src="app/img/arrowRight.png" class="vCaptchaArrow">
		<input type="text" name="captcha" class="vCaptchaText">
	</div>
</span>