<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=2.0">

<style>
.objBlocks .objContainer				{height:130px; max-width:230px; min-width:140px;}
.objBlocks .hasThumb .objIcon img		{margin-top:0%; border-radius:4px;}
.objBlocks .thumbLandscape .objIcon img	{height:100%; width:100%;}
.objBlocks .pdfIcon						{position:absolute; top:0px; right:0px;}
.hasThumb a[rel='lightboxGallery']		{cursor:url("app/img/search.png"),all-scroll !important;}
.vVersionsMenu							{margin-left:5px;}
</style>

<div class="pageFull">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?php
			////	ARCBORESCENCE  &  AJOUT D'ELEMENT
			echo CtrlObject::folderTree();
			if(Ctrl::$curContainer->editContentRight()){
				echo "<div class='menuLine sLink' onclick=\"lightboxOpen('?ctrl=file&action=AddEditFiles&targetObjId=file&_idContainer=".Ctrl::$curContainer->_id."');\"><div class='menuIcon'><img src='app/img/plus.png'></div><div>".Txt::trad("FILE_ajouter_fichier")."</div></div>";
				if(Ctrl::$curContainer->addRight())  {echo "<div class='menuLine sLink' onclick=\"lightboxOpen('?ctrl=object&action=FolderEdit&targetObjId=".Ctrl::$curContainer->getType()."&_idContainer=".Ctrl::$curContainer->_id."')\"><div class='menuIcon'><img src='app/img/folderAdd.png'></div><div>".Txt::trad("addFolder")."</div></div>";}
				echo "<hr>";
			}
			////	MENU DE SELECTION, D'AFFICHAGE, DE TRI  &  DESCRIPTION DU CONTENU  &  ESPACE DISQUE
			echo MdlFile::menuSelectObjects().MdlFile::menuDisplayMode().MdlFile::menuSort();
			echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/info.png'></div><div>".Ctrl::$curContainer->folderContentDescription()."</div></div>";
			if(!empty($fillRateBar))  {echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/diskSpace".($diskSpaceAlert==true?"Alert":null).".png'></div><div>".$fillRateBar."</div></div>";}
			?>
		</div>
	</div>
	<div class="pageFullContent <?= (MdlFile::getDisplayMode()=="line"?"objLines":"objBlocks") ?>">
		<?php
		////	CHEMIN DU DOSSIER & LISTE DES DOSSIERS
		echo CtrlObject::folderPath().$foldersList;
		////	LISTE DES FICHIERS
		foreach($filesList as $tmpFile)
		{
			$downloadBlank=($tmpFile->octetSize>(File::sizeMo*2))  ?  "target='_blank'"  :  null;//Télécharge dans nouvelle fenêtre si supérieur à 2mo, pour pas bloquer la page
			echo $tmpFile->divContainer("objContentCenter").$tmpFile->contextMenu().
				"<div class=\"objContent ".$tmpFile->thumbClass."\">
					<div class='objIcon'><a ".$tmpFile->iconHref." title=\"".$tmpFile->iconTooltip."\"><img src=\"".$tmpFile->typeIcon()."\"></a></div>
					<div class='objLabel'><a href=\"".$tmpFile->urlDownloadDisplay()."\" ".$downloadBlank." title=\"".$tmpFile->tooltip."\">".Txt::reduce($tmpFile->name,75)."</a>".$tmpFile->versionsMenu("icon")."</div>
					<div class='objDetails'>".File::displaySize($tmpFile->octetSize)."</div>
					<div class='objAutor'>".$tmpFile->displayAutor()."</div>
					<div class='objDate'>".$tmpFile->displayDate(true,"date")."</div>
				</div>
			</div>";
		}
		////	AUCUN CONTENU
		if(empty($foldersList) && empty($filesList))	{echo "<div class='pageEmptyContent'>".Txt::trad("FILE_aucun_fichier")."</div>";}
		?>
	</div>
</div>