<script type="text/javascript">
////	Resize
lightboxWidth(650);

////	Archive la news si ya une date de mise en ligne (futur)
$(function(){
	$(".dateBegin").change(function(){
		//date d'aujourd'hui en ms
		var dateBegin=$(this).val().split("/");
		var timeBegin=new Date(dateBegin[1]+"/"+dateBegin[0]+"/"+dateBegin[2]);//attention au format : mois/jour/annee
		//Date "online" spécifié && supérieure à aujourd'hui &&  "offline" pas sélectionné
		if($(".dateBegin").isEmpty()==false && Date.now() < timeBegin.valueOf() && $("[name='offline']").prop("checked")==false){
			notify("<?= Txt::trad("DASHBOARD_dateOnlineNotif") ?>");
			$("[name='offline']").trigger("click");
		}
	});
});
</script>

<style>
.dateBegin, .dateEnd					{width:150px !important;}
input[name='une'],input[name='offline']	{display:none;}
</style>

<form action="index.php" method="post" onsubmit="return finalFormControl()" enctype="multipart/form-data" class="lightboxContent">
	<!--DESCRIPTION (EDITOR)-->
	<textarea name="description"><?= $objNews->description ?></textarea>

	<div class="lightboxInputs">
		<!--A LA UNE-->
		<div class="lightboxInputInline">
			<input type="checkbox" name="une" value="1" id="uneCheckbox" <?= $objNews->une==1?"checked":"" ?>>
			<img src="app/img/dashboard/une.png"> <label for="uneCheckbox" class="abbr" title="<?= Txt::trad("DASHBOARD_topNewsInfo") ?>"><?= Txt::trad("DASHBOARD_topNews") ?></label>	
		</div>
		<!--DATE ONLINE-->
		<div class="lightboxInputInline">
			<img src="app/img/dashboard/online.png">
			<input type="text" name="dateOnline" class="dateBegin" value="<?= Txt::formatDate($objNews->dateOnline,"dbDatetime","inputDate") ?>" placeholder="<?= Txt::trad("DASHBOARD_dateOnline") ?>" title="<?= Txt::trad("DASHBOARD_dateOnlineInfo") ?>">
		</div>
		<!--DATE OFFLINE-->
		<div class="lightboxInputInline">
			<img src="app/img/dashboard/offline.png">
			<input type="text" name="dateOffline" class="dateEnd" value="<?= Txt::formatDate($objNews->dateOffline,"dbDatetime","inputDate") ?>" placeholder="<?= Txt::trad("DASHBOARD_dateOffline") ?>" title="<?= Txt::trad("DASHBOARD_dateOfflineInfo") ?>">
		</div>
		<!--IS OFFLINE-->
		<div class="lightboxInputInline">
			<input type="checkbox" name="offline" value="1" id="offlineCheckbox" <?= $objNews->offline==1?"checked":null ?>>
			<label for="offlineCheckbox" class="abbr" title="<?= Txt::trad("DASHBOARD_offlineInfo") ?>"><?= Txt::trad("DASHBOARD_offline") ?></label> <img src="app/img/dashboard/offline.png"> 
		</div>
	</div>

	<!--MENU COMMUN-->
	<?= $objNews->menuEdit() ?>
</form>