<script type="text/javascript">
////	INIT
$(function(){
	//Init le menu de sélection de période des plugins ("News elements")
	$("#modMenuPlugin select").val("<?= $pluginPeriod ?>");
	//Hauteur max des news
	newsMaxHeight=1500;
	$("[id^='newsDescription']").css("max-height",newsMaxHeight);
	//News masqué en partie par l'overflow ? affiche le bouton "displayAll" avec un Timeout pour que le browser ait le tps de calculer le "scrollHeight"..
	setTimeout(function(){
		$("[id^='newsDescription']").each(function(){
			if($("#"+this.id)[0].scrollHeight > newsMaxHeight){
				var _idNews=this.id.replace("newsDescription","");
				$("#newsButtonFull"+_idNews).css("display","block");
			}
		});
	},300);
});
////	DEROULER UNE LONGUE ACTUALITE
function newsDisplayFull(_idNews)
{
	$("#newsDescription"+_idNews).css("max-height","none").css("overflow","visible");
	$("#newsButtonFull"+_idNews).css("display","none");
}
</script>

<style>
#modMenuPluginSelect			{text-align:center;}
#modMenuPluginSelect>span		{cursor:help;}
#modMenuPluginSelect>select		{margin:10px;}
#modMenuPluginSelect form		{<?= $pluginPeriod!="otherPeriod"?"display:none;":null ?>}
.vPluginModuleHeader			{margin-top:10px;}
.vPluginModuleHeader img		{float:right; margin-top:-8px; max-height:24px;}
#modMenuPlugin .menuIcon		{width:15px;}
#modMenuPlugin .menuIcon img	{max-width:15px;}
.newsBlock						{margin-bottom:10px;}
.newsUne						{box-shadow:4px 4px 6px #a55;}
.newsDatetime					{position:absolute; bottom:5px; right:5px; font-weight:bold; font-size:90%; font-style:italic; color:#999;}
[id^='newsDescription']			{font-weight:normal; padding:10px; min-height:40px; overflow:hidden;}
[id^='newsButtonFull']			{display:none; text-align:center;}
[id^='newsButtonFull'] button	{width:100%; height:25px; border-radius:0px;}
</style>

<div class="pageCenter">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<?php if(MdlDashboardNews::addRight()){ ?><div class="menuLine sLink" onclick="lightboxOpen('<?= MdlDashboardNews::getUrlNew() ?>');"><div class="menuIcon"><img src="app/img/plus.png"></div><div><?= Txt::trad("DASHBOARD_addNews") ?></div></div><?php } ?>
			<?php if(!empty($offlineNewsCount)){ ?><div class="menuLine <?= Req::getParam("offlineNews")==1?"sLinkSelect":"sLink" ?>" onclick="redir('?ctrl=dashboard&offlineNews=<?= Req::getParam("offlineNews")==1?"0":"1" ?>')"><div class="menuIcon"><img src="app/img/dashboard/offline.png"></div><div><?= Txt::trad("DASHBOARD_newsOffline")." ".$offlineNewsCount ?></div></div><?php } ?>
			<?= MdlDashboardNews::menuSort() ?>
			<hr>
			<!--PLUGIN : SELECTION DE PERIODE-->
			<div id="modMenuPlugin">
				<div id="modMenuPluginSelect">
					<span title="<?= $pluginPeriodTitle ?>"><img src="app/img/newObj.png"> <?= Txt::trad("DASHBOARD_newElems") ?></span> &nbsp; 
					<span title="<?= $pluginPeriodTitleCurrent ?>"><img src="app/img/newObj2.png"> <?= Txt::trad("DASHBOARD_currentElems") ?></span>
					<select onChange="if(this.value=='otherPeriod'){$('#modMenuPlugin form').fadeIn();}else{redir('?ctrl=dashboard&pluginPeriod='+this.value);}">
						<?php if(Ctrl::$curUser->isUser()){ ?><option value="connect" title="<?= $pluginConnectLabel ?>">..<?= Txt::trad("DASHBOARD_pluginSinceConnection") ?></option><?php } ?>
						<option value="day" title="<?= $pluginDayLabel ?>">..<?= Txt::trad("DASHBOARD_pluginOfDay") ?></option>
						<option value="week" title="<?= $pluginWeekLabel ?>">..<?= Txt::trad("DASHBOARD_pluginOfWeek") ?></option>
						<option value="month" title="<?= $pluginMonthLabel ?>">..<?= Txt::trad("DASHBOARD_pluginOfMonth") ?></option>
						<option value="otherPeriod"><?= Txt::trad("DASHBOARD_pluginOtherPeriod") ?></option>
					</select>
					<form action="index.php" method="post">
						<input type="text" name="pluginBegin" class="dateBegin" value="<?= date("d/m/Y",$pluginTimeBegin) ?>"> <img src="app/img/arrowRight.png">
						<input type="text" name="pluginEnd" class="dateEnd" value="<?= date("d/m/Y",$pluginTimeEnd) ?>">
						<input type="hidden" name="pluginPeriod" value="otherPeriod">
						<?= Txt::formValidate("OK",false) ?>
					</form>
				</div>
				<?php
				////	NOUVEAUX ELEMENTS DES MODULES (cf. plugins)
				if(empty($pluginsDashboard))	{echo "<div class='pluginEmpty'>".Txt::trad("DASHBOARD_pluginEmpty")."</div>";}
				else
				{
					foreach($pluginsDashboard as $tmpPlugin)
					{
						//Entête du block du module?
						if(empty($tmpModuleName) || $tmpModuleName!=$tmpPlugin->pluginModule){
							echo "<div class='vPluginModuleHeader'><hr><img src='app/img/".$tmpPlugin->pluginModule."/icon.png'></div>";
							$tmpModuleName=$tmpPlugin->pluginModule;
						}
						//Plugin Spécifique (exple: evts à confirmer) OU  Plugin "Objet"
						if(isset($tmpPlugin->pluginBlockMenu))    {echo $tmpPlugin->pluginBlockMenu;}
						else{
							if(!empty($tmpPlugin->pluginIsCurrent))  {$pluginIcon="newObj2.png";}  elseif(!empty($tmpPlugin->pluginIsFolder))  {$pluginIcon="folder.png";}  else  {$pluginIcon="newObj.png";}
							echo "<div class='menuLine vPluginModuleLine sLink'>
										<div class='menuIcon' onclick=\"".$tmpPlugin->pluginJsIcon."\"><img src='app/img/".$pluginIcon."'></div>
										<div title=\"".$tmpPlugin->pluginTitle."\" onclick=\"".$tmpPlugin->pluginJsLabel."\">".Txt::reduce($tmpPlugin->pluginLabel,100)."</div>
								  </div>";
						}
					}
				}
				?>
			</div>
		</div>
	</div>
	<div class="pageCenterContent">
		<?php
		//LISTE DES NEWS
		foreach($newsList as $tmpNews){
			echo $tmpNews->divContainer($tmpNews->une==1?'newsBlock newsUne':'newsBlock').$tmpNews->contextMenu();
		?>
				<div id="newsDescription<?= $tmpNews->_id?>">
					<?= $tmpNews->description ?>
					<div class="newsDatetime"><?= $tmpNews->displayTime.$tmpNews->displayStatus ?></div>
				</div>
				<?= $tmpNews->menuAttachedFiles() ?>
				<div id="newsButtonFull<?= $tmpNews->_id?>">
					<button  class="sLinkSelect" onclick="newsDisplayFull(<?= $tmpNews->_id?>)"><?= Txt::trad("displayAll") ?> <img src="app/img/arrowBottom.png"></button>
				</div>
			</div>
		<?php
		}
		//PAS DE NEWS
		if(empty($newsList))	{echo "<div class='pageEmptyContent'>".Txt::trad("DASHBOARD_noNews")."</div>";}
		?>
	</div>
</div>