<style>
/* BLOCKS DE CONTENU */
.objBlocks .objContainer{height:180px; min-width:350px; max-width:600px;}
.objContentScroll		{padding:10px;}
.vSpaceDescription		{font-weight:normal;}
.vModules				{margin-top:10px;}
.vModules img			{max-height:30px; margin-right:5px;}
.vLabelAffectations		{margin:5px 0px 5px 0px;}
.vSpaceAffectation		{display:inline-block; width:32%; margin:2px; font-size:85%;}
.vSpaceAffectation img	{max-height:18px;}
.vSpaceAffectationAll	{width:200px;}

/*RESPONSIVE -> 490px!*/
@media screen and (max-width:490px){
	.vSpaceAffectation	{width:48%;}
}
</style>

<div class="pageFull">
	<div class="pageModMenuContainer">
		<div id="pageModMenu" class="sBlock">
			<div class="menuLine sLink" onclick="lightboxOpen('<?= MdlSpace::getUrlNew() ?>');" title="<?= Txt::trad("SPACE_moduleInfo") ?>"><div class="menuIcon"><img src="app/img/plus.png"></div><div><?= Txt::trad("SPACE_addSpace") ?></div></div><hr>
			<?= MdlSpace::menuSort() ?>
			<div class="menuLine"><div class="menuIcon"><img src="app/img/info.png"></div><div><?= count($spaceList)." ".Txt::trad(count($spaceList)>1?"SPACE_spaces":"SPACE_space") ?></div></div>
		</div>
	</div>
	<div class="pageFullContent objBlocks">
		<?php
		////	LISTE DES ESPACES
		foreach($spaceList as $tmpSpace){
			echo $tmpSpace->divContainer().$tmpSpace->contextMenu(["confirmDeleteDouble"=>Txt::trad("SPACE_confirmDeleteDbl")]);
		?>
			<div class="objContentScroll">
				<?php
				////	NOM & DESCRIPTION & MODULES AFFECTES
				echo $tmpSpace->name."<div class='vSpaceDescription'>".$tmpSpace->description."</div>";
				echo "<div class='vModules'>";
					foreach($tmpSpace->moduleList(false) as $tmpModule)  {echo "<img src='app/img/".$tmpModule["moduleName"]."/icon.png' title=\"".$tmpModule["description"]."\">";}
				echo "</div><hr>";
				echo "<div class='vLabelAffectations'>".Txt::trad("EDIT_accessRight")." :</div>";
				////	DROITS D'ACCES A DEFINIR
				if(count($tmpSpace->getUsers())==0 && $tmpSpace->allUsersAffected()==false && empty($tmpSpace->public))  {echo "<div class='labelInfos'>".Txt::trad("SPACE_accessRightUndefined")."</div>";}
				////	ESPACE PUBLIC  /  TOUS LES USERS AFFECTES
				if(!empty($tmpSpace->public))		{echo "<div class='vSpaceAffectation'><img src='app/img/public.png'> ".Txt::trad("SPACE_publicSpace")."</div>";}
				if($tmpSpace->allUsersAffected())	{echo "<div class='vSpaceAffectation vSpaceAffectationAll'><img src='app/img/user/icon.png'> ".Txt::trad("SPACE_allUsers")."</div>";}
				////	USERS AFFECTES
				foreach($tmpSpace->getUsers() as $tmpUser){
					$userRightAcces=$tmpSpace->userAccessRight($tmpUser);
					if($tmpSpace->allUsersAffected() && $userRightAcces==1)	{continue;}//Pas d'affichage si simple user et tous les users sont affectés
					echo "<div class='vSpaceAffectation sLink' onclick=\"lightboxOpen('".$tmpUser->getUrl("vue")."');\"><img src='app/img/user/".($userRightAcces==2?'adminSpace.png':'accesUser.png')."'> ".$tmpUser->display()."</div>";
				}
				?>
			</div>
		</div>
		<?php } ?>
	</div>
</div>