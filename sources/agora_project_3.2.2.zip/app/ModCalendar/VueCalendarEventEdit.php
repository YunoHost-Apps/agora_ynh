<script type="text/javascript">
////	Resize
lightboxWidth(550);

//Init la page
$(function(){
	////	INIT LA PAGE
	//Bloque les détails de l'agenda si l'evt n'est pas en accès total
	<?php if($curObj->fullRight()==false){ ?>
	$(".dateBegin,.dateEnd").datepicker("option","disabled",true);
	$(".vEventDetails input").prop("readonly",true);
	$(".vEventDetails select").prop("disabled",true);
	<?php } ?>
	//Les guests n'ont pas accès aux options d'evt
	<?php if(Ctrl::$curUser->isUser()==false){ ?>
		$("#evtPeriodType,#evtOptions,.optionsAffect").hide();
	<?php } ?>
	//Prérempli la valeur des champs
	$("select[name='periodType']").val("<?= $curObj->periodType ?>");
	$("select[name='contentVisible']").val("<?= $curObj->contentVisible ?>");
	$("select[name='_idCat']").val("<?= $curObj->_idCat ?>").trigger("change");//"trigger" pour changer la couleur de l'input
	$("select[name='important']").val("<?= (int)$curObj->important ?>").trigger("change");//valeur au format "integer". "trigger" pour changer la couleur de l'input
	//Background des lignes avec affectation
	$("[name='proposedCalendars[]']:checked,[name='affectationCalendars[]']:checked").each(function(){
		$(this).parent().parent().addClass("sTableRowSelect");
	});
	//Périodicité & Créneau occupés
	displayPeriodType();
	timeSlotBusy();

	////	Change la date/heure/périodicité :  Controle des créneaux horaires occupés  &&  Affiche les details de périodicité?
	$("[name='dateBegin'],[name='timeBegin'],[name='dateEnd'],[name='timeEnd']").change(function(){ timeSlotBusy(); });
	$("[name='periodType'],[name='dateBegin']").change(function(){ displayPeriodType(); });

	////	Coche/décoche une affectation (ou proposition) à un agenda
	$("[name='proposedCalendars[]'],[name='affectationCalendars[]']").change(function(){
		var tmpSelection=find("propose",this.id) ? "#affectationCalendars" : "#proposedCalendars";
		$(tmpSelection+this.value).prop("checked",false);
		if(this.checked)	{$(this).parent().parent().addClass("sTableRowSelect");}
		else				{$(this).parent().parent().removeClass("sTableRowSelect");}
		if(this.checked && find("propose",this.id))  {notify("<?= Txt::trad("CALENDAR_inputProposed") ?>");}
		timeSlotBusy();
	});

	////	Inverse la sélection des agendas
	$("#invertSelection").click(function(){
		$("[name='affectationCalendars[]']:enabled").prop("checked",!$("[name='affectationCalendars[]']:enabled").prop("checked")).trigger("change");
	});

	////	Sélection d'un groupe d'users
	$("[name='groupList[]']").on("change",function(){
		//Pour chaque user du groupe : check/uncheck ?
		var curGroupUserIds=$(this).val().split(",");
		for(var tmpKey in curGroupUserIds)
		{
			var tmpUserId=curGroupUserIds[tmpKey];
			tmpUserCheckedInOtherGroup=false;
			//User est dans un autre groupe déjà sélectionné
			$("[name='groupList[]']:checked").not(this).each(function(){
				var tmpGroupUserIds=$(this).val().split(",");
				if($.inArray(tmpUserId,tmpGroupUserIds)!=-1)	{tmpUserCheckedInOtherGroup=true;}
			});
			//Check l'user (actif) si le groupe courant est checked OU si l'user est dans un autre groupe checked
			var tmpUserCheck=($(this).prop("checked") || tmpUserCheckedInOtherGroup==true)  ?  true  :  false;
			$("[name='affectationCalendars[]'][data-type='user'][data-idUser='"+tmpUserId+"']:enabled").prop("checked",tmpUserCheck).trigger("change");//"trigger" pour gérer le style de la sélection
		}
	});
});

////	Gère l'affichage de la périodicité
function displayPeriodType()
{
	//Réinitialise les options de périodicité & Affiche au besoin l'options sélectionnée
	$("[id^=periodTypeOption_").hide();
	$("#blockPeriodDateEndExceptions").hide();
	if($("[name='periodType']").isEmpty()==false){
		$("#periodTypeOption_"+$("[name='periodType']").val()).show();
		$("#blockPeriodDateEndExceptions").show();
	}
	//Affiche les détails de périodicité (exple : "le 15 du mois")
	var periodTypeOptionDetails="";
	if($("[name='periodType']").val()=="month")	{periodTypeOptionDetails="<?= Txt::trad("the") ?> "+$("[name='dateBegin']").val().substr(0,2)+" <?= Txt::trad("CALENDAR_period_dayOfMonth") ?> ";}//"le 15 du mois"
	if($("[name='periodType']").val()=="year")	{periodTypeOptionDetails="<?= Txt::trad("the") ?> "+$("[name='dateBegin']").val().substr(0,5);}//"le 15/10"
	$("#periodTypeOptionDetails").html(periodTypeOptionDetails);
	//Masque les exceptions de périodicité vides
	$("[id^='divPeriodDateExceptions']").each(function(){
		if($("#"+this.id.replace("div","input")).isEmpty())	{$(this).hide();}
	});
}

////	Supprime une "PeriodDateExceptions"
function deletePeriodDateExceptions(exceptionCpt)
{
	var inputSelector="#inputPeriodDateExceptions"+exceptionCpt;
	if($(inputSelector).isEmpty() || ($(inputSelector).isEmpty()==false && confirm("<?= Txt::trad("delete") ?>?"))){
		$(inputSelector).val("");
		$("#divPeriodDateExceptions"+exceptionCpt).hide();
	}
}

////	Controle occupation créneaux horaires des agendas sélectionnés : en AJAX
function timeSlotBusy()
{
	//delay de prise en charge multiple (2sec max!)
	var timeSlotDelay=1000;
	//"timeSlotBusy()" lance avec un décallage pour limiter le nb de requêtes Ajax : cf. check rapide d'agendas ou de groupe d'agendas
	if(typeof timeSlotClick!="undefined" && (Date.now()-timeSlotClick)<timeSlotDelay)
	{
		timeSlotClick=Date.now();//ne pas mettre en tout debut de fonction
		if(typeof timeSlotTimeout!="undefined")  {clearTimeout(timeSlotTimeout);}//annule le dernier "setTimeout" (pas de cumul)
		timeSlotTimeout=setTimeout(function(){timeSlotBusy();}, (timeSlotDelay+1));//lance avec un décallage supérieur : le controle AJAX sera activé s'il n'y a pas de click dans la foulee (<2sec)
	}
	//Si le dernier click date de + de 1 sec : on lance le controle
	else
	{
		////notify("CONTROL!");//test
		timeSlotClick=Date.now();//ne pas mettre en tout debut de fonction
		//Prépare la requete de controle Ajax, avec la liste des Agendas sélectionnés : affectations accessibles en écriture
		if($("[name='dateBegin']").isEmpty()==false && $("[name='dateEnd']").isEmpty()==false)
		{
			var ajaxUrl="?ctrl=calendar&action=timeSlotBusy&dateTimeBegin="+encodeURIComponent($("[name='dateBegin']").val()+" "+$("[name='timeBegin']").val())+
						"&dateTimeEnd="+encodeURIComponent($("[name='dateEnd']").val()+" "+$("[name='timeEnd']").val())+
						"&_evtId=<?= $curObj->_id ?>&targetObjects[calendar]=";
			$("[name='proposedCalendars[]']:checked,[name='affectationCalendars[]']:checked").each(function(){ ajaxUrl+=this.value+"-"; });
			//Lance le controle Ajax et renvoie les agendas où le créneau est occupé
			$.ajax(ajaxUrl).done(function(ajaxResult){
				if(ajaxResult.length>0)	{$("#timeSlotBusy").fadeIn();  $(".vTimeSlotBusyTable").html(ajaxResult); }
				else					{$("#timeSlotBusy").hide();}
			});
		}
	}
}

////	Contrôle du formulaire
function formControl()
{
	//Controle le nombre d'affectations
	if($("[name='proposedCalendars[]']:checked").isEmpty() && $("[name='affectationCalendars[]']:checked").isEmpty())
		{notify("<?= Txt::trad("CALENDAR_verifCalNb") ?>");  return false;}
	//Controle final (champs obligatoires, affectations/droits d'accès, etc)
	return finalFormControl();
}
</script>

<style>
#blockDescription						{margin-top:15px; <?= empty($curObj->description)?"display:none;":null ?>}
.vEventDetails							{text-align:center;}
#evtOptions								{margin-top:15px;}
.vEvtOptions							{margin-left:15px; margin-top:5px; display:inline-block;}
#evtOptions .vEvtOptions:first-child	{margin-left:0px;}
.vEvtOptions select						{max-width:170px;}
/*PÉRIODICITÉ*/
#periodTypeOptionDetails							{font-size:90%; text-decoration:underline;}
[id^='periodTypeOption_']							{display:none; margin-top:15px;}
#periodTypeOption_monthDay, #periodTypeOption_month	{text-align:left;}
.vPeriodTypeOptionVal								{display:inline-block; margin-left:10px;}
#periodTypeOption_monthDay .vPeriodTypeOptionVal	{width:35px; font-size:90%;}
#periodTypeOption_month .vPeriodTypeOptionVal		{width:22%;}
#blockPeriodDateEndExceptions						{display:none; margin-top:10px; text-align:center;}
#blockPeriodDateExceptions							{display:inline-block; vertical-align:middle;}
[id^='divPeriodDateExceptions']						{margin-top:5px;}
#blockPeriodDateEnd									{display:inline-block; margin-left:15px;}
/*EVTOPTIONS*/
#evtOptions					{text-align:center;}
.vContentVisibleTitle		{text-align:left;}
/*AFFECTATION AUX AGENDAS*/
#invertSelection			{max-height:16px;}
.vAffectationCalendars		{max-height:150px; overflow-y:auto;}
.vAffectationHr				{margin:5px!important;}
.vAffectationBlock			{display:inline-table; width:45%; padding:4px; margin-right:10px; font-size:90%; border-radius:5px;}
.vAffectationBlock>div		{display:table-cell; vertical-align:top;}
.vAffectationBlock>div:first-child	{width:45px; text-align:right;}
.vAffectationBlock img		{max-height:18px;}
input[name='proposedCalendars[]']		{margin:0px; margin-left:4px!important;}
input[name='affectationCalendars[]']	{margin:0px; visibility:hidden;}
[name='groupList[]']		{display:none;}
/*DÉTAILS SUR L'AFFECTATION*/
#timeSlotBusy				{display:none; font-size:90%;}
.vTimeSlotBusyTable			{display:table; margin-top:6px;}
.vTimeSlotBusyRow			{display:table-row;}/*cf. "actionTimeSlotBusy()"*/
.vTimeSlotBusyCell			{display:table-cell; padding:4px; vertical-align:middle;}/*idem*/

/*RESPONSIVE -> 490px!*/
@media screen and (max-width:490px){
	select[name="periodType"], select[name="contentVisible"]	{margin-top:10px;}
	.vAffectationBlock		{width:95%;}
}
</style>

<form action="index.php" method="post" onsubmit="return formControl()" enctype="multipart/form-data" class="lightboxContent">

	<!--PAS D'ACCES AUX DETAILS A L'EVT : MESSAGE-->
	<?php if($curObj->fullRight()==false){ ?>
		<div class="labelInfos"><img src="app/img/info.png"> <?= Txt::trad("CALENDAR_editLimit") ?></div><br>
	<?php } ?>
	
	<div class="vEventDetails">

		<!--TITRE & DESCRIPTION (EDITOR)-->
		<input type="text" name="title" value="<?= $curObj->title ?>" class="textBig" placeholder="<?= Txt::trad("title") ?>">
		<img src="app/img/description.png" class="sLink" title="<?= Txt::trad("description") ?>" onclick="$('#blockDescription').slideToggle()">
		<div id="blockDescription">
			<textarea name="description" placeholder="<?= Txt::trad("description") ?>"><?= $curObj->description ?></textarea>
		</div>
		<br><br>

		<!--DATE DEBUT & FIN-->
		<input type="text" name="dateBegin" class="dateBegin" value="<?= Txt::formatDate($curObj->dateBegin,"dbDatetime","inputDate") ?>" placeholder="<?= Txt::trad("begin") ?>">
		<input type="text" name="timeBegin" class="timeBegin" value="<?= Txt::formatDate($curObj->dateBegin,"dbDatetime","inputHM") ?>" placeholder="H:m">
		<img src="app/img/arrowRight.png">
		<input type="text" name="dateEnd" class="dateEnd" value="<?= Txt::formatDate($curObj->dateEnd,"dbDatetime","inputDate") ?>" placeholder="<?= Txt::trad("end") ?>">
		<input type="text" name="timeEnd" class="timeEnd" value="<?= Txt::formatDate($curObj->dateEnd,"dbDatetime","inputHM") ?>" placeholder="H:m">

		<!--EVENEMENT PERIODIQUE (pas pour les guests)-->
		<span id="evtPeriodType">
			<span class="vEvtOptions">
				<select name="periodType">
					<option value=""><?= Txt::trad("CALENDAR_noPeriodicity") ?></option>
					<option value="weekDay"><?= Txt::trad("CALENDAR_period_weekDay") ?></option>
					<option value="month"><?= Txt::trad("CALENDAR_period_month") ?></option>
					<option value="monthDay"><?= Txt::trad("CALENDAR_period_monthDay") ?></option>
					<option value="year"><?= Txt::trad("CALENDAR_period_year") ?></option>
				</select>
			</span>
		</span>

		<!--DETAIL DE PERIODICITE (exple: "le 15 du mois"-->
		<span id="periodTypeOptionDetails"></span>
		<!--JOURS DE LA SEMAINE-->
		<div id="periodTypeOption_weekDay">
			<?php for($cpt=1; $cpt<=7; $cpt++){ ?>
			<div class="vPeriodTypeOptionVal">
				<input type="checkbox" name="periodValues_weekDay[]" value="<?= $cpt ?>" id="periodValues_weekDay<?= $cpt ?>" <?= ($curObj->periodType=="weekDay" && in_array($cpt,$tabPeriodValues))?"checked":null ?> >
				<label for="periodValues_weekDay<?= $cpt ?>"><?= Txt::trad("day_".$cpt) ?></label>
			</div>
			<?php } ?>
		</div>

		<!--JOURS DU MOIS-->
		<div id="periodTypeOption_monthDay">
			<?php for($cpt=1; $cpt<=31; $cpt++){ ?>
			<div class="vPeriodTypeOptionVal">
				<input type="checkbox" name="periodValues_monthDay[]" value="<?= $cpt ?>" id="periodValues_monthDay<?= $cpt ?>" <?= ($curObj->periodType=="monthDay" && in_array($cpt,$tabPeriodValues))?"checked":null ?>>
				<label for="periodValues_monthDay<?= $cpt ?>"><?= $cpt ?></label>
			</div>
			<?= ($cpt==10 || $cpt==20)?"<br>":null ?>
			<?php } ?>
		</div>

		<!--MOIS DE L'ANNEE-->
		<div id="periodTypeOption_month">
			<?php for($cpt=1; $cpt<=12; $cpt++){ ?>
			<div class="vPeriodTypeOptionVal">
				<input type="checkbox" name="periodValues_month[]" value="<?= $cpt ?>" id="periodValues_month<?= $cpt ?>" <?= ($curObj->periodType=="month" && in_array($cpt,$tabPeriodValues))?"checked":null ?>>
				<label for="periodValues_month<?= $cpt ?>"><?= Txt::trad("month_".$cpt) ?></label>
			</div>
			<?php } ?>
		</div>

		<!--FIN DE PERIODICITE & EXCEPTIONS DE PERIODICITE (10 maxi)-->
		<div id="blockPeriodDateEndExceptions">
			<div id="blockPeriodDateExceptions">
				<span class="vEvtOptions">
					<span class="sLink" onclick="$('[id^=divPeriodDateExceptions]:hidden').first().show()"><?= Txt::trad("CALENDAR_periodException") ?> <img src="app/img/plusSmall.png"></span>
					<?php for($cpt=1; $cpt<=10; $cpt++){ ?>
					<div id="divPeriodDateExceptions<?= $cpt ?>">
						<input type="text" name="periodDateExceptions[]" value="<?= isset($periodDateExceptions[$cpt])?$periodDateExceptions[$cpt]:null ?>" class="dateInput" id="inputPeriodDateExceptions<?= $cpt ?>">
						<img src="app/img/delete.png" title="<?= Txt::trad("delete") ?>" class="sLink" onclick="deletePeriodDateExceptions(<?= $cpt ?>)">
					</div>
					<?php } ?>
				</span>
			</div>
			<div id="blockPeriodDateEnd">
				<?= Txt::trad("CALENDAR_periodDateEnd") ?> <input type="text" name="periodDateEnd" class="dateInput" value="<?= Txt::formatDate($curObj->periodDateEnd,"dbDate","inputDate") ?>">
			</div>
		</div>
		
		<!--IMPORTANT / VISIBILITE / CATEGORIE-->
		<div id="evtOptions">
			<span class="vEvtOptions">
				<?= Txt::trad("CALENDAR_category") ?>
				<select name="_idCat">
					<option value=""></option>
					<?php foreach(MdlCalendarEventCategory::getCategories() as $tmpCat){ ?>
					<option value="<?= $tmpCat->_id ?>" data-color="<?= $tmpCat->color ?>"><?= $tmpCat->title ?></option>
					<?php } ?>
				</select>
			</span>
			<span class="vEvtOptions">
				<?= Txt::trad("important") ?>
				<select name="important">
					<option value="0"><?= Txt::trad("no") ?></option>
					<option value="1" data-color="#900"><?= Txt::trad("yes") ?></option>
				</select>
			</span>
			<span class="vEvtOptions">
				<select name="contentVisible" title="<div class='vContentVisibleTitle'><?= Txt::trad("CALENDAR_visibilityInfo") ?></div>">
					<option value="public"><?= Txt::trad("CALENDAR_visibilityPublic") ?></option>
					<option value="public_cache"><?= Txt::trad("CALENDAR_visibilityPublicHide") ?></option>
					<option value="prive"><?= Txt::trad("CALENDAR_visibilityPrivate") ?></option>
				</select>
			</span>
		</div>
	</div>

	<!--AFFECTATIONS-->
	<div class="lightboxBlockTitle optionsAffect"><?= Txt::trad("CALENDAR_calendarAffectations") ?> <img src="app/img/switch.png" id="invertSelection" class="sLink" title="<?= Txt::trad("invertSelection") ?>"></div>
	<div class="lightboxBlock optionsAffect">
		<?php
		////	LISTE DES AGENDAS
		echo "<div class='vAffectationCalendars'>";
		foreach(MdlCalendar::affectationCalendars() as $tmpCalendar)
		{
			if(!empty($tmpType) && $tmpType!=$tmpCalendar->type)	{echo "<hr class='vAffectationHr'>";}
			$tmpType=$tmpCalendar->type;
			echo "<div class='vAffectationBlock sTableRow'>";
				echo "<div>";
					if($tmpCalendar->calAffectReinit==true)	{echo "<input type='hidden' name='calAffectReinit[]' value=\"".$tmpCalendar->_id."\">";}
					if($tmpCalendar->isMyPerso()==false)	{echo "<label for=\"proposedCalendars".$tmpCalendar->_id."\">?</label><input type='checkbox' name='proposedCalendars[]' value=\"".$tmpCalendar->_id."\" ".$tmpCalendar->checkProposed." ".$tmpCalendar->disablePropose." id=\"proposedCalendars".$tmpCalendar->_id."\" title=\"".Txt::trad("CALENDAR_inputPropose")."\">";}
					echo "<input type='checkbox' name='affectationCalendars[]' value=\"".$tmpCalendar->_id."\" ".$tmpCalendar->checkAffectation." ".$tmpCalendar->disableAffect." id=\"affectationCalendars".$tmpCalendar->_id."\" data-type=\"".$tmpCalendar->type."\" data-idUser=\"".$tmpCalendar->_idUser."\" title=\"".Txt::trad("CALENDAR_inputAffect")."\">";
				echo "</div>";
				echo "<div><label for=\"affectationCalendars".$tmpCalendar->_id."\" title=\"".$tmpCalendar->tooltip."\">".$tmpCalendar->title."</label></div>";
			echo "</div>";
		}
		echo "</div>";
		////	GROUPES d'UTILISATEURS
		if(!empty($userGroups))  {echo "<hr class='vAffectationHr'>";}
		foreach($userGroups as $tmpGroup){
			echo "<div class='vAffectationBlock sLink' title=\"".Txt::trad("selectUnselect")." :<br>".$tmpGroup->usersLabel."\">
					<input type='checkbox' name=\"groupList[]\" value=\"".implode(",",$tmpGroup->userIds)."\" id='box".$tmpGroup->_targetObjId."'>
					<label for='box".$tmpGroup->_targetObjId."'><img src='app/img/user/userGroup.png'> ".$tmpGroup->title."</label>
				  </div>";
		}
		?>
		<!--CRENEAU HORAIRE OCCUPE?-->
		<div id="timeSlotBusy" class="sAccessWriteLimit">
			<hr><?= Txt::trad("CALENDAR_busyTimeslot") ?>
			<div class="vTimeSlotBusyTable"></div>
		</div>
	</div>

	<!--MENU COMMUN-->
	<?= $curObj->menuEdit() ?>
</form>