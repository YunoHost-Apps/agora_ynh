<?php if($cptCal==0){ ?>
<style>
.vCalMonthMain						{display:table; width:100%; height:100%;}
.vCalMonthMain>div					{display:table-row;}
.vCalMonthMain>div>div				{display:table-cell;}
.vCalMonthMain>div:first-child		{height:15px;}/*ligne du header*/
.vCalMonthWeekNb					{color:#999; text-align:center; vertical-align:middle; width:20px;}
.vCalMonthWeekNb:hover				{background:#e9e9e9;}
.vCalMonthDayHeader					{text-align:center;}
.vCalMonthDayCell					{background:#fff; border-top:solid 1px #ddd; border-bottom:solid 1px #fff; border-left:solid 1px #ccc;}
.vCalMonthOldDate,.vCalMonthOtherMonth	{background:#f9f9f9;}
.vCalMonthDayCellLabel				{color:#222; padding:3px; text-align:right; border-bottom:dotted #eee 1px;}
.vCalMonthDayCellLabel:hover		{background:#ddd;}
.vCalMonthToday						{color:#d00; background:#f9f9f9; border-bottom:solid 1px #fdd;}
.vCalMonthOtherMonth .vCalMonthDayCellLabel	{color:#aaa;}
.vCalMonthDayCelebration			{float:left; color:#070; font-style:italic;}
.vCalMonthDayCellAddEvt				{display:none;}
.vCalMonthDayCellLabel:hover .vCalMonthDayCellAddEvt	{display:inline;}

/*RESPONSIVE*/
@media screen and (max-width:1024px){
	.vCalMonthWeekNb, .vCalMonthDayCelebration, .vCalEvtLabel img	{display:none!important;}
	.vCalMonthDayCellAddEvt	{float:left; display:block; opacity:0.3; filter:grayscale(100%)}
}

/* IMPRESSION */
@media print{
	.vCalMonthMain			{display:table; max-height:620px!important;}
	.vCalMonthDaysLine		{height:auto!important;}
	.vCalMonthWeekNb		{display:none!important;}
	.vCalMonthOtherMonth	{color:#ddd;}
	.vCalMonthDayCell		{color:#222; border:solid 1px #ddd;}
	.vCalMonthDayCellLabel	{border:none!important;}
}
</style>

<script>
////	Gère l'affichage de la vue "month" (cf. "calendarInitVue()")
function calendarDimensions()
{
	//largeur/hauteur des jours
	$(".vCalMonthDayHeader,.vCalMonthDayCell").css("width", Math.round(($(".vCalMonthMain").width()-$(".vCalMonthWeekNb").width()) / 7));
	var lineHeight=Math.round($(".vCalMonthMain:first").height() / $(".vCalMonthMain:first .vCalMonthDaysLine").length)-4;//-4 pour prendre en compte le border
	$(".vCalMonthDaysLine").css("height", lineHeight+"px");

	//Redimentionne "vCalendarBlock" si la hauteur réelle est supérieure à "availableContentHeight()"
	$(".vCalendarBlock").each(function(){
		var realHeight=$(this).find(".vCalendarHeader").height() + $(this).find(".vCalMonthMain").height() -2;
		if($(this).innerHeight()<realHeight)	{$(this).css("height",realHeight);}
	});
}
</script>
<?php } ?>


<div class="vCalMonthMain">
	<!--HEADER DES JOURS-->
	<div>
		<div class="vCalMonthWeekNb">&nbsp;</div>
		<?php
		for($cmpDay=1; $cmpDay<=7; $cmpDay++){
			$dayLabel=Txt::trad("day_".$cmpDay);
			if(Tool::isMobile())	{$dayLabel=substr($dayLabel,0,3).".";}
			echo "<div class='vCalMonthDayHeader'>".$dayLabel."</div>";
		}
		?>
	</div>

	<?php
	////	JOURS DU MOIS
	foreach($periodDays as $tmpDay)
	{
		////	LIGNE DE LA SEMAINE + Numéro de semaine-->
		if(date("N",$tmpDay["timeBegin"])==1)	{echo "<div class='vCalMonthDaysLine'><div class='vCalMonthWeekNb sLink' onClick=\"redir('?ctrl=calendar&displayMode=week&curTime=".$tmpDay["timeBegin"]."')\" title=\"".Txt::trad("CALENDAR_weekNb")." ".date("W",$tmpDay["timeBegin"])."\">".date("W",$tmpDay["timeBegin"])."</div>";}
		////	CELLULE DU JOUR
		echo "<div class='vCalMonthDayCell ".$tmpDay["dayClass"]."'>
				<div class='vCalMonthDayCellLabel sLink ".$tmpDay["vCalMonthToday"]."' onClick=\"lightboxOpen('".$tmpDay["urlEditNew"]."&_idCal=".$tmpCal->_id."')\" title=\"".$txtAddEvt.$txtAddEvtPropose."\">
					<div class='vCalMonthDayCelebration'>".$tmpDay["celebrationDay"]."</div>".
					date("j",$tmpDay["timeBegin"])." <img src='app/img/plusSmall2.png' class='vCalMonthDayCellAddEvt'>
				</div>";
				////	EVENEMENTS DU JOUR
				foreach($eventList[$tmpDay["date"]] as $tmpEvt)
				{
					$tmpEvtTitle=Tool::isMobile()  ?  Txt::reduce($tmpEvt->title,25)  :  Txt::reduce($tmpEvt->title,60);
					if(!empty($tmpEvt->important))	{$tmpEvtTitle.=" <img src='app/img/important.png'>";}
					echo $tmpEvt->divContainer("vCalEvtBlock","data-catColor='".$tmpEvt->catColor."'").$tmpEvt->contextMenu(["inlineLauncher"=>true,"_idCal"=>$tmpCal->_id,"curDateTime"=>strtotime($tmpEvt->dateBegin)])."
						<div class='vCalEvtLabel' onclick=\"lightboxOpen('".$tmpEvt->getUrl("vue")."')\">".Txt::displayDate($tmpEvt->dateBegin,"mini",$tmpEvt->dateEnd)." ".$tmpEvtTitle."</div>
					 </div>";
				}
			echo "</div>";
		////	FIN DE LIGNE DE LA SEMAINE
		if(date("N",$tmpDay["timeBegin"])==7)	{echo "</div>";}
	}
	?>
</div>