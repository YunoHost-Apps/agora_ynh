<script type="text/javascript">
lightboxWidth(600);//Resize
</script>

<style>
.vEventDescription	{margin-top:10px; font-weight:normal;}
.vEventDetails		{line-height:20px;}
.percentBar			{margin:10px 15px 0px 0px;}/*Surcharge common.css*/
</style>

<div class="lightboxContent">
	<!--ICONE EDIT / DATE / PERIODICITE-->
	<div class="lightboxObjTitle">
		<?php
		if($curObj->editRight())	{echo "<a href=\"javascript:lightboxOpen('".$curObj->getUrl("edit")."')\" class='lightboxObjEditIcon' title=\"".Txt::trad("modify")."\"><img src='app/img/edit.png'></a>";}
		echo Txt::displayDate($curObj->dateBegin,"full",$curObj->dateEnd);
		if(!empty($labelPeriod))	{echo "<br>".$labelPeriod;}
		?>
	</div>
	
	<!--TITRE / DESCRIPTION / CATEGORIE-->
	<hr>
	<div class="vEventTitle">
		<?= !empty($labelCategory) ? $labelCategory." : " : null ?>
		<?= $curObj->title ?>
		<?= !empty($curObj->important) ? "<img src='app/img/important.png' title=\"".Txt::trad("important")."\"" : null?>
	</div>
	<div class="vEventDescription"><?= $curObj->description ?></div>
	
	<!--VISIBILITE / AFFECTATIONS AUX AGENDAS / FICHIERS JOINTS-->
	<?= !empty($contentVisible) ? "<hr>".$contentVisible : null ?>
	<hr>
	<?= $curObj->affectedCalendarsLabel() ?>
	<?= $curObj->menuAttachedFiles("<hr>") ?>
</div>