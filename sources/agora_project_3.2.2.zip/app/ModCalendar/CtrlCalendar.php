<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Controleur du module "Calendar"
 */
class CtrlCalendar extends Ctrl
{
	const moduleName="calendar";
	public static $moduleOptions=["ajout_agenda_ressource_admin","ajout_categorie_admin"];
	public static $MdlObjects=array("MdlCalendar","MdlCalendarEvent");

	/*
	 * ACTION PAR DEFAUT
	 */
	public static function actionDefault()
	{
		////	AGENDAS VISIBLES (TOUS?)  &&  AGENDAS AFFICHES  &&  EVT PROPOSÉS
		$vDatas["displayAllCals"]=(Req::getParam("displayAllCals")==1 && Ctrl::$curUser->isAdminGeneral())  ?  true  :  false;
		$vDatas["visibleCalendars"]=($vDatas["displayAllCals"]==true)  ?  MdlCalendar::affectationCalendars()  :  MdlCalendar::visibleCalendars();
		$vDatas["displayedCalendars"]=MdlCalendar::displayedCalendars($vDatas["visibleCalendars"]);
		$vDatas["menuProposedEvents"]=self::menuProposedEvents();
		////	MODE D'AFFICHAGE (day / 3Days / workWeek / week / month)  &  TEMPS DE RÉFÉRENCE  &  JOURS FÉRIÉS
		$displayMode=self::prefUser("calendarDisplayMode","displayMode");
		if(empty($displayMode))  {$displayMode=(Tool::isMobile()) ? "3Days":"month";}
		$vDatas["displayMode"]=$displayMode;
		$vDatas["curTime"]=$curTime=(Req::isParam("curTime")) ? Req::getParam("curTime") : time();
		$vDatas["celebrationDays"]=Trad::celebrationDays(date("Y",$curTime));
		////	AFFICHAGE : PREPARE LES TIMES/DATES, 
		//AFFICHAGE MOIS
		if($displayMode=="month"){
			$vDatas["timeBegin"]=strtotime(date("Y-m",$curTime)."-01 00:00");
			$vDatas["timeEnd"]  =strtotime(date("Y-m",$curTime)."-".date("t",$curTime)." 23:59");
			$vDatas["timePrev"]=strtotime("-1 month",$curTime);
			$vDatas["timeNext"]=strtotime("+1 month",$curTime);
			$vDatas["timeDisplayedBegin"]=strtotime("-".(date("N",$vDatas["timeBegin"])-1)." days", $vDatas["timeBegin"]);//Commence tjs par un lundi. Si le mois commence par un mercredi, on enlève 2 jours pour le lundi/mardi du mois précédent
			$vDatas["timeDisplayedEnd"]=strtotime("+".(7-date("N",$vDatas["timeEnd"]))." days", $vDatas["timeEnd"]);	  //Termine tjs l'affichage par un dimanche. Idem mais pour la fin du mois
		}
		//AFFICHAGE SEMAINE / SEMAINE DE TRAVAIL
		elseif(preg_match("/week/i",$displayMode)){
			$weekTimeBegin=strtotime("-".(date("N",$curTime)-1)." days",$curTime);//lundi=0 => dimanche=6
			$weekTimeEnd=($displayMode=="week") ? strtotime("+6 days",$weekTimeBegin) : strtotime("+4 days",$weekTimeBegin);
			$vDatas["timeBegin"]=strtotime(date("Y-m-d",$weekTimeBegin)." 00:00");
			$vDatas["timeEnd"]	=strtotime(date("Y-m-d",$weekTimeEnd)." 23:59");
			$vDatas["timePrev"]=strtotime("-1 week",$curTime);
			$vDatas["timeNext"]=strtotime("+1 week",$curTime);

		}
		//AFFICHAGE 3 PROCHAINS JOURS
		elseif($displayMode=="3Days"){
			$vDatas["timeBegin"]=strtotime(date("Y-m-d",$curTime)." 00:00");
			$vDatas["timeEnd"]	=$vDatas["timeBegin"]+259199;//259199 = 3 jours - 1sec
			$vDatas["timePrev"]=strtotime("-3 day",$curTime);
			$vDatas["timeNext"]=strtotime("+3 day",$curTime);
		}
		//AFFICHAGE JOUR
		elseif($displayMode=="day"){
			$vDatas["timeBegin"]=strtotime(date("Y-m-d",$curTime)." 00:00");
			$vDatas["timeEnd"]	=strtotime(date("Y-m-d",$curTime)." 23:59");
			$vDatas["timePrev"]=strtotime("-1 day",$curTime);
			$vDatas["timeNext"]=strtotime("+1 day",$curTime);
			
		}
		////	LIBELLES ET MENU DE LA PERIODE DE L'AGENDA
		//Libellés "month"
		if($displayMode=="month")
		{
			//Exple "mars 2016"
			$vDatas["labelPeriod"]=ucfirst(Txt::formatime("%B %Y",$curTime));
			//Menu pour changer d'année et de mois
			$vDatas["calMonthPeriodMenu"]=null;
			for($tmpMonth=1; $tmpMonth<=12; $tmpMonth++){
				$tmpMonthTime=strtotime(date("Y",$curTime)."-".($tmpMonth>9?$tmpMonth:"0".$tmpMonth)."-01");
				$vDatas["calMonthPeriodMenu"].="<a onClick=\"redir('?ctrl=calendar&curTime=".$tmpMonthTime."')\" ".(date("Y-m",$curTime)==date("Y-m",$tmpMonthTime)?"class='sLinkSelect'":null).">".Txt::formatime("%B",$tmpMonthTime)."</a>";
			}
			$vDatas["calMonthPeriodMenu"].="<hr>";
			for($tmpYear=date("Y")-3; $tmpYear<=date("Y")+5; $tmpYear++){
				$tmpYearTime=strtotime($tmpYear."-".date("m",$curTime)."-01");
				$vDatas["calMonthPeriodMenu"].="<a onClick=\"redir('?ctrl=calendar&curTime=".$tmpYearTime."')\" ".(date("Y",$curTime)==$tmpYear?"class='sLinkSelect'":null).">".$tmpYear."</a>";
			}
		}
		//Autres libellés
		else
		{
			//exple "semaine 44"
			$titleLabelPeriod=Txt::trad("CALENDAR_displayWeek")." ".date("W",$vDatas["timeBegin"]);
			if($displayMode=="day"){//exple "26 oct. 2015"
				$vDatas["labelPeriod"]="<span title=\"".$titleLabelPeriod."\">".Txt::formatime("%e %b %Y",$curTime)."</span>";
			}else{//exple "20 - 27 nov. 2015"	
				$beginMonthLabel=(date("m",$vDatas["timeBegin"])!=date("m",$vDatas["timeEnd"]))  ?  Txt::formatime("%b",$vDatas["timeBegin"])  :  null;//Si besoin, affiche le mois du début ET le mois de la fin de période
				$vDatas["labelPeriod"]="<span title=\"".$titleLabelPeriod."\">".strftime("%e",$vDatas["timeBegin"])." ".$beginMonthLabel." - ".Txt::formatime("%e %b %Y",$vDatas["timeEnd"])."</span>";
			}
		}
		////	LISTE LES JOURS À AFFICHER
		$vDatas["periodDays"]=[];
		if(empty($vDatas["timeDisplayedBegin"]))	{$vDatas["timeDisplayedBegin"]=$vDatas["timeBegin"];  $vDatas["timeDisplayedEnd"]=$vDatas["timeEnd"];}
		for($timeDay=$vDatas["timeDisplayedBegin"]+43200; $timeDay<=$vDatas["timeDisplayedEnd"]; $timeDay+=86400)//43200sec de décalage : heures d'été/hivers
		{
			//début et fin du jour (attention aux heures d'été/hivers)
			$tmpDay["date"]=date("Y-m-d",$timeDay);
			$tmpDay["timeBegin"]=strtotime(date("Y-m-d",$timeDay)." 00:00");
			$tmpDay["timeEnd"]=strtotime(date("Y-m-d",$timeDay)." 23:59");
			//Class css de la cellule : avant/après le mois affiché OU jour du passé OU défault
			if($displayMode=="month" && date("m",$timeDay)!=date("m",$curTime))	{$tmpDay["dayClass"]="vCalMonthOtherMonth";}
			elseif($tmpDay["timeEnd"]<time())									{$tmpDay["dayClass"]="vCalMonthOldDate";}
			else																{$tmpDay["dayClass"]=null;}
			//Url d'ajout d'evt pour le jour (vue mois) / Libelle de jour ferie / Aujourd'hui?
			$tmpDay["urlEditNew"]=MdlCalendarEvent::getUrlNew()."&newTimeBegin=".($tmpDay["timeBegin"]+32400);//9h
			$tmpDay["celebrationDay"]=(array_key_exists(date("Y-m-d",$timeDay),$vDatas["celebrationDays"]))  ?  $vDatas["celebrationDays"][date("Y-m-d",$timeDay)]  :  null;
			$tmpDay["vCalMonthToday"]=(date("Y-m-d",$timeDay)==date("Y-m-d")) ? "vCalMonthToday" : null;
			//Ajoute les infos du jour
			$vDatas["periodDays"][]=$tmpDay;
		}
		////	VUE "MONTH"/"WEEK" DE CHAQUE AGENDA
		foreach($vDatas["displayedCalendars"] as $cptCal=>$tmpCal)
		{
			//init
			$vDatas2=$vDatas;
			$vDatas2["tmpCal"]=$tmpCal;
			$vDatas2["cptCal"]=$cptCal;
			$vDatas2["txtAddEvt"]=($displayMode=="month") ? Txt::trad("CALENDAR_addEvtDay") : Txt::trad("CALENDAR_addEvtHour");//"ajouter un événement"
			$vDatas2["txtAddEvtPropose"]=($tmpCal->editRight()==false) ? " (".Txt::trad("CALENDAR_propose").")" : null;//"(proposition)"
			//LISTE DES EVENEMENTS DE CHAQUE JOUR
			$vDatas2["eventList"]=[];
			$tmpCal->displayedPeriodEvtList=$tmpCal->evtList($vDatas["timeDisplayedBegin"],$vDatas["timeDisplayedEnd"]);//Evenements de l'agenda, sur la période affichee
			foreach($vDatas["periodDays"] as $dayCpt=>$tmpDay)
			{
				//Ajoute la liste des evts du jour dans l'agenda courant
				$vDatas2["eventList"][$tmpDay["date"]]=[];
				$tmpCalDisplayedDayEvtList=MdlCalendar::evtFilterDay($tmpCal->displayedPeriodEvtList,$tmpDay["timeBegin"],$tmpDay["timeEnd"]);//Sélectionne uniquement les evenements sur la journée
				foreach($tmpCalDisplayedDayEvtList as $tmpEvt)
				{
					//Evt hors catégorie?
					if(Req::isParam("_idCatFilter") && $tmpEvt->_idCat!=Req::getParam("_idCatFilter"))	{continue;}
					//Element pour l'affichage "semaine"/"jour"
					if($displayMode!="month")
					{
						//Duree / Hauteur à afficher pour l'evt
						$tmpEvt->dayCpt=$dayCpt;
						$tmpEvt->timeBegin=strtotime($tmpEvt->dateBegin);
						$tmpEvt->timeEnd=strtotime($tmpEvt->dateEnd);
						$evtBeforeTmpDay=($tmpEvt->timeBegin < $tmpDay["timeBegin"]);//Evt commence avant le jour courant ?
						$evtAfterTmpDay=($tmpEvt->timeEnd > $tmpDay["timeEnd"]);	 //Evt termine après le jour courant?
						if($evtBeforeTmpDay==true && $evtAfterTmpDay==true)	{$tmpEvt->durationMinutes=24*60;}										//Affiche toute la journée
						elseif($evtBeforeTmpDay==true)						{$tmpEvt->durationMinutes=($tmpEvt->timeEnd-$tmpDay["timeBegin"])/60;}	//Affiche l'evt depuis 0h00 du jour courant
						elseif($evtAfterTmpDay==true)						{$tmpEvt->durationMinutes=($tmpDay["timeEnd"]-$tmpEvt->timeBegin)/60;}	//Affiche l'evt jusqu'à 23h59 du jour courant
						else												{$tmpEvt->durationMinutes=($tmpEvt->timeEnd-$tmpEvt->timeBegin)/60;}	//Affichage normal (au cour de la journée)
						//Heure/Minutes de début d'affichage ("evtBeforeDayBegin" si l'evt a commencé avant le jour affiché)
						$tmpEvt->minutesFromDayBegin=($tmpEvt->timeBegin>$tmpDay["timeBegin"])  ?  (($tmpEvt->timeBegin-$tmpDay["timeBegin"])/60)  :  "evtBeforeDayBegin";
					}
					//AJOUTE L'EVT!
					$vDatas2["eventList"][$tmpDay["date"]][]=$tmpEvt;
				}
			}
			$calendarVue=($displayMode=="month")?"VueCalendarMonth.php":"VueCalendarWeek.php";
			$tmpCal->calendarVue=self::getVue(Req::getCurModPath().$calendarVue, $vDatas2);
		}
		////	SYNTHESE DES AGENDAS (SI + D'UN AGENDA)
		if(count($vDatas["displayedCalendars"])>1 && !Tool::isMobile())
		{
			//Jours à afficher pour la synthese
			$vDatas["periodDaysSynthese"]=[];
			foreach($vDatas["periodDays"] as $tmpDay)
			{
				//affichage "month" & jour d'un autre mois : passe le jour
				if($displayMode=="month" && date("m",$tmpDay["timeBegin"])!=date("m",$curTime))	{continue;}
				//Evénements de chaque agenda pour le $tmpDay 
				$nbCalsOccuppied=0;
				$tmpDay["calsEvts"]=[];
				foreach($vDatas["displayedCalendars"] as $tmpCal){
					$tmpDay["calsEvts"][$tmpCal->_id]=MdlCalendar::evtFilterDay($tmpCal->displayedPeriodEvtList,$tmpDay["timeBegin"],$tmpDay["timeEnd"]);
					if(!empty($tmpDay["calsEvts"][$tmpCal->_id]))	{$nbCalsOccuppied++;}
				}
				//Tooltip de synthese si au moins un agenda possède un événement à cette date
				$tmpDay["nbCalsOccuppied"]=(!empty($nbCalsOccuppied))  ?  Txt::displayDate($tmpDay["timeBegin"],"full")." :<br>".Txt::trad("CALENDAR_calendarsPercentBusy")." : ".$nbCalsOccuppied." / ".count($tmpDay["calsEvts"])  :  null;
				//Ajoute le jour
				$vDatas["periodDaysSynthese"][]=$tmpDay;
			}
		}
		////	LANCE L'AFFICHAGE
		static::$isMainPage=true;
		static::displayPage("VueIndex.php",$vDatas);
	}

	/*
	 * Agenda courant est affiché?
	 */
	public static function isDisplayedCal($displayedCalendars, $curCal)
	{
		foreach($displayedCalendars as $tmpCalendar){
			if($tmpCalendar->_id==$curCal->_id)  {return true;}
		}
	}

	/*
	 * PLUGINS
	 */
	public static function plugin($pluginParams)
	{
		$pluginsList=$eventList=[];
		if($pluginParams["type"]=="search" || $pluginParams["type"]=="dashboard")
		{
			//"Mes agendas" si on est sur le dashboard / "Agendas visibles" si c'est la recherche
			$visibleCalendars=($pluginParams["type"]=="dashboard") ? MdlCalendar::myCalendars() : MdlCalendar::visibleCalendars();
			if(!empty($visibleCalendars))
			{
				////	Evenements à confirmer
				if($pluginParams["type"]=="dashboard")
				{
					$menuProposedEvents=self::menuProposedEvents();
					if(!empty($menuProposedEvents)){
						$objMenuConfirm=new stdClass();
						$objMenuConfirm->pluginModule=self::moduleName;
						$objMenuConfirm->pluginBlockMenu=$menuProposedEvents;
						$pluginsList[]=$objMenuConfirm;
					}
				}
				////	Evenements de chaque agenda : événements courants
				if($pluginParams["type"]=="dashboard")
				{
					foreach($visibleCalendars as $tmpCal){
						$tmpCalEvtFullList=$tmpCal->evtList(null,null,1,false);//Tous les Evt avec accessRight>=1, pas triés par H:M
						$tmpCalEvtList=MdlCalendar::evtFilterDays($tmpCalEvtFullList, strtotime($pluginParams["dateTimeBegin"]), strtotime($pluginParams["dateTimeEnd"]));
						foreach($tmpCalEvtList as $tmpObj)  {$tmpObj->pluginIsCurrent=true;  $eventList[]=$tmpObj;}
					}
				}
				////	Evenements de chaque agenda : sélection normale du plugin (date de création OU recherche)
				foreach($visibleCalendars as $tmpCal){
					$eventList=array_merge($eventList, $tmpCal->evtList(null,null,1,false,$pluginParams));//Tous les Evt avec accessRight>=1, pas triés par H:M et filtrés avec $pluginParams
				}
				$eventList=array_unique($eventList,SORT_REGULAR);
				////	Ajoute les plugins
				foreach($eventList as $tmpObj)
				{
					if($tmpObj->readRight())
					{
						//Agendas ou l'evenement est affecté.. et visibles par l'user courant
						$calendarsUrl=null;
						foreach($tmpObj->affectedCalendars(true) as $tmpCal){
							if(in_array($tmpCal,$visibleCalendars))  {$calendarsUrl.="&displayedCalendars[]=".$tmpCal->_id;}//(ex "date_affiche"/"affichage_demande")
						}
						//infos du plugin
						$tmpObj->pluginModule=self::moduleName;
						$tmpObj->pluginIcon=(isset($tmpObj->pluginIsCurrent) && $pluginParams["type"]=="dashboard") ? "newObj2.png" : "calendar/icon.png";
						$tmpObj->pluginLabel=Txt::displayDate($tmpObj->dateBegin,"normal",$tmpObj->dateEnd)." :<br>".$tmpObj->title;
						$tmpObj->pluginTitle=Txt::displayDate($tmpObj->dateBegin,"full",$tmpObj->dateEnd)."<hr>".$tmpObj->affectedCalendarsLabel();
						$tmpObj->pluginJsIcon="redir('?ctrl=calendar&displayType=month&datetime=".strtotime($tmpObj->dateBegin).$calendarsUrl."',true);";//"datetime" & "displayType" (month/week/day)
						$tmpObj->pluginJsLabel="lightboxOpen('".$tmpObj->getUrl("vue")."');";
						$pluginsList[]=$tmpObj;
					}
				}
			}
		}
		return $pluginsList;
	}

	/*
	 * ACTION : Evenements que l'user courant a créé
	 */
	public static function actionMyEvents()
	{
		$vDatas["myEvents"]=Db::getObjTab("calendarEvent","SELECT * FROM ap_calendarEvent WHERE _idUser=".Ctrl::$curUser->_id." ORDER BY dateBegin");
		static::displayPage("VueMyEvents.php",$vDatas);
	}

	/*
	 * ACTION : Edition d'un agenda
	 */
	public static function actionCalendarEdit()
	{
		//Init
		$curObj=Ctrl::getTargetObj();
		$curObj->controlEdit();
		if(MdlCalendar::addRight()==false)   {self::noAccessExit();}
		////	Formulaire validé
		if(Req::isParam("formValidate")){
			//Enregistre & recharge l'objet
			$timeSlot=Req::getParam("timeSlotBegin")."-".Req::getParam("timeSlotEnd");
			$typeCalendar=$curObj->isNew() ? ", type='ressource'" : null;
			$curObj=$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description").", timeSlot=".Db::format($timeSlot).$typeCalendar);
			static::lightboxClose();
		}
		////	Affiche la vue
		$vDatas["curObj"]=$curObj;
		static::displayPage("VueCalendarEdit.php",$vDatas);
	}

	/*
	 * ACTION : Edition d'un evenement d'agenda
	 */
	public static function actionCalendarEventEdit()
	{
		//Init
		$curObj=Ctrl::getTargetObj();
		$curObj->controlEdit();
		////	Formulaire validé
		if(Req::isParam("formValidate"))
		{
			//Modifie les détails uniquement si on a les droits complets
			if($curObj->fullRight())
			{
				//Prépare les dates
				$dateBegin=Txt::formatDate(Req::getParam("dateBegin")." ".Req::getParam("timeBegin"), "inputDatetime", "dbDatetime");
				$dateEnd=Txt::formatDate(Req::getParam("dateEnd")." ".Req::getParam("timeEnd"), "inputDatetime", "dbDatetime");
				///périodicité
				$periodDateEnd=$periodValues=$periodDateExceptions=null;
				if(Req::isParam("periodType")){
					$periodDateEnd=Txt::formatDate(Req::getParam("periodDateEnd"), "inputDate", "dbDate");
					$periodValues=Txt::tab2txt(Req::getParam("periodValues_".Req::getParam("periodType")));
					if(Req::isParam("periodDateExceptions")){
						$periodDateExceptions=[];
						foreach(Req::getParam("periodDateExceptions") as $tmpDate)  {$periodDateExceptions[]=Txt::formatDate($tmpDate,"inputDate","dbDate");}
					}
				}
				//Enregistre & recharge l'objet
				$curObj=$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description","editor").", dateBegin=".Db::format($dateBegin).", dateEnd=".Db::format($dateEnd).", _idCat=".Db::formatParam("_idCat").", important=".Db::formatParam("important").", contentVisible=".Db::formatParam("contentVisible").", periodType=".Db::formatParam("periodType").", periodValues=".Db::format($periodValues).", periodDateEnd=".Db::format($periodDateEnd).", periodDateExceptions=".Db::formatTab2txt($periodDateExceptions));
			}
			//Si besoin, réinitialise les affectations aux agendas : uniquement ceux sur lesquels on peut éditer les événements
			if($curObj->isNew()==false){
				foreach(Req::getParam("calAffectReinit") as $_idCal)  {$curObj->deleteAffectation($_idCal);}
			}
			//Attribue les affectations aux agendas et propositions (uniquement ceux sur lesquels on peut éditer les événements)
			$allAffectations=$specificAffectUserIds=[];
			if(Req::isParam("affectationCalendars")){$allAffectations=Req::getParam("affectationCalendars");}
			if(Req::isParam("proposedCalendars"))	{$allAffectations=array_merge($allAffectations,Req::getParam("proposedCalendars"));}
			foreach($allAffectations as $idCal){
				$tmpCal=Ctrl::getObj("calendar",$idCal);
				if(in_array($tmpCal,MdlCalendar::affectationCalendars())){
					$confirmed=(Req::isParam("affectationCalendars") && in_array($idCal,Req::getParam("affectationCalendars")))  ?  1  :  0;
					Db::query("INSERT INTO ap_calendarEventAffectation SET _idEvt=".$curObj->_id.", _idCal=".$tmpCal->_id.", confirmed=".Db::format($confirmed));
					if($tmpCal->type=="user")	{$specificAffectUserIds[]=$tmpCal->_idUser;}
				}
			}
			// Invité : affiche un message "votre demande sera prise en compte prochainement"
			if(Ctrl::$curUser->isUser()==false)  {Ctrl::addNotif(Txt::trad("EDIT_demandToConfirm"));}
			//Notifie par mail & Ferme la page
			$tmpFilePath=self::getIcalEvents([$curObj]);
			$attachedFiles=[["path"=>$tmpFilePath, "name"=>Txt::clean($curObj->title,"maxi")."_EXPORT.ics"]];
			$curObj->sendMailNotif("<b>".$curObj->title."</b> : ".Txt::displayDate($curObj->dateBegin,"full",$curObj->dateEnd)."<br>".$curObj->description, $attachedFiles, $specificAffectUserIds);
			if(is_file($tmpFilePath))	{unlink($tmpFilePath);}
			static::lightboxClose();
		}
		////	Affiche la vue
		$vDatas["tabPeriodValues"]=Txt::txt2tab($curObj->periodValues);
		foreach(Txt::txt2tab($curObj->periodDateExceptions) as $keyTmp=>$tmpException)	{$vDatas["periodDateExceptions"][$keyTmp+1]=Txt::formatDate($tmpException,"dbDate","inputDate");}
		// Agendas d'affectations
		$vDatas["affectationCalendars"]=MdlCalendar::affectationCalendars();
		foreach($vDatas["affectationCalendars"] as $tmpCal)
		{
			//Check affectation & proposition?
			$preselectCalendar=($curObj->isNew() && $tmpCal->_id==Req::getParam("_idCal")) ? true : false;
			$tmpCal->checkAffectation=(in_array($tmpCal,$curObj->affectedCalendars(true))  || ($preselectCalendar==true && $tmpCal->editContentRight())) ? "checked" : null;	   //check si déjà affectés OU agenda présélectionné + contenu de l'agenda éditable
			$tmpCal->checkProposed	 =(in_array($tmpCal,$curObj->affectedCalendars(false)) || ($preselectCalendar==true && $tmpCal->editContentRight()==false)) ? "checked" : null;//check si déjà proposés OU agenda présélectionné + contenu de l'agenda pas éditable
			//Désactive affectation & proposition?
			$tmpCal->disableAffect =($tmpCal->editContentRight() || ($curObj->fullRight() && !empty($tmpCal->checkAffectation))) ? null : "disabled";	//actif si contenu de l'agenda éditable OU auteur de l'evt + agenda dejà affecté (proposition accepte)
			$tmpCal->disablePropose=($tmpCal->editContentRight() || $curObj->fullRight()) ? null : "disabled";											//actif si contenu de l'agenda éditable OU auteur de l'evt
			$tmpCal->calAffectReinit=(empty($tmpCal->disableAffect) || empty($tmpCal->disablePropose)) ? true : false;//Modif d'evt : Réinit affection si proposition ou affectation possible
			//Tooltip du label
			if(empty($tmpCal->disableAffect))		{$tmpCal->tooltip.=Txt::trad("CALENDAR_inputAffect");}	//"Ajouter l'événement [..]"
			elseif(empty($tmpCal->disablePropose))	{$tmpCal->tooltip.=Txt::trad("CALENDAR_proposeInfo");}	//"Proposer l'événement uniquement [..]"
			else									{$tmpCal->tooltip.=Txt::trad("CALENDAR_noModifInfo");}	//"Modification non autorisé [..]"
			if(!empty($tmpCal->description))	{$tmpCal->tooltip.="<br><i>".$tmpCal->description."<i>";}
		}
		//Dates d'un nouvel event		
		if($curObj->isNew()){
			if(Req::isParam("newTimeEnd"))			{$curObj->dateBegin=date("Y-m-d H:i:00",Req::getParam("newTimeBegin"));  $curObj->dateEnd=date("Y-m-d H:i:00",Req::getParam("newTimeEnd"));}
			elseif(Req::isParam("newTimeBegin"))	{$curObj->dateBegin=$curObj->dateEnd=date("Y-m-d H:i:00",Req::getParam("newTimeBegin"));}
			else									{$curObj->dateBegin=$curObj->dateEnd=date("Y-m-d H:00:00");}
		}
		$vDatas["curObj"]=$curObj;
		$vDatas["userGroups"]=MdlUserGroup::getGroups(Ctrl::$curSpace);
		static::displayPage("VueCalendarEventEdit.php",$vDatas);
	}

	/*
	 * AJAX : Control des créneaux horaires des agendas sélectionnés
	 */
	public static function actionTimeSlotBusy()
	{
		if(Req::isParam(["dateTimeBegin","dateTimeEnd","_evtId","targetObjects"]))
		{
			//Init
			$textTimeSlotBusy=null;
			$timeBegin=Txt::formatDate(Req::getParam("dateTimeBegin"),"inputDatetime","time")+1;//Décale d'une sec. pour eviter les faux positifs. Exple: créneaux 11h-12h dispo, même si 12h-13h est occupé
			$timeEnd=Txt::formatDate(Req::getParam("dateTimeEnd"),"inputDatetime","time")-1;//idem. Exple: créneaux 11h-12h dispo, même si 12h-13h est occupé
			//Vérifie le créneau horaire sur chaque agenda sélectionné
			foreach(self::getTargetObjects() as $tmpCal)
			{
				$calendarBusy=$calendarBusyTimeSlots=null;
				//Evts de l'agenda sur la période sélectionné ($accessRightMini=0.5)
				foreach(MdlCalendar::evtFilterDay($tmpCal->evtList($timeBegin,$timeEnd),$timeBegin,$timeEnd) as $tmpEvt){
					if($tmpEvt->_id!=Req::getParam("_evtId")){//Sauf l'evt en cours d'édition..
						$calendarBusyTimeSlots.=" &nbsp; &nbsp; <img src='app/img/arrowRight.png'> ".Txt::displayDate($tmpEvt->dateBegin,"normal",$tmpEvt->dateEnd)." ";
						$calendarBusy=true;
					}
				}
				//L'agenda est occupé?
				if($calendarBusy==true)  {$textTimeSlotBusy.="<div class='vTimeSlotBusyRow'><div class='vTimeSlotBusyCell'>".$tmpCal->title."</div><div class='vTimeSlotBusyCell'>".$calendarBusyTimeSlots."</div></div>";}
			}
			//Retourne le message
			echo $textTimeSlotBusy;
		}
	}

	/*
	 * MENU : Liste des evenements à confirmer
	 */
	public static function menuProposedEvents()
	{
		//Récupère les evenements proposés sur chaque "myCalendars()"
		$menuProposedEvents=null;
		foreach(MdlCalendar::myCalendars() as $tmpCal)
		{
			//S'il y a des propositions evenement : affiche le menu
			$eventsToConfirm=Db::getObjTab("calendarEvent","SELECT T1.* FROM ap_calendarEvent T1, ap_calendarEventAffectation T2 WHERE T1._id=T2._idEvt AND T2._idCal=".$tmpCal->_id." AND (T2.confirmed=0 or T2.confirmed is null)");
			if(count($eventsToConfirm)>0)
			{
				//Supprime les proposition d'evenements passés?
				foreach($eventsToConfirm as $tmpKey=>$tmpEvt){
					if($tmpEvt->isOldEvt(time()-86400))   {$tmpEvt->deleteAffectation($tmpCal->_id);  unset($eventsToConfirm[$tmpKey]);}
				}
				//S'il y a toujours des propositions
				if(count($eventsToConfirm)>0)
				{
					// Libelle de l'agenda
					$libConfirmEvent=($tmpCal->isMyPerso())  ?  Txt::trad("CALENDAR_evtProposedForMe")  :  Txt::trad("CALENDAR_evtProposedFor")." <i>".$tmpCal->title."</i>";
					$menuProposedEvents.="<div class='confirmEventLib'>".$libConfirmEvent." <img src='app/img/important.png'></div>";
					// Evénements à confirmer sur l'agenda
					foreach($eventsToConfirm as $tmpEvt){
						$actionJsAndId="onclick=\"confirmEventProposition(".$tmpCal->_id.",".$tmpEvt->_id.",this.id);\"  id=\"confirmEventProposition".$tmpEvt->_id."-".$tmpCal->_id."\"";
						$tooltip=htmlspecialchars($tmpEvt->title).(!empty($tmpEvt->description) ? "<hr>".Txt::reduce(strip_tags($tmpEvt->description),100) : null);
						$tooltip="title=\"".Txt::displayDate($tmpEvt->dateBegin,"full",$tmpEvt->dateEnd)."<div>".$tooltip."</div><hr>".Txt::trad("OBJECTcalendar")." : ".$tmpCal->title."<hr>".Txt::trad("CALENDAR_evtProposedBy")." ".$tmpEvt->displayAutor()."\"";
						$menuProposedEvents.="<div ".$actionJsAndId." ".$tooltip." class='confirmEventProposition sLink'><img src='app/img/arrowRight.png'> ".$tmpEvt->title."</div>";
					}
				}
			}
		}
		return $menuProposedEvents;
	}

	/*
	 * ACTION : Validation d'événement dans un Agenda
	 */
	public static function actionConfirmEventProposition()
	{
		$curCal=Ctrl::getTargetObj();
		if($curCal->confirmEventPropositionRight())
		{
			$curEvt=Ctrl::getObj("calendarEvent",Req::getParam("_idEvt"));
			if(Req::getParam("confirmed")==1)	{Db::query("UPDATE ap_calendarEventAffectation SET confirmed=1 WHERE _idEvt=".(int)$curEvt->_id." AND _idCal=".$curCal->_id);}
			else								{$curEvt->deleteAffectation($curCal->_id);}
			echo "true";
		}
	}

	/*
	 * ACTION : Détails d'un événement
	 */
	public static function actionCalendarEventVue()
	{
		$curObj=Ctrl::getTargetObj();
		$curObj->controlRead();
		// visibilite / Catégorie
		$vDatas["contentVisible"]=(preg_match("/(public_cache|prive)/i",$curObj->contentVisible))  ?  ($curObj->contentVisible=="public_cache"?Txt::trad("CALENDAR_visibilityPublicHide"):Txt::trad("CALENDAR_visibilityPrivate"))  :  null;
		$vDatas["labelCategory"]=(!empty($curObj->objCategory))  ?  $curObj->objCategory->display()  :  null;
		//Périodicité
		$vDatas["labelPeriod"]=$periodValues=null;
		if(!empty($curObj->periodType))
		{
			//Périodicité
			$vDatas["labelPeriod"]=Txt::trad("CALENDAR_period_".$curObj->periodType);
			foreach(Txt::txt2tab($curObj->periodValues) as $tmpVal){
				if($curObj->periodType=="weekDay")		{$periodValues.=Txt::trad("day_".$tmpVal).", ";}
				elseif($curObj->periodType=="monthDay")	{$periodValues.=$tmpVal.", ";}
				elseif($curObj->periodType=="month")	{$periodValues.=Txt::trad("month_".$tmpVal).", ";}
			}
			if(!empty($periodValues))	{$vDatas["labelPeriod"].=" : ".trim($periodValues, ", ");}
			//Périodicité : fin
			if(!empty($curObj->periodDateEnd))	{$vDatas["labelPeriod"].=". &nbsp; ".Txt::trad("CALENDAR_periodDateEnd")." : ".Txt::displayDate($curObj->periodDateEnd,"full");}
			//Périodicité : exceptions
			if(!empty($curObj->periodDateExceptions)){
				$vDatas["labelPeriod"].="<br>".Txt::trad("CALENDAR_periodException")." : ";
				$periodDateExceptions=array_filter(Txt::txt2tab($curObj->periodDateExceptions));//"array_filter" pour enlever les valeurs vides
				foreach($periodDateExceptions as $tmpVal)	{$vDatas["labelPeriod"].=Txt::displayDate($tmpVal,"dateMini").", ";}
				$vDatas["labelPeriod"]=trim($vDatas["labelPeriod"], ", ");
			}
		}
		//Détails de l'événement
		$vDatas["curObj"]=$curObj;
		static::displayPage("VueCalendarEvent.php",$vDatas);
	}

	/*
	 * ACTION : Edition des categories d'evenements
	 */
	public static function actionCalendarEventCategoryEdit()
	{
		////	Droit d'ajouter une categorie?
		if(MdlCalendarEventCategory::addRight()==false)  {static::lightboxClose(false);}
		////	Validation de formulaire
		if(Req::isParam("formValidate")){
			$curObj=Ctrl::getTargetObj();
			$curObj->controlEdit();
			//Modif d'une categorie
			$_idSpaces=(!in_array("all",Req::getParam("spaceList")))  ?  Txt::tab2txt(Req::getParam("spaceList"))  :  null;
			$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description").", color=".Db::formatParam("color").", _idSpaces=".Db::format($_idSpaces));
			//Ferme la page
			static::lightboxClose();
		}
		////	Liste des categories
		$vDatas["categoriesList"]=MdlCalendarEventCategory::getCategories(true);
		$vDatas["categoriesList"][]=new MdlCalendarEventCategory();//nouvelle categorie vide
		foreach($vDatas["categoriesList"] as $tmpKey=>$tmpCategory){
			if($tmpCategory->editRight()==false)	{unset($vDatas["categoriesList"][$tmpKey]);}
			else{
				$tmpCategory->tmpId=$tmpCategory->_targetObjId;
				$tmpCategory->createdBy=($tmpCategory->isNew()==false)  ?  Txt::trad("creation")." : ".Ctrl::getObj("user",$tmpCategory->_idUser)->display()  :  null;
			}
		}
		////	Affiche le form
		static::displayPage("VueCalendarEventCategoryEdit.php",$vDatas);
	}

	/*
	 * Création du fichier .ICAL
	 */
	public static function getIcalEvents($eventList)
	{
		//INIT
		$ical ="BEGIN:VCALENDAR\n";
		$ical.="PRODID:-//Agora-Project//".self::$agora->name."//EN\n";
		$ical.="VERSION:".VERSION_AGORA."\n";
		$ical.="CALSCALE:GREGORIAN\n";
		$ical.="METHOD:PUBLISH\n";
		//TIMEZONE
		$ical.="BEGIN:VTIMEZONE\n";
		$ical.="TZID:".self::$curTimezone."\n";
		$ical.="X-LIC-LOCATION:".self::$curTimezone."\n";
		//Daylight
		$ical.="BEGIN:DAYLIGHT\n";
		$ical.="TZOFFSETFROM:".self::icalHour()."\n";
		$ical.="TZOFFSETTO:".self::icalHour(1)."\n";
		$ical.="TZNAME:CEST\n";
		$ical.="DTSTART:19700329T020000\n";
		$ical.="RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=-1SU;BYMONTH=3\n";
		$ical.="END:DAYLIGHT\n";
		//Standard
		$ical.="BEGIN:STANDARD\n";
		$ical.="TZOFFSETFROM:".self::icalHour(1)."\n";
		$ical.="TZOFFSETTO:".self::icalHour()."\n";
		$ical.="TZNAME:CET\n";
		$ical.="DTSTART:19701025T030000\n";
		$ical.="RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=-1SU;BYMONTH=10\n";
		$ical.="END:STANDARD\n";
		$ical.="END:VTIMEZONE\n";
		//AJOUT DE CHAQUE EVENEMENT
		foreach($eventList as $tmpEvt)
		{
			//Infos de base
			$ical.="BEGIN:VEVENT\n";
			$ical.="CREATED:".self::icalDate($tmpEvt->dateCrea)."\n";
			$ical.="LAST-MODIFIED:".self::icalDate($tmpEvt->dateModif)."\n";
			$ical.="DTSTAMP:".self::icalDate(date("Y-m-d H:i"))."\n";
			$ical.="UID:".self::icalIdEvt($tmpEvt)."\n";
			$ical.="SUMMARY:".$tmpEvt->title."\n";
			$ical.="DTSTART;TZID=".self::icalDate($tmpEvt->dateBegin,true)."\n";//exple : "20050714T170000Z" pour 14 juillet 2005 à 17h00
			$ical.="DTEND;TZID=".self::icalDate($tmpEvt->dateEnd,true)."\n";
			// Périodicité : année / jours de la semaine / mois (non compatible .ics) / jours du mois (non compatible .ics)
			$periodDateEnd=($tmpEvt->periodDateEnd) ? ";UNTIL=".self::icalDate($tmpEvt->periodDateEnd) : null;
			if($tmpEvt->periodType=="year"){
				$ical.="RRULE:FREQ=YEARLY;INTERVAL=1".$periodDateEnd."\n";
			}elseif($tmpEvt->periodType=="weekDay"){
				$tmpEvt->periodValues=str_replace([1,2,3,4,5,6,7], ['MO','TU','WE','TH','FR','SA','SU'], $tmpEvt->periodValues);
				$ical.="RRULE:FREQ=WEEKLY;INTERVAL=1;BYDAY=".implode(",",Txt::txt2tab($tmpEvt->periodValues)).$periodDateEnd."\n";
			}elseif($tmpEvt->periodType=="monthDay"){
				$tmpEvt->description.=Txt::trad("CALENDAR_period_monthDay")." : ";
				$tmpEvt->description.=Txt::trad("the")." ".implode(",",Txt::txt2tab($tmpEvt->periodValues))." ".Txt::trad("CALENDAR_period_dayOfMonth");
				$ical.="RRULE:FREQ=MONTHLY;INTERVAL=1".$periodDateEnd."\n";
			}elseif($tmpEvt->periodType=="month"){
				$tmpEvt->description.=Txt::trad("CALENDAR_period_month")." : ";
				foreach(Txt::txt2tab($tmpEvt->periodValues) as $tmpMonth)	{$tmpEvt->description.=Txt::trad("month_".$tmpMonth).", ";}
				$ical.="RRULE:FREQ=MONTHLY;INTERVAL=1".$periodDateEnd."\n";
			}
			//Description (& agendas où il est affecté) et Categorie
			if(count($tmpEvt->affectedCalendars())>0)	{$tmpEvt->description.=(!empty($tmpEvt->description)?" - ":null).Txt::reduce(str_replace("<br>"," ",$tmpEvt->affectedCalendarsLabel()));}
			$tmpEvt->description=str_replace(["\r","\n"], null, html_entity_decode(strip_tags($tmpEvt->description)));
			if(!empty($tmpEvt->description))	{$ical.="DESCRIPTION:".$tmpEvt->description."\n";}
			if(!empty($tmpEvt->_idCat))			{$ical.="CATEGORIES:".Ctrl::getObj("calendarEventCategory",$tmpEvt->_idCat)->title."\n";}
			$ical.="END:VEVENT\n";
		}
		//Fin du ical
		$ical.="END:VCALENDAR\n";
		//Enregistre dans un fichier temporaire
		$tmpFilePath=tempnam(sys_get_temp_dir(),"exportCalendar".uniqid());
		$fp=fopen($tmpFilePath, "w");
		fwrite($fp,$ical);
		fclose($fp);
		//renvoie le chemin du fichier tmp
		return $tmpFilePath;
	}

	/*
	 * Export .ical : formatage de heure/date et Identifiant unique
	 */
	public static function icalHour($timeLag=0)
	{
		// Exemple avec "-5:30"
		$hourTimezone=Tool::$tabTimezones[self::$curTimezone];
		$valueSign=(substr($hourTimezone,0,1)=="-") ? '-' : '+';				//"-"
		$hourAbsoluteVal=str_replace(['-','+'],null,substr($hourTimezone,0,-3));//"5"
		$hourAbsoluteVal+=$timeLag;												//Si $timeLag=2 -> "7"
		if($hourAbsoluteVal<10)	{$hourAbsoluteVal="0".$hourAbsoluteVal;}		//"05"
		$minutes=substr($hourTimezone,-2);										//"30"
		return $valueSign.$hourAbsoluteVal.$minutes;//Retourne "-0530"
	}
	public static function icalDate($dateTime, $timezone=false)
	{
		$dateTime=date("Ymd",strtotime($dateTime))."T".date("Hi",strtotime($dateTime))."00";//exple: "20151231T235900Z"
		return ($timezone==true) ? self::$curTimezone.":".$dateTime : str_replace("T000000Z","T235900Z",$dateTime."Z");
	}
	public static function icalIdEvt($tmpEvt)
	{
		return md5($tmpEvt->dateCrea.$tmpEvt->_id);
	}

	/*
	 * Export des événements d'un agenda
	 */
	public static function actionExportEvents()
	{
		$curCalendar=Ctrl::getTargetObj();
		//Droit en édition?
		if($curCalendar->editRight())
		{
			//Liste des evts
			$eventList=[];
			$periodBegin=time()-(86400*30);//Time - 30jours
			$periodEnd=time()+(86400*365*5);//Time + 5ans
			$curCalEvtPeriodList=$curCalendar->evtList($periodBegin,$periodEnd);//Evenements de l'agenda, sur la période sélectionnée
			foreach(MdlCalendar::evtFilterDays($curCalEvtPeriodList,$periodBegin,$periodEnd) as $tmpEvt)	{$eventList[]=$tmpEvt;}
			//Récup le fichier Ical (même si aucun agendas à afficher..)
			$tmpFilePath=self::getIcalEvents($eventList);
			if(is_file($tmpFilePath))
			{
				$fileName=Txt::clean($curCalendar->title,"maxi")."_EXPORT_".date("d-m-Y").".ics";
				//Téléchargement du fichier / Envoi le fichier par mail
				if(Req::isParam("sendMail")==false)  {File::download($fileName,$tmpFilePath,null,false);}
				else{
					$subject=$mainMessage=ucfirst(Txt::trad("OBJECTcalendar"))." ''".$curCalendar->title."'' : ".Txt::trad("CALENDAR_exportEvtMailList");
					$mainMessage.="<br>".Txt::trad("CALENDAR_exportEvtMailInfo");
					$attachedFiles=[["path"=>$tmpFilePath, "name"=>$fileName]];
					Tool::sendMail(Ctrl::$curUser->mail, $subject, $mainMessage, null, $attachedFiles);
				}
				//Supprime le fichier
				unlink($tmpFilePath);
			}
		}
		//Redirige en page principale
		Ctrl::redir("?ctrl=".Req::$curCtrl);//ne pas mettre de "action"
	}

	/*
	 * Import d'événement (format .ical) dans un agenda
	 */
	public static function actionImportEvents()
	{
		//Charge et controle
		$curCalendar=Ctrl::getTargetObj();
		$curCalendar->controlEdit();
		////	Validation de formulaire : sélection du fichier / des evt à importer
		if(Req::isParam("formValidate"))
		{
			//Prépare le tableau d'import
			if(isset($_FILES["importFile"]) && is_file($_FILES["importFile"]["tmp_name"]))
			{
				//Récupère les événements
				require("class.iCalReader.php");
				$ical=new ical($_FILES["importFile"]["tmp_name"]);
				$vDatas["eventList"]=$ical->events();
				//Formate les imports
				foreach($vDatas["eventList"] as $cptEvt=>$tmpEvt)
				{
					//Init
					$tmpEvt["dbDateBegin"]=substr($tmpEvt["DTSTART"],0,4)."-".substr($tmpEvt["DTSTART"],4,2)."-".substr($tmpEvt["DTSTART"],6,2)." ".substr($tmpEvt["DTSTART"],9,2).":".substr($tmpEvt["DTSTART"],11,2);
					$tmpEvt["dbDateEnd"]=substr($tmpEvt["DTEND"],0,4)."-".substr($tmpEvt["DTEND"],4,2)."-".substr($tmpEvt["DTEND"],6,2)." ".substr($tmpEvt["DTEND"],9,2).":".substr($tmpEvt["DTEND"],11,2);
					$tmpEvt["DESCRIPTION"]=strip_tags(nl2br($tmpEvt["DESCRIPTION"]));
					//Etat de l'événement : importer ? dejà present (ne pas importer) ?
					$isPresent=Db::getVal("SELECT count(*) FROM ap_calendarEvent T1, ap_calendarEventAffectation T2 WHERE T1._id=T2._idEvt AND T2._idCal=".$curCalendar->_id." AND T1.title=".Db::format($tmpEvt["SUMMARY"],"editor")." AND T1.dateBegin=".Db::format($tmpEvt["dbDateBegin"])." AND T1.dateEnd=".Db::format($tmpEvt["dbDateEnd"]));
					$tmpEvt["isPresent"]=($isPresent>0) ? true : false;
					//Enregistre
					$vDatas["eventList"][$cptEvt]=$tmpEvt;
				}
			}
			//Importe les événements
			elseif(Req::isParam("eventList"))
			{
				//Import de chaque événement
				foreach(Req::getParam("eventList") as $tmpEvt)
				{
					//Import sélectionné?
					if(!empty($tmpEvt["checked"])){
						//Créé et enregistre l'événement
						$curObj=new MdlCalendarEvent();
						$curObj=$curObj->createUpdate("title=".Db::format($tmpEvt["title"]).", description=".Db::format($tmpEvt["description"]).", dateBegin=".Db::format($tmpEvt["dateBegin"]).", dateEnd=".Db::format($tmpEvt["dateEnd"]));
						//Affecte à l'agenda courant
						Db::query("INSERT INTO ap_calendarEventAffectation SET _idEvt=".$curObj->_id.", _idCal=".$curCalendar->_id.", confirmed=1");
					}
				}
				//Ferme la page
				static::lightboxClose();
			}
		}
		////	Affiche le menu d'Import/Export
		$vDatas["curCalendar"]=$curCalendar;
		static::displayPage("VueCalendarImportEvt.php",$vDatas);
	}
}