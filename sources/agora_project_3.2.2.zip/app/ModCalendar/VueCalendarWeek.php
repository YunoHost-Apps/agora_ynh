<?php if($cptCal==0){ ?>
<script>
////	Gère l'affichage de la vue "week" (cf. "calendarInitVue()")
function calendarDimensions(printCalendar)
{
	////	Largeur / Hauteur des block scroller des agendas
	$(".vCalWeekScroller").css("display","none");//masque pour avoir les dimensions non déformées du conteneur
	weekScrollerHeight=Math.round($(".vCalWeekMain").innerHeight() - $(".vCalWeekHeader").outerHeight(true));
	$(".vCalWeekScroller").css("height",weekScrollerHeight).css("width",$(".vCalWeekMain").width()).css("display","block");//height PUIS width (à cause de l'ascenseur pour le calcul), puis on raffiche

	////	Init la sélection  &&  "mouseup" sur la page : réinit la sélection
	isMouseDown=selectedDate=timeSelectBegin=timeSelectEnd=null;
	$(document).mouseup(function(){
		isMouseDown=selectedDate=timeSelectBegin=timeSelectEnd=null;
		$(".vCalWeekHourHalfCell").removeClass("vCalWeekHourHalfSelect");
	});

	////	Lance l'affichage de chaque agenda
	$(".vCalWeekScroller").each(function(){
		////	Hauteur des lignes d'heure (créneau horaire de l'agenda doit prendre la hauteur du "weekScrollerHeight")
		var calWeekTimeSlotHours=parseInt($(this).attr("data-timeSlotDuration")) +1;//+1 : nb de lignes du "TimeSlot"
		if(calWeekTimeSlotHours<=2)  {calWeekTimeSlotHours=12;}//timeslot par défaut
		var calWeekLineHeight=Math.round(weekScrollerHeight / calWeekTimeSlotHours)-1;//-1: bordure
		if(calWeekLineHeight<30)		{calWeekLineHeight=30;}//hauteur minimum
		else if(printCalendar===true)	{calWeekLineHeight=35;}//hauteur si on imprime (en rapport direct avec la résolution d'écran!)
		calScrollId="#"+this.id;//Agenda courant
		$(".vCalWeekLine,.vCalWeekHourHalfs",calScrollId).outerHeight(calWeekLineHeight);

		////	Largeur/Hauteur de chaque jour (avec marges)
		var weekCellWidth=Math.round(($(this).innerWidth() - $(".vCalWeekHourLabel").innerWidth()) / $(calScrollId+" .vCalWeekLine:first-child .vCalWeekCell").length);
		$(".vCalWeekHeaderDay, "+calScrollId+" .vCalWeekCell").css("width",weekCellWidth+"px");
		weekCellHeight=$(calScrollId+" .vCalWeekLine:first-child .vCalWeekCell").outerHeight(true);

		////	Affiche chaque événement
		hearlierEvtTop=null;
		$(calScrollId+" .vCalEvtBlock").each(function(){
			//Largeur, Position left et top
			var curDaySelector=calScrollId+" .vCalWeekLine:first-child [data-dayCpt='"+$(this).attr("data-dayCpt")+"']";
			var minutesFromDayBegin=$(this).attr("data-minutesFromDayBegin");
			var evtPosTop=(minutesFromDayBegin!="evtBeforeDayBegin")  ?  Math.round((weekCellHeight/60) * parseInt(minutesFromDayBegin))  :  0;
			$(this).outerWidth($(curDaySelector).width()).css("left",$(curDaySelector).position().left).css("top",evtPosTop);
			//Hauteur de l'evt
			var evtHeightMini=Math.round(weekCellHeight*0.8);//80% d'une hauteur de cellule
			var durationMinutes=parseInt($(this).attr("data-durationMinutes"));
			var evtHeight=Math.round((weekCellHeight/60) * durationMinutes);//30mn mini
			if(evtHeight<evtHeightMini)  {evtHeight=evtHeightMini;}
			$(this).outerHeight(evtHeight-1);//-1px pour mieux délimiter
			//Première position des evts de la semaine (evt le plus tôt de la semaine)
			if(minutesFromDayBegin!="evtBeforeDayBegin" && (hearlierEvtTop===null || evtPosTop<hearlierEvtTop))  {hearlierEvtTop=evtPosTop;}
		});

		////	Place l'agenda (scroll) au début de la plage horaire OU sur l'événement le plus tôt de la semaine
		var scrollTopTimeSlot=weekCellHeight * parseInt($(this).attr("data-timeSlotBegin"));
		var scrollTopCalWeek=(hearlierEvtTop!==null && hearlierEvtTop<scrollTopTimeSlot)  ?  hearlierEvtTop  :  scrollTopTimeSlot;
		$(this).scrollTop(scrollTopCalWeek);

		////	Sélection de créneau horaire pour l'ajout d'un evt
		$(calScrollId+" .vCalWeekHourHalfCell").on("mousedown mousemove mouseup",function(event){
			//Init la sélection / Sélectionne le Timeslot (si on est sur le même jour)
			if(event.type=="mousedown")  {isMouseDown=true;}
			else if(event.type=="mousemove" && isMouseDown==true && (selectedDate==null || selectedDate==$(this).attr("data-selectedDate")))
			{
				//Init "timeSelectBegin" & "timeSelectBegin" & Sélection du jour
				selectedDate=$(this).attr("data-selectedDate");
				var timeCellBegin=parseInt($(this).attr("data-newTimeBegin"));
				var timeCellEnd=timeCellBegin+1800;
				if(timeSelectBegin==null)	{timeSelectBegin=timeCellBegin;}
				timeSelectEnd=timeCellEnd;
				//Ajoute la classe aux cellules sélectionnées (entre "timeSelectBegin" et "timeSelectEnd")
				$(".vCalWeekHourHalfCell[data-selectedDate='"+selectedDate+"']").each(function(){
					var timeCellBegin=parseInt($(this).attr("data-newTimeBegin"));
					(timeSelectBegin<=timeCellBegin && timeCellBegin<timeSelectEnd)  ?  $(this).addClass("vCalWeekHourHalfSelect")  :  $(this).removeClass("vCalWeekHourHalfSelect");
				});
			}
			//Termine la sélection et ouvre le menu d'édition
			else if(event.type=="mouseup"){
				if(timeSelectBegin==null || timeSelectEnd==null)	{timeSelectBegin=timeSelectEnd=parseInt($(this).attr("data-newTimeBegin"));}//Sélection pas encore initialisé (click direct sur une plage horaire)
				lightboxOpen("<?= MdlCalendarEvent::getUrlNew() ?>&_idCal="+$(this).attr("data-idCal")+"&newTimeBegin="+timeSelectBegin+"&newTimeEnd="+timeSelectEnd);//Edition d'evt & réinitialise la sélection
			}
		});
	});

	////	Affiche l'agenda
	$(".vCalWeekMain").css("visibility","visible");
}
</script>

<style>
.vCalWeekMain						{height:100%; visibility:hidden;}
.vCalWeekScroller					{position:relative; overflow-y:scroll; overflow-x:hidden;}
.vCalWeekHeader, .vCalWeekTable, .vCalWeekHourHalfs						{display:table; width:100%;}
.vCalWeekHeaderLine, .vCalWeekLine, .vCalWeekHourHalfLine				{display:table-row;}
.vCalWeekHeaderLine>div, .vCalWeekLine>div, .vCalWeekHourHalfLine>div	{display:table-cell;}
.vCalWeekHeaderLine>div				{text-align:center; vertical-align:bottom; <?= $displayMode=="day"?"visibility:hidden;":null ?>}
.vCalWeekHeaderLine>div:last-child	{width:10px;}/*width du scroller*/
.vCalWeekHourLabel					{width:35px; text-align:right; color:#999; font-weight:normal;}
.vCalWeekCell						{background:#fff; border-top:solid 1px #ddd; border-bottom:solid 1px #fff; border-left:solid 1px #ccc;}
.vCalWeekHourOutTimeslot, .vCalWeekHourHalfOld	{background:#f7f7f7;}
.vCalWeekHourHalfCell				{height:50%;}
.vCalWeekHourHalfCur				{border-top:solid 1px #c00;}
.vCalWeekHourHalfCell:hover, .vCalWeekHourHalfSelect	{background:#eee;}
.vCalEvtBlock						{position:absolute;}
.vCalEvtBlock .menuLaunch			{margin-right:5px;}/*menu contextuel*/

/*RESPONSIVE*/
@media screen and (max-width:1024px){
	.vCalWeekHeaderDay img, .vCalWeekHourLabelZero, .vCalEvtLabel img	{display:none;}
	.vCalWeekHourLabel	{width:10px; font-size:90%;}
}

/* IMPRESSION */
@media print{
	.vCalWeekLine .vCalWeekCell:last-child	{border-right:solid 1px #ddd!important;}
	.vCalWeekLine:last-child .vCalWeekCell	{border-bottom:solid 1px #ddd!important;}
	.vCalWeekScroller			{overflow:visible!important;}
	.vCalWeekHourHalfCell		{display:none!important;}
	.vCalEvtBlock				{border:solid 1px #ddd!important;}
}
</style>
<?php } ?>

<div class="vCalWeekMain">
	<!--HEADER DES JOURS : FIXE-->
	<div class="vCalWeekHeader">
		<div class="vCalWeekHeaderLine">
			<div class="vCalWeekHourLabel">&nbsp;</div>
			<?php
			foreach($periodDays as $tmpDay){
				$dayLabelFormat=Tool::isMobile() ? "%a" : "%A";
				$classCurDay=(date("y-m-d",$tmpDay["timeBegin"])==date("y-m-d"))  ?  "sAccessWrite"  :  null;
				$celebrationDay=(!empty($tmpDay["celebrationDay"]))  ?  " <img src='app/img/calendar/celebrationDay.png' title=\"".$tmpDay["celebrationDay"]."\">"  :  null;
				echo "<div class=\"vCalWeekHeaderDay ".$classCurDay."\">".Txt::formatime($dayLabelFormat,$tmpDay["timeBegin"])." ".date("j",$tmpDay["timeBegin"]).$celebrationDay."</div>";
			}
			?>
			<div>&nbsp;</div>
		</div>
	</div>

	<?php
	////	PARTIE SCROLLABLE DE L'AGENDA : EVENEMENTS & GRILLE DES HEURES/MINUTES
	echo "<div class='vCalWeekScroller' id=\"calWeekScroller".$tmpCal->_targetObjId."\" data-timeSlotBegin=\"".$tmpCal->timeSlotBegin."\" data-timeSlotDuration=\"".round($tmpCal->timeSlotEnd-$tmpCal->timeSlotBegin)."\">";

		////	EVENEMENTS DE L'AGENDA POUR CHAQUE JOUR
		foreach($eventList as $tmpDateEvts)
		{
			foreach($tmpDateEvts as $tmpEvt)
			{
				$evtAttr="data-dayCpt=\"".$tmpEvt->dayCpt."\" data-minutesFromDayBegin=\"".$tmpEvt->minutesFromDayBegin."\" data-durationMinutes=\"".$tmpEvt->durationMinutes."\" data-catColor=\"".$tmpEvt->catColor."\"";
				$tmpEvtTitle=Tool::isMobile()  ?  Txt::reduce($tmpEvt->title,30)  :  Txt::reduce($tmpEvt->title,60);
				if(!empty($tmpEvt->important))	{$tmpEvtTitle.=" <img src='app/img/important.png'>";}
				echo $tmpEvt->divContainer("vCalEvtBlock",$evtAttr).$tmpEvt->contextMenu(["inlineLauncher"=>true,"_idCal"=>$tmpCal->_id,"curDateTime"=>strtotime($tmpEvt->dateBegin)]).
						"<div class='vCalEvtLabel' onclick=\"lightboxOpen('".$tmpEvt->getUrl("vue")."')\">".Txt::displayDate($tmpEvt->dateBegin,"mini",$tmpEvt->dateEnd)." ".$tmpEvtTitle."</div>
					 </div>";
			}
		}

		////	GRILLE DES HEURES/MINUTES
		echo "<div class='vCalWeekTable'>";
			for($H=0; $H<=23; $H++)
			{
				//créneau hors du "Timeslot" de l'agenda?
				$tmpHourClass=($H<$tmpCal->timeSlotBegin || $H>$tmpCal->timeSlotEnd || $H==12 || $H==13)  ?  "vCalWeekHourOutTimeslot"  :  null;
				//LIGNE + LABEL DE L'HEURE COURANTE + HEURE COURANTE POUR CHAQUE JOUR
				echo "<div class='vCalWeekLine'>";
					echo "<div class='vCalWeekHourLabel'>".$H."<span class='vCalWeekHourLabelZero'>:00</span></div>";
					foreach($periodDays as $dayCpt=>$tmpDay)
					{
						echo "<div class='vCalWeekCell' data-dayCpt=\"".$dayCpt."\">";
							echo "<div class='vCalWeekHourHalfs'>";
								//DIVISE LES CELLULES EN 1/2 HEURE POUR LE SELECTION
								foreach([0,1] as $halfHour)
								{
									//Init
									$halfHourBegin=$tmpDay["timeBegin"]+(3600*$H)+(1800*$halfHour);
									$halfHourEnd=$halfHourBegin+1800;	
									if(time()>$halfHourBegin && time()<$halfHourEnd)	{$halfClass="vCalWeekHourHalfCur";}
									elseif($halfHourBegin<time())						{$halfClass="vCalWeekHourHalfOld";}
									else												{$halfClass=$tmpHourClass;}
									$tmpNewDateTitle=$txtAddEvt." ".date("H:i",$halfHourBegin).$txtAddEvtPropose;
									$tmpNewDate=date("Ymd",$halfHourBegin);
									echo "<div class='vCalWeekHourHalfLine'>
											<div class=\"vCalWeekHourHalfCell ".$halfClass."\" title=\"".$tmpNewDateTitle."\" data-idCal=\"".$tmpCal->_id."\" data-newTimeBegin=\"".$halfHourBegin."\" data-selectedDate=\"".$tmpNewDate."\">&nbsp;</div>
										  </div>";
								}
							echo "</div>";
						echo "</div>";
					}
				echo "</div>";
			}
		?>
		</div>
	</div>
</div>