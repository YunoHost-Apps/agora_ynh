<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Modele des evenements
 */
class MdlCalendarEvent extends MdlObject
{
	const moduleName="calendar";
	const objectType="calendarEvent";
	const dbTable="ap_calendarEvent";
	const MdlObjectContainer="MdlCalendar";
	const hasAccessRight=false;
	const hasShortcut=false;
	const htmlEditorField="description";
	public static $requiredFields=array("title","dateBegin","timeBegin","dateEnd","timeEnd");
	public static $searchFields=array("title","description");
	private $_confirmedCalendars=null;
	private $_proposedCalendars=null;

	/*
	 * SURCHARGE : Constructeur
	*/
	function __construct($objIdOrValues=null)
	{
		parent::__construct($objIdOrValues);
		//Visibilité
		if(empty($this->contentVisible))	{$this->contentVisible="public";}
		//Categorie
		if(!empty($this->_idCat))	{$this->objCategory=Ctrl::getObj("calendarEventCategory",$this->_idCat);	$this->catColor=$this->objCategory->color;}
		else						{$this->objCategory=null;													$this->catColor="#444";}
		//Masque le title/description si besoin
		if($this->accessRight()<1){
			$this->title="<i>".Txt::trad("CALENDAR_evtPrivate")."</i>";
			$this->description=null;
		}
	}

	/*
	 * SURCHARGE : Droit d'accès à un événement
	 * Ajoute le accessRight "0.5" qui permet juste de voir la plage horaire de l'evenement
	 */
	public function accessRight()
	{
		if($this->_accessRight===null)
		{
			//Droit par défaut
			$this->_accessRight=parent::accessRight();
			if($this->_accessRight<3)
			{
				//Droit en fonction des agendas auquels l'événement est affecté : supérieur?
				$tmpAccessRight=$tmpMaxRight=0;
				$allCalendarsFullAccess=true;
				foreach($this->affectedCalendars(true) as $objCalendar){
					if($objCalendar->accessRight()>$tmpMaxRight)	{$tmpMaxRight=$objCalendar->accessRight();}//Droit de l'agenda > droit max temporaire
					if($objCalendar->editFullContentRight()==false)	{$allCalendarsFullAccess=false;}//L'agenda pas accessible en écriture
				}
				if($allCalendarsFullAccess==true)								{$tmpAccessRight=3;}	//Que des agendas accessibles en écriture
				elseif($tmpMaxRight>=2)											{$tmpAccessRight=2;}	//Au moins 1 agenda accessible en écriture
				elseif($tmpMaxRight>=1 && $this->contentVisible=="public")		{$tmpAccessRight=1;}	//Au moins 1 agenda accessible en lecture/ecriture limité
				elseif($tmpMaxRight>=1 && $this->contentVisible=="public_cache"){$tmpAccessRight=0.5;}	//Au moins 1 agenda accessible en lecture/ecriture limité  :  lecture plage horaire uniquement!
				//Surcharge le droit d'accès?
				if($tmpAccessRight > $this->_accessRight)	{$this->_accessRight=$tmpAccessRight;}
			}
		}
		return $this->_accessRight;
 	}

	/*
	 * SURCHARGE : suppression d'evenement
	 */
	public function delete()
	{
		//init
		$calDeleteOn=(Req::isParam("_idCalDeleteOn"))  ?  Ctrl::getObj("calendar",Req::getParam("_idCalDeleteOn"))  :  null;
		//Suppr l'evt  :  sur un agenda spécifique  ||  Suppr un evt périodique à une date précise  ||  Suppression complète de l'evt
		if(!empty($calDeleteOn) && ($this->fullRight() || $calDeleteOn->editRight()))	{$this->deleteAffectation($calDeleteOn->_id);}
		elseif(Req::isParam("periodDateExceptionsAdd") && $this->fullRight())			{Db::query("UPDATE ap_calendarEvent SET periodDateExceptions=".Db::format($this->periodDateExceptions."@@".Req::getParam("periodDateExceptionsAdd")."@@")." WHERE _id=".$this->_id);}
		elseif($this->fullRight())														{Db::query("DELETE FROM ap_calendarEventAffectation WHERE _idEvt=".$this->_id);}
		//On supprime l'événement s'il est affecté à aucun agenda
		if(Db::getVal("SELECT count(*) FROM ap_calendarEventAffectation WHERE _idEvt=".$this->_id)==0)  {parent::delete();}
	}

	/*
	 * Agendas (objets) où l'evenement est affecté
	 * $confirmed = true / false / "all" pour récupérer toutes les affectations
	 */
	public function affectedCalendars($confirmed=true)
	{
		if($this->_confirmedCalendars===null){
			$this->_confirmedCalendars=Db::getObjTab("calendar","SELECT * FROM ap_calendar WHERE _id in (select _idCal as _id from ap_calendarEventAffectation T2 WHERE _idEvt=".$this->_id." and confirmed=1)");
			$this->_proposedCalendars=Db::getObjTab("calendar","SELECT * FROM ap_calendar WHERE _id in (select _idCal as _id from ap_calendarEventAffectation T2 WHERE _idEvt=".$this->_id." and confirmed is null)");
		}
		if($confirmed==true)		{return $this->_confirmedCalendars;}
		elseif($confirmed==false)	{return $this->_proposedCalendars;}
		elseif($confirmed=="all")	{return array_merge($this->_confirmedCalendars,$this->_proposedCalendars);}
	}

	/*
	 * Texte des agendas où l'evenement est affecté + ceux ou il est en attente de confirmation
	 */
	public function affectedCalendarsLabel()
	{
		if(Ctrl::$curUser->isUser())
		{
			$calendarsConfirmed=$calendarsUnconfirmed=null;
			foreach($this->affectedCalendars(true) as $objCalendar)		{$calendarsConfirmed.=", ".$objCalendar->title;}
			foreach($this->affectedCalendars(false) as $objCalendar)	{$calendarsUnconfirmed.=", ".$objCalendar->title;}
			if(!empty($calendarsConfirmed))		{$calendarsConfirmed=Txt::trad("CALENDAR_evtAffects")." ".trim($calendarsConfirmed,",")."<br>";}
			if(!empty($calendarsUnconfirmed))	{$calendarsUnconfirmed=Txt::trad("CALENDAR_evtAffectToConfirm")." ".trim($calendarsUnconfirmed,",");}
			return $calendarsConfirmed.$calendarsUnconfirmed;
		}
	}
	
	/*
	 * SURCHARGE : droit de suppression => fullRight
	 */
	public function deleteRight()
	{
		return ($this->fullRight() && $this->isNew()==false);
	}

	/*
	 * SURCHARGE : Menu contextuel
	 */
	public function contextMenu($options=null)
	{
		//Evt dans plusieurs agendas
		if(count($this->affectedCalendars())>1){
			$options["deleteLabel"]=Txt::trad("CALENDAR_deleteEvtCals");//"supprimer" devient "Supprimer dans tous les agendas"
			if(!empty($options["_idCal"]) && Ctrl::getObj("calendar",$options["_idCal"])->editRight())//si on a le droit : "Supprimer dans cet agenda"
				{$options["specificOptions"][]=["actionJs"=>"confirmRedir('".Txt::trad("confirmDelete",true)."','".$this->getUrl("delete")."&_idCalDeleteOn=".$options["_idCal"]."')", "iconSrc"=>"delete.png", "label"=>Txt::trad("CALENDAR_deleteEvtCal")];}
		}
		//Evt périodique : "Supprimer uniquement à cette date"
		if(!empty($options["curDateTime"]) && !empty($this->periodType) && $this->fullRight())
			{$options["specificOptions"][]=["actionJs"=>"confirmRedir('".Txt::trad("confirmDelete",true)."','".$this->getUrl("delete")."&periodDateExceptionsAdd=".date("Y-m-d",$options["curDateTime"])."')", "iconSrc"=>"delete.png", "label"=>Txt::trad("CALENDAR_deleteEvtDate")];}
		//Liste des agendas ou est affecté l'evenement
		if(!empty($options["specificOptions"]))  {$options["specificOptions"][]=["label"=>"<hr>"];}//sépare des autres "specificOptions"..
		$options["specificOptions"][]=["label"=>$this->affectedCalendarsLabel()];
		//Renvoie le menu surchargé
		return parent::contextMenu($options);
	}

	/*
	 * Vérifie s'il s'agit d'un evenement passé
	 */
	public function isOldEvt($timeReference)
	{
		return ((int)$timeReference>0 && strtotime($this->dateEnd)<$timeReference  &&  (empty($this->periodType) || (!empty($this->periodDateEnd) && strtotime($this->periodDateEnd)<$timeReference)));
	}

	/*
	 * Supprime une affectation à un agenda
	 */
	public function deleteAffectation($_idCal)
	{
		 $curCal=Ctrl::getObj("calendar",$_idCal);
		 if($this->fullRight() || $curCal->editContentRight())
			{Db::query("DELETE FROM ap_calendarEventAffectation WHERE _idEvt=".$this->_id." AND _idCal=".$curCal->_id);}
	}
}