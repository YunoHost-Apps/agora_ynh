<script type="text/javascript">
lightboxWidth(650);//Resize
</script>

<style>
.vEventLine		{display:table; width:100%; margin:5px;}
.vEventLine>div	{display:table-cell;}
.vEventDate		{width:200px;}
.vEventOptions	{width:50px;}

/*RESPONSIVE -> 490px!*/
@media screen and (max-width:490px){
	.vEventDate		{width:80px;}
}
</style>

<div class="lightboxContent">
	<div class="lightboxObjTitle"><?= Txt::trad("CALENDAR_evtAutor") ?></div>
	<hr>
	<!--LISTE DES EVT-->
	<?php foreach($myEvents as $tmpEvent){ ?>
	<div class="vEventLine sTableRow" title="<?= Txt::displayDate($tmpEvent->dateBegin,"full",$tmpEvent->dateEnd) ?><br><?= $tmpEvent->description ?>">
		<div class="vEventDate"><?= Txt::displayDate($tmpEvent->dateBegin,"normal",$tmpEvent->dateEnd) ?></div>
		<div class="vEventTitle"><?= $tmpEvent->title ?></div>
		<div class="vEventOptions">
			<img src="app/img/edit.png" class="sLink" onclick="lightboxOpen('<?= $tmpEvent->getUrl("edit") ?>')">
			<img src="app/img/delete.png" class="sLink" onclick="if(confirm('<?= Txt::trad("confirmDelete",true) ?>')) {lightboxClose(true,'<?= $tmpEvent->getUrl("delete") ?>');}">
		</div>
	</div>
	<?php } ?>
	<!--AUCUN EVT-->
	<?php if(empty($myEvents)){echo "<h3>".Txt::trad("CALENDAR_noEvt")."</h3>";} ?>
</div>