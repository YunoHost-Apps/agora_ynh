<script type="text/javascript">
lightboxWidth("800px");//Resize

////	Init la page
$(function(){
	//Switch de la sélection
	$("img[src*='switch.png']").click(function(){
		$(":checkbox[id^='boxEvent']").each(function(){
			$(this).prop("checked",!$(this).prop("checked")).trigger("change");
		});
	});
});

////	Contrôle du formulaire
function formControl()
{
	//Fichier Import au format csv
	if($("input[name='importFile']").exist()){
		if($("input[name='importFile']").isEmpty())						{notify("<?= Txt::trad("specifyFile") ?>");	return false;}
		else if(extension($("input[name='importFile']").val())!="ics")	{notify("<?= Txt::trad("fileExtension") ?> ICS");	return false;}
	}
}
</script>

<style>
form				{text-align:center;}
td					{text-align:left; vertical-align:top; padding:5px;}
.vTableHeader td	{background:#ddd; text-align:center;}
td:nth-child(1)		{width:30px;}
td:nth-child(2)		{width:100px;}
td:nth-child(3)		{width:150px;}
.vTableEvt:hover	{background:#eee;}
td img				{vertical-align:middle;}
.eventDescription	{font-weight:normal;}
</style>

<div class="lightboxContent">
	<div class="lightboxTitle"><?= Txt::trad("CALENDAR_importIcal") ?></div>

	<form action="index.php" method="post" enctype="multipart/form-data" onsubmit="return formControl()" class="lightboxContent">
		<!--SELECTION DU FICHIER D'IMPORT-->
		<?php if(empty($eventList)){ ?><input type="file" name="importFile"><?php } ?>

		<!--EVENEMENTS A IMPORTER-->
		<?php if(!empty($eventList)){ ?>
			<table>
				<!--HEADER-->
				<tr class="vTableHeader">
					<td title="<?= Txt::trad("invertSelection") ?>"><img src="app/img/switch.png" class="sLink"></td>
					<td><?= Txt::trad("CALENDAR_importIcalState") ?></td>
					<td><?= Txt::trad("begin")." - ".Txt::trad("end") ?></td>
					<td><?= Txt::trad("title") ?></td>
					<td><?= Txt::trad("description") ?></td>
				</tr>
				<!--LISTE D'EVENEMENTS-->
				<?php foreach($eventList as $cptEvt=>$tmpEvt){ ?>
					<tr class="vTableEvt">
						<td><input type="checkbox" name="eventList[<?= $cptEvt ?>][checked]" value="1" id="boxEvent<?= $cptEvt ?>"></td>
						<td><?= ($tmpEvt["isPresent"]==true)  ?  "<img src='app/img/dotR.png'> ".Txt::trad("CALENDAR_importIcalStatePresent")  :  "<img src='app/img/dotG.png'> ".Txt::trad("CALENDAR_importIcalStateImport") ?></td>
						<td><?= Txt::displayDate($tmpEvt["dbDateBegin"],"full",$tmpEvt["dbDateEnd"]) ?><input type="hidden" name="eventList[<?= $cptEvt ?>][dateBegin]" value="<?= $tmpEvt["dbDateBegin"] ?>"><input type="hidden" name="eventList[<?= $cptEvt ?>][dateEnd]" value="<?= $tmpEvt["dbDateEnd"] ?>"></td>
						<td><label for="boxEvent<?= $cptEvt ?>"><?= $tmpEvt["SUMMARY"] ?></label> <input type="hidden" name="eventList[<?= $cptEvt ?>][title]" value="<?= $tmpEvt["SUMMARY"] ?>"></td>
						<td class="eventDescription"><label for="boxEvent<?= $cptEvt ?>"><?= $tmpEvt["DESCRIPTION"] ?></label> <input type="hidden" name="eventList[<?= $cptEvt ?>][description]" value="<?= $tmpEvt["DESCRIPTION"] ?>"></td>
					</tr>
				<?php } ?>
			</table>
		<?php } ?>

		<!--VALIDATION DU FORM-->
		<?= Txt::formValidate() ?>
	</form>
</div>