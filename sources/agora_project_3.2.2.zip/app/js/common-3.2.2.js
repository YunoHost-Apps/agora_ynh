/**
*------------------------V3---------------------------
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * PAGE INIT  =>  PAGE LOAD / PAGE RESIZE / REQUETE AJAX
 */
$(function(){
	pageLoadTimestamp=Date.now();
	extendJquery();
	initTooltips();
	checkboxLabel();
	contextMenu();
	mainPageDisplay();													//menu flottant / largeur des blocks d'objet / clic sur les blocks d'objet / Gallerie d'image via LightBox  /  Etc.
	inputControls();													//Controles de champs (Datepickers, FileSize..)
	$(document).toastmessage({position:"top-center",stayTime:10000});	//Notifications
	$("input[type='password']").attr("autocomplete","off");				//Pass
	$(".confirmEventLib").effect("pulsate",{times:50},50000);			//"pulsate" sur les confirm. d'evt
});

/*
 * RESIZE : redéfini les elements de la page, avec "debounceDelay" pour lancer l'action en fin de resize
 */
if(isMobile()==false){
	$(window).resize(
		debounceDelay(function(){ mainPageDisplay(); },50)
	);
}

/*
 * PAGE INIT : Fonctions étendues à Jquery
 */
function extendJquery()
{
	////	Vitesse (duration) par défaut des effets : "fadeIn()", "toggle()", etc
	$.fx.speeds._default=100;

	////	Verifie l'existance d'un element
	$.fn.exist=function(){
		return (this.length>0) ? true : false;
	};
	////	Verifie si l'element n'a pas de valeur ("empty") ...et aussi s'il existe
	$.fn.isEmpty=function(){
		return (this.length==0 || this.val().length==0) ? true : false;
	};
	////	Focus sur un champs surligné en rouge
	$.fn.focusRed=function(){
		this.addClass("focusRed").focus();
	};
	////	Affichage/masquage d'element : "surcharge" de fonctions de base de Jquery
	if(inIframe())
	{
		var fadeInBASIC=$.fn.fadeIn;
		var showBASIC=$.fn.show;
		var toggleBASIC=$.fn.toggle;
		var slideToggleBASIC=$.fn.slideToggle;
		var fadeToggleBASIC=$.fn.fadeToggle;
		$.fn.fadeIn=function(){			lightboxResize();	return fadeInBASIC.apply(this,arguments); };
		$.fn.show=function(){			lightboxResize();	return showBASIC.apply(this,arguments); };
		$.fn.toggle=function(){			lightboxResize();	return toggleBASIC.apply(this,arguments); };
		$.fn.slideToggle=function(){	lightboxResize();	return slideToggleBASIC.apply(this,arguments); };
		$.fn.fadeToggle=function(){		lightboxResize();	return fadeToggleBASIC.apply(this,arguments); };
	}
}

/*
 * PAGE INIT : Init les tooltips avec Tooltipster (mettre la class "tooltip" & l'attribut "title" à la balise html)
 */
function initTooltips()
{
	if(!isMobile())
	{
		$("[title]").not(".noTooltip,[title='']").tooltipster({
			contentAsHTML:true,
			multiple:true,
			animation:"grow",
			delay:800,
			speed:100,
			position: "bottom",
			theme:"tooltipster-shadow"
		});
	}
}

/*
 * PAGE INIT : Click un label lié à une checkbox OU une checkbox lié à un label : change le style!
 *			La balise "<label>" doit avoir une propriété "for" correspondant à un "id" de checkbox
 *			Ignorer les "objectRight[]" & "targetObjects[]" qui ont leur propre fonctionnement (checkbox pour sélections et affectations)
 */
function checkboxLabel()
{
	//Lance une première fois la fonction (init)
	checkboxLabelStyle();
	//Lance ensuite à chaque changement de label/checkbox/radio
	$("label[for], :checkbox[id]:not([name^='objectRight'],[name^='targetObjects']), :radio[id]").change(debounceDelay(function(){  checkboxLabelStyle();  },100));
}
function checkboxLabelStyle()
{
	$(":checkbox[id]:not([name^='objectRight'],[name^='targetObjects']), :radio[id]").each(function(){
		if(this.checked)		{$("label[for='"+this.id+"']").removeClass("sLink").addClass("sLinkSelect");}
		else if(!this.disabled)	{$("label[for='"+this.id+"']").removeClass("sLinkSelect").addClass("sLink");}
		else					{$("label[for='"+this.id+"']").css("cursor","default");}//pas de "cursor:pointer"
	});
}

/*
 * Debounce : execute le code passé en paramètre (callback) après un certain délai, mais repousse l'execution du callback si "debounceDelay()" est relancée avant la fin du délai
 * Evite ainsi de saturer le browser, par exemple avec fonction qui fait boucler une sélection d'objets ou de labels
 */
function debounceDelay(callback, delay)
{
	//init le timer et lance la fonction avec le callback
	var debounceTimer;
	return function()
	{
		//Arguments et "this" rajoutés dans le "callback"
		var args=arguments;
		var context=this;
		clearTimeout(debounceTimer);
		//Lance le callback avec le delais demandé
		debounceTimer=setTimeout(function(){
			callback.apply(context, args);
		}, delay);
	}
}

/*
 * PAGE INIT : Init les menus contextuels
 * chaque launcher (icone/texte/block d'objet) doit avoir la propriété "for" correspondant à l'ID du menu  &&  une class "menuLaunch" (sauf les launcher de block d'objet) 
 */
function contextMenu()
{
	////	Mode responsive
	if(isMobile())
	{
		////	Click d'un launcher (icone/texte) : Affiche le menu
		$(".menuLaunch").click(function(){
			var tmpMenuId="#"+$(this).attr("for");
			//Menu déjà présent dans "#respMenuContent" : affiche en tant que "sous-menu"
			if($(tmpMenuId).parents("#respMenuContent").exist())	{$(tmpMenuId).addClass("contextMenuSubMenu").slideToggle();}
			//Sinon affichage normal dans "#respMenuContent"
			else{
				curRespMenuId=tmpMenuId;
				$(curRespMenuId+">*").appendTo("#respMenuContent");//Déplace le contenu du menu dans "#respMenuContent" (conserve les listeners par rapport à un clonage via "html()")
				$("#respMenuMain").show("slide",{direction:"right"},100);
				$("#respMenuBg").fadeIn();
				$("body").css("overflow","hidden");//pas de scroll de page en arriere plan
			}
		});
		//Masque le menu
		$("#respMenuBg, #respMenuClose, #respMenuMain").on("click swiperight",function(event){
			if(event.type=="swiperight" || (event.type=="click" && this.id!="respMenuMain")){
				$("#respMenuContent>*").appendTo(curRespMenuId);//Replace le menu dans le div d'origine
				$("#respMenuMain").hide("slide",{direction:"right"},100);
				$("#respMenuBg").fadeOut();
				$("body").css("overflow","visible");//remet le scroll sur le body (..normal)
			}
		});
	}
	////	Mode Normal
	else
	{
		////	Affiche via Mouseover ou click d'un launcher (icone/texte)
		$(".menuLaunch").on("mouseover click",function(event){
			event.stopPropagation();//Pas de probagation (selection du block ou autre)
			showContextMenu(this,event);
		});
		////	Affiche via Click Droit sur le block de l'objet
		$("[for^='objContextMenu_']").on("contextmenu",function(event){
			showContextMenu(this,event);
			return false;//pour pas afficher le menu du browser
		});
		////	Survol le block d'un objet : Masque les menus qui ne le concernent pas
		$("[for^='objContextMenu_']").on("mouseenter",function(){
			$(".contextMenu").not("#"+$(this).attr("for")).fadeOut();
		});
		////	Quitte le menu : on le masque
		$(".contextMenu").on("mouseleave",function(){
			$(this).fadeOut();
		});
		////	Click dans le menu : pas de propagation
		$(".contextMenu").click(function(event){
			event.stopPropagation();//Pas de probagation (selection du block ou autre)
		});
	}
}
/*
 * Affiche un menu contextuel
 */
function showContextMenu(launcher, event)
{
	////	Récup' l'Id du menu  &  Ferme les autres menus
	var menuId="#"+$(launcher).attr("for");
	$(".contextMenu").not(menuId).hide();
	////	Hauteur max du menu (fonction de la hauteur de page)
	$(menuId).css("max-height", Math.round($(window).height()-30)+"px");
	////	Positionne le menu en fonction du launcher
	var menuPosX=$(launcher).position().left;//Position du "launcher" : "menuLaunch" OU Block de l'objet ("contextmenu")
	var menuPosY=$(launcher).position().top;//idem
	////	Clic droit sur l'objet : Ajuste avec la position de la souris. Attention car la position "relative" du "objContainer" décale les "event.pageX/Y"
	if(event.type=="contextmenu")	{menuPosX=event.pageX-menuPosX-10;  menuPosY=event.pageY-menuPosY-10;}
	////	Menu au bord droit/bas de la page ?
	else
	{
		//Positions de base du menu
		var posMenuRight =menuPosX + $(menuId).outerWidth(true);
		var posMenuBottom=menuPosY + $(menuId).outerHeight(true);
		//Parent en position "relative" (majorité des cas) OU "absolute" : rajoute sa position
		var objSelector="#"+$(launcher).parent(".objContainer").attr("id");
		if($(objSelector).css("position")=="relative" || $(objSelector).css("position")=="absolute"){
			posMenuRight+=$(objSelector).offset().left;//utiliser "offset()" relatif au document et non "position()" relatif au parent..
			posMenuBottom+=$(objSelector).offset().top;
		}
		//Vérifie et ajuste si besoin la position
		var posPageRight=$(window).width();
		var posPageBottom=$(window).height()+$(window).scrollTop();
		if(posPageRight < posMenuRight)		{menuPosX=menuPosX-(posMenuRight-posPageRight)-10;}
		if(posPageBottom < posMenuBottom)	{menuPosY=menuPosY-(posMenuBottom-posPageBottom)-10;}
	}
	////	Positionne et affiche le menu
	$(menuId).css("left", Math.round(menuPosX)+"px").css("top", Math.round(menuPosY)+"px").fadeIn();
}

/*
 * Controle s'il s'agit d'un mail
 */
function isMail(mail)
{
	var mailRegex=/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	return mailRegex.test(mail);
}

/*
 * Cherche une expression dans une chaine de caracteres
 */
function find(needle, haystack)
{
	//Convertir en texte puis en minuscule : recherche la position de needle dans haystack
	if(typeof haystack!="undefined")	{return (haystack.toString().toLowerCase().indexOf( needle.toString().toLowerCase() ) >= 0) ? true : false;}
}

/*
 * Affiche un message de notification (via le plugin Jquery "toastmessage")
 */
function notify(message, typeNotif)
{
	if(typeNotif=="success")		{var toastType="showSuccessToast";}	//Type "success" (vert)
	else if(typeNotif=="warning")	{var toastType="showWarningToast";}	//Type "warning" (jaune)
	else							{var toastType="showNoticeToast";}	//Type "info" (bleu) => par défaut
	if(inIframe())	{parent.$().toastmessage(toastType, message);}
	else			{$().toastmessage(toastType, message);}
}

/*
 * Redirection page
 */
function redir(adress, redirMainPage)
{
	if(redirMainPage===true)	{window.parent.location.href=adress;}
	else						{window.location.href=adress;}
}

/*
 * Lancé depuis une iframe ?
 */
function inIframe()
{
	return (window.parent && window.parent.location!=window.location);
}

/*
 * Ouvre une lightbox
 * "url" doit être à "null" si "htmlContent" est précisé
 * via une fonction, et non des "href" : plus souple + n'interfère pas avec "stopPropagation()" des contextMenu()
 */
function lightboxOpen(url, htmlContent)
{
	//Lancé depuis le lightbox : relance la fonction depuis la fenetre parente
	if(inIframe()){
		parent.lightboxOpen(url, htmlContent);
	}
	//Pdf en mode Responsive : affiche directement le browser (sinon affiche dans le lightbox "PDF plugin is required")
	if(isMobile() && extension(url)=="pdf"){
		window.open(url);
	}
	//Affiche en mode html : pour du html/pdf/mp3/video
	else if(isEmptyValue(htmlContent)==false || extension(url)=="pdf" || extension(url)=="mp3" || videoPlayerOpen(url))
	{
		//Prépare le "content"
		var curContent="empty content";
		if(isEmptyValue(htmlContent)==false){curContent=htmlContent;}
		else if(extension(url)=="mp3")		{curContent='<audio controls autoplay><source src="'+url+'" type="audio/mpeg">HTML5 browser is required</audio>';}
		else if(videoPlayerOpen(url))		{curContent='<video controls autoplay><source src="'+url+'" type="video/'+extension(url)+'">HTML5 browser is required</video>';}
		else if(extension(url)=="pdf")		{curContent='<object data="'+url+'" type="application/pdf" height="'+Math.floor($(window).height()-100)+'px" width="'+Math.floor($(window).width()-100)+'px">PDF plugin is required</object>';}	
		//Affiche le fancybox & redimensionne en décalé (le temps du chargement d'un pdf par exemple)
		$.fancybox({content:curContent});
		setTimeout(function(){$.fancybox.update();},2000);
	}
	//Affiche en mode Iframe
	else
	{
		$.fancybox({
			type:"iframe",
			href:url,
			padding:(isMobile()?0:5),//padding entre le conteneur et le contenu
			margin:(isMobile()?[4,4,4,4]:[20,20,20,20]),//margin entre le fancybox et le bord de la page
			//Init le lightbox"
			beforeShow:function(){
				confirmCloseLightbox=false;//Page d'édition: confirmation à la fermeture de page
				if(find("edit",url))  {$(".fancybox-iframe").contents().find("form").on("click keyup",function(){ confirmCloseLightbox=true; });}
				this.width=$(".fancybox-iframe").contents().find("body").width();//Width du en fonction du contenu (cf. "lightboxWidth()")
			},
			//Demande confirmation de fermeture si on edite un element
			beforeClose:function(){
				if(confirmCloseLightbox==true)  {return confirm(labelConfirmCloseLightbox);}
			}
		});
	}
}

/*
 * Largeur d'une Lightbox (appelé depuis le lightbox)
 */
function lightboxWidth(pageWidth)
{
	$(function(){
		//Récup le width en pixel
		if(find("px",pageWidth))		{pageWidth=pageWidth.replace("px","");}
		else if(find("%",pageWidth))	{pageWidth=($(window.parent).width()/100) * pageWidth.replace("%","");}
		//Width du contenu > Width de la page (très petite resolution)
		if(pageWidth>$(window.parent).width())	{pageWidth=$(window.parent).width()-10;}/*"-10" pour conserver le padding du "fancybox-iframe"*/
		//Applique le width & Update le fancybox
		if(isEmptyValue(pageWidth)==false)	{$("body").css("width",pageWidth);}
		parent.$.fancybox.update();
	});
}

/*
 * Agrandit si besoin la hauteur d'une Lightbox : suite à un fadeIn() ou autre (avec "duration" de 100ms)
 */
function lightboxResize(forceResize)
{
	//Page déjà chargée && Lancé depuis une lightbox
	if(previouslyLoadedPage() && parent.$(".fancybox-skin").is(":visible"))
	{
		//Hauteur du LightBox au début des "fadeIn" and co
		lightboxHeightOld=(inIframe())  ?  parent.$(".fancybox-iframe").contents().height()  :  $(".fancybox-inner").contents().height();
		//Réinit le "setTimeout" si besoin : pas de cumul
		if(typeof lightboxResizeTimeout!="undefined")	{clearTimeout(lightboxResizeTimeout);}
		//Lance l'update si le contenu est plus grand, avec "setTimeout()" le temps qu'agissent les "fadeIn" and co
		lightboxResizeTimeout=setTimeout(function(){
			var lightboxHeightNew=(inIframe())  ?  parent.$(".fancybox-iframe").contents().height()  :  $(".fancybox-inner").contents().height();
			if(lightboxHeightOld < lightboxHeightNew || forceResize===true)	{parent.$.fancybox.update();}
		},300);
	}
}

/*
 * Afficher un "prompt" via le lightbox
 */
function lightboxPrompt(promptLabel, actionJS, inputType, defaultValue)
{
	if(isEmptyValue(inputType))		{inputType="text";}//"text" ou "password"
	if(isEmptyValue(defaultValue))	{defaultValue="";}//valeur par défaut dans l'input
	// Construit le formulaire
	var promptForm= "<div class='lightboxTitle'>"+promptLabel+"</div>"+
					"<input type='"+inputType+"' class='promptInputText' value=\""+defaultValue+"\" onkeydown=\"if(event.keyCode==13){"+actionJS+"}\"> &nbsp;"+
					"<button type='button' onclick=\"if($('.promptInputText').isEmpty()==false){"+actionJS+"}\">OK</button>";
	// Affiche le prompt et met le focus sur l'input
	$.fancybox({width:400,height:200,content:promptForm});
	setTimeout(function(){
		$.fancybox.update();
		$(".promptInputText").focus();//decalé car un autre focus peut être fait avant (cf. page de connexion)
	},1000);
}

/*
 * Ferme le lightbox & reload si besoin la page principale (appelé depuis le lightbox)
 */
function lightboxClose(reloadParentPage, reloadSpecificUrl, urlMsgNotif)
{
	//Reload la page principale ? Url => passé en paramètre OU .parent (lightbox)
	var reloadUrl=null;
	if(reloadParentPage===true)
	{
		reloadUrl=(isEmptyValue(reloadSpecificUrl)==false)  ?  reloadSpecificUrl  :  window.parent.location.href;
		//Spécifie "urlMsgNotif" : enlève les anciens "msgNotif" déjà affichés et ajoute le "urlMsgNotif"
		if(isEmptyValue(urlMsgNotif)==false){
			if(find("msgNotif",reloadUrl))	{reloadUrl=reloadUrl.substring(0,reloadUrl.indexOf('&msgNotif'));}
			reloadUrl+=urlMsgNotif;
		}
	}
	//Ferme le lightbox
	if(isEmptyValue(reloadUrl)==false)	{window.parent.location.replace(reloadUrl);}
	else								{parent.$.fancybox.close();}
}

/*
 * Vérifie si on est sur un appareil mobile/tactile
 */
function isMobile()
{
	var pattern=/android|iphone|ipad|ipod|blackberry|windows phone|tablet|touch/i;
	return (pattern.test(navigator.userAgent) || $(window.parent).width()<=1024) ? true : false;
}

/*
 * Version obsolete d'IE ?
 */
function isObsoleteIE()
{
	var vBrowser=navigator.appVersion;
	return (find("MSIE 5.",vBrowser) || find("MSIE 6.",vBrowser) || find("MSIE 7.",vBrowser) || find("MSIE 8.",vBrowser));
}

/*
 * Confirmer une action (suppression ou autre) puis rediriger
 */
function confirmRedir(confirmLabel, redirUrl, ajaxControlUrl, ajaxConfirmLabel)
{
	//Effectue un controle Ajax?
	if(isEmptyValue(ajaxControlUrl)==false){
		var ajaxResult=$.ajax({url:ajaxControlUrl,async:false}).responseText;//Attend la réponse Ajax pour passer à la suite (async:false)
		if(ajaxResult!="true" && confirm(ajaxConfirmLabel)==false)	{return false;}//exple : "Attention! certains sous-dossiers ne vous sont pas accessibles en lecture.."
	}
	//Lance la suppression?
	if(confirm(confirmLabel))	{redir(redirUrl);}
}

/*
 * Scroll vers un element OU en bas de page
 */
function toScroll(thisSelector)
{
	//Scroll si la page ne vient pas d'être chargé
	if(previouslyLoadedPage()){
		var heightReference=(typeof thisSelector!="undefined" && $(thisSelector).exist())  ?  $(thisSelector).position().top  :  $(document).height();
		$("html,body").animate({scrollTop:heightReference},100);
	}
}

/*
 * Extension d'un fichier (sans le point!)
 */
function extension(fileName)
{
	if(isEmptyValue(fileName)==false)	{return fileName.split('.').pop().toLowerCase();}
}

/*
 * Verif si un fichier peut être ouvert par le player vidéo
 * cf. "File::fileTypes('videoPlayer')"
 */
function videoPlayerOpen(fileName)
{
	var extensionFile=extension(fileName);
	return (extensionFile=="mp4" || extensionFile=="webm" || extensionFile=="ogg" || extensionFile=="mkv" || extensionFile=="flv");
}

/*
 * Vérifie si une chaine est au format Json
 */
function isJsonString(string)
{
	try{
		JSON.parse(string);
	}catch(e){
		return false;
	}
	return true;
}

/*
 * Vérifie si une valeure est "empty" (équivalent à php)
 */
function isEmptyValue(value)
{
	return (value==null || typeof value=="undefined" || value=="" || value==0);
}

/*
 * La page ne vient pas d'être chargée à l'instant
 */
function previouslyLoadedPage()
{
	return ((Date.now()-pageLoadTimestamp)>1500);//1500ms minimum!
}



/***************************************************************************************************************************/
/*******************************************	SPECIFIC FUNCTIONS	********************************************************/
/***************************************************************************************************************************/



/*
 * Contrôle de connexion à l'agora
 */
function controlConnect()
{
	var inputLogin=$("[name=connectLogin]");
	var inputPassword=$("[name=connectPassword]");
	if(inputLogin.isEmpty() || inputLogin.val()==inputLogin.attr("placeholder") || inputPassword.isEmpty() || inputPassword.val()==inputPassword.attr("placeholder")){
		notify(labelSpecifyLoginPassword);
		return false;
	}
}

/*
 * PAGE INIT : Initialise l'affichage des pages principales
 * => menu flottant / largeur des blocks d'objet / clic sur les blocks d'objet
 */
function mainPageDisplay()
{
	////	Header en mode "mobile"
	if(isMobile() && $(".headerBar").exist())
	{
		//Marge entre le header et le Contenu de la page : dès que la page est chargée avec les images
		$(window).load(function(){
			$(".pageFull,.pageCenter").css("margin-top", Math.round($(".headerBar").height()+15));
		});
		//Module courant affiché (launcher responsive)
		if($(".headerModuleSelect").exist())  {$("#headerModuleResp").html($(".headerModuleSelect").html()+"<img src='app/img/arrowBottom.png'>");}
	}

	////	Footer
	$(window).load(function(){
		if($("#pageFooterIcon").is(":visible"))		{$(".pageFull,.pageCenter").css("margin-bottom", $("#pageFooterIcon").outerHeight(true));}//Ne masque pas le bas du contenu principal : icone / texte du footer
		if($("#livecounterMain").is(":visible"))	{$(".pageFull,.pageCenter").css("margin-bottom", $("#livecounterMain").outerHeight(true));}//Idem : messenger
		$("#pageFooterHtml").css("max-width", ($(window).outerWidth(true)-$("#pageFooterIcon").outerWidth(true)) );//Pour que "pageFooterHtml" ne se superpose pas à "pageFooterIcon"
	});

	////	Menu du module flottant (menu de gauche)
	if(isMobile()==false && $(".pageModMenuContainer").exist())
	{
		var pageMenuPos=$(".pageModMenuContainer").position();
		$(window).scroll(function(){
			var pageMenuHeight=pageMenuPos.top;//Init la position top du menu
			$(".pageModMenuContainer").children().each(function(){ pageMenuHeight+=$(this).outerHeight(); });//hauteur de chaque element
			if(pageMenuHeight < $(window).height())		{$(".pageModMenuContainer").css("padding-top",$(window).scrollTop()+"px");}
		});
	}

	////	Définie la largeur des blocks d'objets en fonction de la largeur de la page
	if($(".objBlocks .objContainer").length>0)
	{
		//Marge & Largeur min/max des objets
		var objMargin=parseInt($(".objContainer").css("margin-right"));
		var objMinWidth=parseInt($(".objContainer").css("min-width"));
		var objMaxWidth=parseInt($(".objContainer").css("max-width")) + objMargin;//ajoute la marge pour l'application du "width()"
		//Largeur disponible
		var containerWidth=$(".pageFullContent").width();//pas de "innerWidth()" car cela ajoute le "padding"
		if(isMobile()==false && $(document).height()==$(window).height())	{containerWidth=containerWidth-18;}//pas d'ascenseur : anticipe son apparition
		//Calcul la largeur des objets
		var objWidth=null;
		var lineNbObjects=Math.ceil(containerWidth / objMaxWidth);//Nb maxi d'objets par ligne
		if(containerWidth < (objMinWidth*2))				{objWidth=containerWidth;  $(".objContainer").css("max-width",containerWidth);}	//On peut afficher qu'un objet par ligne : il prendra la largeur du conteneur
		else if($(".objContainer").length<lineNbObjects)	{objWidth=objMaxWidth;}															//Nb d'objets insuffisant pour remplir la 1ère ligne : il prendra sa largeur maxi
		else												{objWidth=Math.floor(containerWidth/lineNbObjects);}							//Sinon on calcul : fonction du conteneur et du nb d'objets par ligne
		//Applique la largeur des blocks (enlève le margin, car pas pris en compte par le "outerWidth")
		$(".objContainer").outerWidth((objWidth-objMargin)+"px");
	}

	////	Click/DblClick sur les blocks conteneurs des objets (l'id du block doit commencer par "objBlock_")
	if($(".objContainer").exist())
	{
		//Pas sur mobile
		if(isMobile()==false)
		{
			$(".objContainer").click(function(){
				//Init
				var blockId="#"+this.id;
				timeDblClick=500;
				if(typeof timeLastClick=="undefined")	{timeLastClick=Date.now();  containerIdLastClick=this.id;}
				//Double click?
				diffNowAndLastClick=(Date.now()-timeLastClick);
				var isDblClick=(diffNowAndLastClick>10 && diffNowAndLastClick<timeDblClick && containerIdLastClick==this.id);
				//Action sur l'objet
				if(isDblClick==true && $(blockId).attr("data-urlEdit"))		{lightboxOpen($(blockId).attr("data-urlEdit"));}//dblClick + "data-urlEdit" => édition d'objet
				else if(isDblClick==false && typeof objSelect=="function")	{objSelect(this.id);}							//click + fonction "objSelect()" => lance la fonction (cf. "VueObjMenuSelection.php")
				//Update "lastClickTime" & "containerIdLastClick"
				timeLastClick=Date.now();
				containerIdLastClick=this.id;
			});
		}
	}

	////	Initialise les galleries d'image ayant l'attribut "rel='lightboxGallery'"
	if($("[rel='lightboxGallery']").exist())
	{
		fancyboxThumbs=(!isMobile())  ?  {title:{type:'outside'},thumbs:{width:50,height:50}}  :  {title:null};
		$("[rel='lightboxGallery']").fancybox({
			openEffect:'elastic',
			closeEffect:'elastic',
			preload:3,
			padding:0,//img sans bordure
			helpers:fancyboxThumbs
		});
	}
}

/*
 * PAGE INIT : Initialise les controles de champs -> Datepickers, FileSize controls, Integer, etc
 */
function inputControls()
{
	////	Init le Datepicker jquery-UI
	$(".dateInput, .dateBegin, .dateEnd").datepicker({
		dateFormat:"dd/mm/yy",
		firstDay:1,
		showOtherMonths: true,
		selectOtherMonths: true,
		onSelect:function(date){
			//Select .dateBegin -> bloque la date minimum de .dateEnd (mais pas inversement!)
			if($(this).hasClass("dateBegin"))	{$(".dateEnd").datepicker("option","minDate",date);}
			//Trigger sur le champ concerné pour continuer l'action
			$(this).trigger("change");
		}
	});
	////	Init le plugin Timepicker (jquery-UI)
	if(jQuery().timepicker){
		$(".timeBegin, .timeEnd").timepicker({timeFormat:"H:i"});
	}
	////	Readonly sur les datepickers et timepickers
	if(isMobile())	{$(".dateInput, .dateBegin, .dateEnd, .timeBegin, .timeEnd").attr("readonly","readonly").css("background-color","white");}

	////	Controle les dates de début/fin
	$(".dateBegin, .dateEnd, .timeBegin, .timeEnd").change(function(){
		//Masque le champ H:M?
		if($(this).hasClass("dateBegin") || $(this).hasClass("dateEnd")){
			var timeClass=$(this).hasClass("dateBegin") ? ".timeBegin" : ".timeEnd";
			if($(this).isEmpty()==false)	{$(timeClass).show();}
			else							{$(timeClass).hide();  $(timeClass).val(null);}
		}
		//Controle des date/time
		if($(".dateBegin").isEmpty()==false || $(".dateEnd").isEmpty()==false)
		{
			//Controle des "H:M"
			if($(this).hasClass("timeBegin") || $(this).hasClass("timeEnd"))
			{
				//Champ à controler
				var timeClass=$(this).hasClass("timeBegin") ? ".timeBegin" : ".timeEnd";
				//controle Regex des H:M
				var timeRegex=/^[0-2][0-9][:][0-5][0-9]$/;
				if($(timeClass).isEmpty()==false && timeRegex.test($(timeClass).val())==false){
					notify("H:m error");
					$(timeClass).val(null);
					return false;
				}
				//précise H:M de fin si vide et début précisé
				if($(".timeEnd").isEmpty())  {$(".timeEnd").val($(".timeBegin").val());}
			}
			//Début après Fin : message d'erreur
			if($(".dateBegin").isEmpty()==false && $(".dateEnd").isEmpty()==false)
			{
				var timestampBegin=$(".dateBegin").datepicker("getDate").getTime()/1000;//getTime() renvoie des millisecondes..
				var timestampEnd=$(".dateEnd").datepicker("getDate").getTime()/1000;//idem
				if($(".timeBegin").isEmpty()==false)	{var hourMinute=$(".timeBegin").val().split(":");	timestampBegin=timestampBegin + (hourMinute[0]*3600) + (hourMinute[1]*60);}
				if($(".timeEnd").isEmpty()==false)		{var hourMinute=$(".timeEnd").val().split(":");		timestampEnd=timestampEnd + (hourMinute[0]*3600) + (hourMinute[1]*60);}
				if(timestampBegin > timestampEnd)
				{
					//Date/heure de fin reculé : message d'erreur
					if($(this).hasClass("dateEnd") || $(this).hasClass("timeEnd"))	{notify(labelDateBeginEndControl);}
					//Modif la date/heure de fin ("setTimeout" pour éviter une re-modif du timePicker)
					setTimeout(function(){
						$(".dateEnd").val($(".dateBegin").val());
						$(".timeEnd").val($(".timeBegin").val());
					},500);
				}
			}
		}
	});

	////	Controle la taille des fichiers des inputs "file"
	$("input[type='file']").change(function(){
		if($(this).isEmpty()==false && this.files[0].size > valueUploadMaxFilesize){
			$(this).val("");
			notify(labelUploadMaxFilesize);
		}
	});

	////	Inputs de type "integer" -> doivent avoir une classe "integerValue"
	$(".integerValue").on("change keyup",function(){ 
		$(this).val($(this).val().replace(/\D/g,''));
	});

	////	Affecte une couleur à un input "select" (chaque option doit avoir un attribut "data-color")
	$("select option").each(function(){
		var optionColor=$(this).attr("data-color");
		if(isEmptyValue(optionColor)==false)	{$(this).css("background-color",optionColor).css("color","#fff");}
	});
	$("select").change(function(){
		var optionColor=$(this).find("option:selected").attr("data-color");
		if(isEmptyValue(optionColor)==false)	{$(this).css("background-color",optionColor).css("color","#fff");}
		else									{$(this).css("background-color","#fff").css("color","#000");}
	});
}

/*
 * Confirmation (ou pas) d'événement
 */
function confirmEventProposition(_idCal, _idEvt, divId)
{
	//Init
	var confirmed=false;
	var ajaxUrl="?ctrl=calendar&action=confirmEventProposition&targetObjId=calendar-"+_idCal+"&_idEvt="+_idEvt;
	//Demande de confirmation
	if(confirm(labelEvtConfirm))			{ajaxUrl+="&confirmed=1";  confirmed=true;}
	else if(confirm(labelEvtConfirmNot))	{ajaxUrl+="&confirmed=0";  confirmed=true;}
	//Lance la requête en Ajax
	if(confirmed==true){
		$.ajax(ajaxUrl).done(function(ajaxResult){
			//erreur ajax  ||  recharge la page et le calendrier  ||  supprime la proposition du menu
			if(find("true",ajaxResult)==false)	{notify("Confirm event proposition error");}
			else if(getUrlParam("ctrl",window.location.href)=="calendar")  {redir("?ctrl=calendar");}
			else{
				$("#"+divId).hide();
				if($(".confirmEventProposition").is(":visible")==false)  {$(".confirmEventLib").hide();}
			}
		});
	}
}

/*
 * Affectations des Spaces<->Users : userEdit OU spaceEdit (Click de Label/Checkbox)
 */
function initSpaceAffectations()
{
	//Click de Label
	$(".spaceAffectTable label").click(function(){
		//init
		var _idTarget=this.id.replace("target","");
		var box1="[name='spaceAffect[]'][value='"+_idTarget+"_1']";
		var box2="[name='spaceAffect[]'][value='"+_idTarget+"_2']";
		//Bascule les checkboxes
		var boxToCheck=null;
		if(!$(box1).prop("disabled") && !$(box1).prop("checked") && !$(box2).prop("checked"))	{boxToCheck=box1;}
		else if($(box1).prop("checked") && !$(box2).prop("checked"))							{boxToCheck=box2;}
		//Uncheck les boxes (sauf si disabled), Check celle sélectionnée
		$("[name='spaceAffect[]'][value^='"+_idTarget+"_']").not(":disabled[name='spaceAffect[]']").prop("checked",false);
		if(boxToCheck!=null)	$(boxToCheck).prop("checked",true);
		//Style des labels
		spaceAffectStyle();
	});
	//Click de Checkbox
	$(".spaceAffectTable :checkbox").change(function(){
		var _idTarget=$(this).val().slice(0, $(this).val().lastIndexOf("_"));//exple "1_2" => "1"
		$("[name='spaceAffect[]'][value^='"+_idTarget+"_']").not(this).not(":disabled[name='spaceAffect[]']").prop("checked",false);//"uncheck" les autres checkbox du "target"
		spaceAffectStyle();//Style des labels
	});
	//Init le style des labels
	spaceAffectStyle();
};

/*
 * Applique un style aux labels avec une checkbox cochée
 */
function spaceAffectStyle()
{
	//Réinit le style des labels et rows
	$(".spaceAffectTable label").removeClass("sAccessRead sAccessWrite");
	$(".spaceAffectRow").removeClass("sTableRowSelect");
	//Stylise les labels && la ligne sélectionnées
	$("[name='spaceAffect[]']:checked").each(function(){
		//récupère l'id de la cible && le droit d'accès associé à la box
		var targetRight=this.value.split('_').pop();
		var targetId=this.value.replace('_'+targetRight, '');
		//Stylise le label et la ligne
		if(targetRight=="2")		{$("#target"+targetId).addClass("sAccessWrite");}
		else if(targetRight=="1")	{$("#target"+targetId).addClass("sAccessRead");}
		$("#rowTarget"+targetId).addClass("sTableRowSelect");
	});
}

/*
 * Calcul la hauteur disponible pour le contenu principal de la page
 */
function availableContentHeight()
{
	//Height de la fenêtre (pas la page!)  -  Position "top" du contenu  -  Height du livecounter (visible)  -  Height du footer (visible)  -  12px de marge
	return Math.round($(window).height() - $(".pageCenterContent,.pageFullContent,.pageEmptyContent").offset().top - $("#pageFooterIcon:visible").outerHeight() -12);
}

/*
 * Récupère dans une Url la valeur d'un parametre
 */
function getUrlParam(paramName, url)
{
	paramName=paramName.replace(/[\[\]]/g, "\\$&");
	var regex=new RegExp("[?&]"+paramName+"(=([^&#]*)|&|#|$)");
	var results=regex.exec(url);
	if(!results)			{return null;}
	else if(!results[2])	{return '';}
	else					{return decodeURIComponent(results[2].replace(/\+/g," "));}
}