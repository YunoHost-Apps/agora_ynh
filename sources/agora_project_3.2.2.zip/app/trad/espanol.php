<?php
/*
 * Classe de gestion d'une langue
 */
class Trad extends Txt
{
	/*
	 * Chargement les elements de traduction
	 */
	public static function loadTradsLang()
	{
		////	Header http / Editeurs Tinymce,DatePicker,etc / Dates formatées par PHP
		self::$trad["CURLANG"]="es";
		self::$trad["HEADER_HTTP"]="es";
		self::$trad["DATEPICKER"]="es";
		self::$trad["HTML_EDITOR"]="es";
		self::$trad["UPLOADER"]="es";
		setlocale(LC_TIME, "es_ES.utf8", "es_ES.UTF-8", "es_ES", "es", "spanish");

		////	Divers
		self::$trad["OK"]="OK";
		self::$trad["fillAllFields"]="Gracias rellene todos los campos";
		self::$trad["inaccessibleElem"]="Elemento inaccesible";
		self::$trad["warning"]="Atención";
		self::$trad["elemEditedByAnotherUser"]="El elemento está siendo editado por";//"..bob"
		self::$trad["requiredFields"]="Campo obligatorio";
		self::$trad["yes"]="sí";
		self::$trad["no"]="no";
		self::$trad["none"]="no";
		self::$trad["and"]="y";
		self::$trad["goToPage"]="Ir a la página";
		self::$trad["alphabetFilter"]="Filtro alfabético";
		self::$trad["displayAll"]="Mostrar todo";
		self::$trad["anyCategory"]="Cualquier categoría";
		self::$trad["important"]="importante";
		self::$trad["show"]="mostrar";
		self::$trad["hide"]="ocultar";
		self::$trad["keep"]="Mantengar";
		self::$trad["byDefault"]="Por defecto";
		self::$trad["mapLocalize"]="Localizar en el mapa";
		self::$trad["mailInvalid"]="El correo electrónico no es válida";
		self::$trad["element"]="elemento";
		self::$trad["elements"]="elementos";
		self::$trad["folder"]="directorio";
		self::$trad["folders"]="directorios";
		self::$trad["close"]="Cerrar";
		self::$trad["visibleSpaces"]="Espacios en los que será visible";
		self::$trad["visibleAllSpaces"]="Visible en todos los espacios";
		self::$trad["confirmCloseLightbox"]="¿Quieres cerrar el formulario?";
		self::$trad["modifRecorded"]="Los cambios fueron registrados";

		////	Menu/Menu contextuel
		self::$trad["objNew"]="nuevo elemento";
		self::$trad["objNewInfos"]="Creado desde mi anterior conexión o creado dentro de las 24 horas";
		self::$trad["personalAccess"]="Acceso personal";
		
		////	images
		self::$trad["picture"]="foto";
		self::$trad["wallpaper"]="papel tapiz";
		self::$trad["imgChange"]="cambiar";
		self::$trad["pixels"]="píxeles";
		
		////	Connexion
		self::$trad["SpecifyLoginPassword"]="Gracias a especificar un nombre de usuario y contraseña";
		self::$trad["login"]="Identificador";
		self::$trad["login2"]="Identificador de conexión";
		self::$trad["placeholderLogin"]="Email / Identificador";
		self::$trad["password"]="Contraseña";
		self::$trad["passwordToModify"]="Contraseña (cambiar)";
		self::$trad["passwordVerif"]="Confirmar contraseña";
		self::$trad["passwordInfo"]="Dejar en blanco si desea mantener su contraseña";
		self::$trad["passwordVerifError"]="Su confirmación de contraseña no es válida";
		self::$trad["connect"]="Conexión";
		self::$trad["connectAuto"]="mantengamos el contacto";
		self::$trad["connectAutoInfo"]="Recordar mi nombre de usuario y la contraseña para una conexión automática";
		self::$trad["forgotPassword"]="¿ olvidado sus datos de acceso ?";
		self::$trad["forgotPasswordInfo"]="Enviar mi nombre de usuario y contraseña a mi dirección de correo electrónico (si se especifica)";
		self::$trad["guestAccess"]="Acceso de invitado";
		self::$trad["spacePassError"]="Contraseña incorrecta";
		self::$trad["ieObsolete"]="Su navegador es demasiado viejo y no soporta todos los elementos de HTML : Se recomienda actualizarlo o utilizar otro navegador";
		
		////	Affichage
		self::$trad["displayMode"]="Mostrar";
		self::$trad["displayMode_line"]="Lista";
		self::$trad["displayMode_block"]="Bloque";
		
		////	Sélectionner / Déselectionner tous les éléments
		self::$trad["select"]="seleccionar";
		self::$trad["selectUnselect"]="seleccionar / deseleccionar";
		self::$trad["selectAll"]="Seleccionar todo";
		self::$trad["invertSelection"]="Invertir selección";
		self::$trad["deleteElems"]="Eliminar elementos";
		self::$trad["changeFolder"]="Mover a otro directorio";
		self::$trad["showOnMap"]="Mostrar en el mapa";
		self::$trad["selectUser"]="Gracias por seleccionar al menos un usuario";
		self::$trad["selectUsers"]="Gracias por seleccionar por lo menos dos usuarios";
		self::$trad["selectSpace"]="Gracias por elegir al menos un espacio";
		
		////	Temps ("de 11h à 12h", "le 25-01-2007 à 10h30", etc.)
		self::$trad["from"]="de";
		self::$trad["at"]="a";
		self::$trad["the"]="el";
		self::$trad["begin"]="inicio";
		self::$trad["end"]="Fin";
		self::$trad["hourSeparator"]="h";
		self::$trad["days"]="dias";
		self::$trad["day_1"]="lunes";
		self::$trad["day_2"]="Martes";
		self::$trad["day_3"]="miércoles";
		self::$trad["day_4"]="Jueves";
		self::$trad["day_5"]="Viernes";
		self::$trad["day_6"]="Sábado";
		self::$trad["day_7"]="Domingo";
		self::$trad["month_1"]="Enero";
		self::$trad["month_2"]="Febrero";
		self::$trad["month_3"]="marzo";
		self::$trad["month_4"]="Abril";
		self::$trad["month_5"]="Mayo";
		self::$trad["month_6"]="Junio";
		self::$trad["month_7"]="julio";
		self::$trad["month_8"]="agosto";
		self::$trad["month_9"]="Septiembre";
		self::$trad["month_10"]="octubre";
		self::$trad["month_11"]="Noviembre";
		self::$trad["month_12"]="Diciembre";
		self::$trad["today"]="hoy";
		self::$trad["displayToday"]="Ver hoy";
		self::$trad["beginEndError"]="La fecha de fin no puede ser anterior a la fecha de inicio";
		self::$trad["dateFormatError"]="La fecha debe estar en el formato dd/mm/AAAA";
		
		////	Nom & Description (pour les menus d'édition principalement)
		self::$trad["title"]="Título";
		self::$trad["name"]="Nombre";
		self::$trad["description"]="Descripción";
		self::$trad["specifyName"]="Gracias por especificar un nombre";
		
		////	Validation des formulaires
		self::$trad["add"]=" Añadir";
		self::$trad["modify"]=" Editar";
		self::$trad["modifyAndAccesRight"]="Editar + derechos de acceso";
		self::$trad["validate"]=" Validar";
		self::$trad["send"]="Enviar";
		self::$trad["sendTo"]="Enviar a";
		
		////	Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
		self::$trad["sortBy"]="Ordenar por";
		self::$trad["SORT_dateCrea"]="fecha de creación";
		self::$trad["SORT_dateModif"]="fecha de modification";
		self::$trad["SORT_title"]="Título";
		self::$trad["SORT_description"]="Descripción";
		self::$trad["SORT__idUser"]="autor";
		self::$trad["SORT_extension"]="Tipo de archivo";
		self::$trad["SORT_octetSize"]="tamaño";
		self::$trad["SORT_downloadsNb"]="downloads";
		self::$trad["SORT_civility"]="civilidad";
		self::$trad["SORT_name"]="appelido";
		self::$trad["SORT_firstName"]="nombre";
		self::$trad["SORT_adress"]="dirección";
		self::$trad["SORT_postalCode"]="Código postal";
		self::$trad["SORT_city"]="ciudad";
		self::$trad["SORT_country"]="país";
		self::$trad["SORT_function"]="función";
		self::$trad["SORT_companyOrganization"]="compañía / organización";
		self::$trad["tri_ascendant"]="Ascendente";
		self::$trad["tri_descendant"]="Descendente";
		
		////	Options de suppression
		self::$trad["confirmDelete"]="Confirmar eliminación ?";
		self::$trad["confirmDeleteDouble"]="Está seguro ?!";
		self::$trad["confirmDeleteFolder"]="Advertencia : algunos sub-directorios no son accessible : serán tambien eliminados !";
		self::$trad["delete"]="Eliminar";
		
		////	Visibilité d'un Objet : auteur et droits d'accès
		self::$trad["autor"]="Autor";
		self::$trad["creation"]="Creación";
		self::$trad["modification"]="Modif";
		self::$trad["objHistory"]="histórico del elemento";
		self::$trad["guest"]="invitado";
		self::$trad["guests"]="invitados";
		self::$trad["all"]="todos";
		self::$trad["unknown"]="desconocido";
		self::$trad["accessRead"]="lectura";
		self::$trad["readInfos"]="Acceso en lectura";
		self::$trad["accessWriteLimit"]="escritura limitada";
		self::$trad["readLimitInfos"]="Acceso en escritura limitada : possibilidad de añadir elementos (-ELEMENT-), sin modificar o suprimir los creados por otros usuarios";
		self::$trad["accessWrite"]="escritura";
		self::$trad["writeInfos"]="Acceso en escritura";
		self::$trad["writeInfosContainer"]="Acceso en escritura : possibilidad de añadir, modificar o suprimir<br>todos los elementos (-ELEMENT-) del -CONTENEUR-";
		self::$trad["autorPrivilege"]="Solo el autor y los administradores pueden cambiar<br>los permisos de acceso o eliminar el -CONTENEUR-";
		self::$trad["folderContent"]="contenido";
		
		////	Libellé des objets
		self::$trad["OBJECTcontainer"]="contenedor";
		self::$trad["OBJECTelement"]="elemento";
		self::$trad["OBJECTfolder"]="directorio";
		self::$trad["OBJECTdashboardNews"]="novedade";
		self::$trad["OBJECTfile"]="archivo";
		self::$trad["OBJECTcalendar"]="calendario";
		self::$trad["OBJECTcalendarEvent"]="evento";
		self::$trad["OBJECTforumSubject"]="tema";
		self::$trad["OBJECTforumMessage"]="mensaje";
		self::$trad["OBJECTcontact"]="contacto";
		self::$trad["OBJECTlink"]="favorito";
		self::$trad["OBJECTtask"]="tarea";
		self::$trad["OBJECTuser"]="usuario";
		
		////	Envoi d'un mail (nouvel utilisateur, notification de création d'objet, etc...)
		self::$trad["MAIL_noFooter"]="No firme el mensaje";
		self::$trad["MAIL_noFooterInfo"]="No firme el final del mensaje con el nombre del remitentey un enlace al espacio";
		self::$trad["MAIL_hideRecipients"]="Ocultar los destinatarios";
		self::$trad["MAIL_hideRecipientsInfo"]="Por defecto, los destinatarios de correo electrónico aparecen en el mensaje.";
		self::$trad["MAIL_receptionNotif"]="Confirmación de entrega";
		self::$trad["MAIL_receptionNotifInfo"]="Advertencia! algunos clientes de correo electrónico no soportan el recibo de entrega";
		self::$trad["MAIL_sendBy"]="Enviado por";  // "Envoyé par" M. Trucmuche
		self::$trad["MAIL_sendOk"]="El correo electrónico ha sido enviado !";
		self::$trad["MAIL_sendNotif"]="El correo electrónico de notificación ha sido enviado !";
		self::$trad["MAIL_notSend"]="El correo electrónico no se pudo enviar..."; // idem
		self::$trad["MAIL_elemCreatedBy"]="Nuevo elemento creado por";//boby
		self::$trad["MAIL_elemModifiedBy"]="Elemento modificado por";//boby
		self::$trad["MAIL_elemOnSpace"]="en el espacio";//truc
		self::$trad["MAIL_elemAccessLink"]="Haga clic aquí para acceder al elemento en su espacio";

		////	Dossier & fichier
		self::$trad["gigaOctet"]="GB";
		self::$trad["megaOctet"]="MB";
		self::$trad["kiloOctet"]="KB";
		self::$trad["rootFolder"]="Directorio raíz";
		self::$trad["rootFolderEditInfo"]="Abra la configuración del espacio<br>para cambiar los derechos de acceso a la carpeta raíz";
		self::$trad["addFolder"]="añadir un directorio";
		self::$trad["download"]="Descargar archivos";
		self::$trad["downloadNb"]="Descargado";
		self::$trad["downloadNb2"]="veces"; // Téléchargé 'n' fois
		self::$trad["downloadFolder"]="Descargar el directorio";
		self::$trad["diskSpaceUsed"]="Espacio utilizado";
		self::$trad["diskSpaceUsedModFile"]="Espacio utilizado para los Archivos";
		self::$trad["downloadAlert"]="La descarga de archivos de gran tamaño no están disponibles durante el día";//..(9h=>19h)
		self::$trad["downloadAlert2"]="Tamaño máximo del archivo durante estas horas";//..200Mo
		
		////	Infos sur une personne
		self::$trad["civility"]="Civilidad";
		self::$trad["name"]="Appelido";
		self::$trad["firstName"]="Nombre";
		self::$trad["adress"]="Dirección";
		self::$trad["postalCode"]="Código postal";
		self::$trad["city"]="Ciudad";
		self::$trad["country"]="País";
		self::$trad["telephone"]="Teléfono";
		self::$trad["telmobile"]="teléfono móvil";
		self::$trad["mail"]="Email";
		self::$trad["fax"]="Fax";
		self::$trad["website"]="Página web";
		self::$trad["skills"]="Habilidades";
		self::$trad["hobbies"]="Intereses";
		self::$trad["function"]="Función";
		self::$trad["companyOrganization"]="compañía / organización";
		self::$trad["comment"]="Comentario";
		
		////	Captcha
		self::$trad["captcha"]="Identificación Visual";
		self::$trad["captchaInfo"]="Por favor, escriba los 4 caracteres para su identificación";
		self::$trad["captchaSpecify"]="Por favor, especifique la identificación visual";
		self::$trad["captchaError"]="La identificación visual no es valida";
		
		////	Rechercher
		self::$trad["searchSpecifyText"]="Por favor, especifique las palabras clave de al menos 3 caracteres";
		self::$trad["search"]="Buscar";
		self::$trad["searchDateCrea"]="Fecha de creación";
		self::$trad["searchDateCreaDay"]="menos de un día";
		self::$trad["searchDateCreaWeek"]="menos de una semana";
		self::$trad["searchDateCreaMonth"]="menos de un mes";
		self::$trad["searchDateCreaYear"]="menos de un año";
		self::$trad["searchOnSpace"]="Buscar en el espacio";
		self::$trad["advancedSearch"]= "Búsqueda avanzada";
		self::$trad["advancedSearchSomeWords"]= "cualquier palabra";
		self::$trad["advancedSearchAllWords"]= "todas las palabras";
		self::$trad["advancedSearchExactPhrase"]= "frase exacta";
		self::$trad["keywords"]="Palabras clave";
		self::$trad["listModules"]="Módulos";
		self::$trad["listFields"]="Campos";
		self::$trad["listFieldsElems"]="Elementos involucrados";
		self::$trad["noResults"]="No hay resultados";
		
		////	Gestion des inscriptions d'utilisateur
		self::$trad["usersInscription"]="registrarse en el sitio";
		self::$trad["usersInscriptionInfo"]="crear una nueva cuenta de usuario (validado por un administrador)";
		self::$trad["usersInscriptionSpace"]="registrarse al espacio";
		self::$trad["usersInscriptionRecorded"]="Su registro será validado tan pronto como sea posible por el administrador del espacio";
		self::$trad["usersInscriptionOptionSpace"]="Permitir a los visitantes que se registren en el espacio";
		self::$trad["usersInscriptionOptionSpaceInfo"]="El registro se encuentra en la página de inicio. Debe ser validado por el administrador del espacio.";
		self::$trad["usersInscriptionValidate"]="Registros";
		self::$trad["usersInscriptionValidateInfo"]="Validar registros de usuarios al espacio";
		self::$trad["usersInscriptionInvalidate"]="invalidar";
		self::$trad["usersInscriptionInvalidateMail"]="Su cuenta no ha sido validado en";
		
		////	Importer ou Exporter : Contact OU Utilisateurs
		self::$trad["export"]="Exportar";
		self::$trad["import"]="Importar";
		self::$trad["importExport_user"]="usuarios";
		self::$trad["importExport_contact"]="contactos";
		self::$trad["exportFormat"]="formato";
		self::$trad["specifyFile"]="or favor, especifique un archivo";
		self::$trad["fileExtension"]="El tipo del archivo no es válido. Debe ser de tipo";
		self::$trad["importInfo"]="Seleccione los campos (Agora) de destino con las listas desplegables de cada columna.";
		self::$trad["importNotif"]="Por favor, seleccione la columna de nombre en las listas desplegables";
		self::$trad["importNotif2"]="Por favor, seleccione al menos un contacto para importar";
		self::$trad["importNotif3"]="El campo Agora ya ha sido seleccionado en otra columna (cada campo Agora se puede seleccionar sólo una vez)";
		
		////	Messages d'alert ou d'erreur
		self::$trad["NOTIF_identification"]="Nombre de usuario o contraseña no válida";
		self::$trad["NOTIF_presentIp"]="Cuenta actualmente utilizada con una dirección IP diferente... (una cuenta puede ser utilizada en una sola computadora al mismo tiempo)";
		self::$trad["NOTIF_adressIp"]="La dirección IP utilizada no está permitida con esta cuenta";
		self::$trad["NOTIF_noSpaceAccess"]="El acceso no esta actualmente permitido con este cuente : probablemente no asignado a un espacio.";
		self::$trad["NOTIF_fileOrFolderAccess"]="El archivo o directorio no está disponible";
		self::$trad["NOTIF_diskSpace"]="El espacio para almacenar sus archivos no es suficiente, no se puede añadir archivos";
		self::$trad["NOTIF_fileVersionForbidden"]="Tipo de archivo no permitido";
		self::$trad["NOTIF_fileVersion"]="Tipo de archivo diferente del original";
		self::$trad["NOTIF_folderMove"]="No se puede mover el directorio dentro de sí mismo..!";
		self::$trad["NOTIF_duplicateName"]="Un elemento con el mismo nombre ya existe.";
		self::$trad["NOTIF_fileName"]="Un archivo con el mismo nombre ya existe (no ha sido reemplazado)";
		self::$trad["NOTIF_chmodDATAS"]="El directorio ''DATAS'' no es accesible por escrito. Usted necesita dar un acceso de lectura y escritura para el propietario y el grupo (''chmod 775'').";
		self::$trad["NOTIF_usersNb"]="No se puede añadir un nuevo usuario : se limita a "; // "...limité à" 10
		self::$trad["NOTIF_update"]="Se llevó a cabo una actualización";
		self::$trad["NOTIF_usersExist"]="El nombre de usuario ya existe : el usuario no se ha creado";
		
		////	header menu / Footer
		self::$trad["HEADER_displaySpace"]="Espacios disponibles";
		self::$trad["HEADER_displayAdmin"]="Visualización de Administrador";
		self::$trad["HEADER_displayAdminInfo"]="Mostrar TODOS los elementos del espacio (solo para los administradores)";
		self::$trad["HEADER_searchElem"]="Buscar en el espacio";
		self::$trad["HEADER_documentation"]="Documentación";
		self::$trad["HEADER_disconnet"]="Cerrar sesión del Ágora";
		self::$trad["HEADER_shortcuts"]="Acceso directo";
		self::$trad["MESSENGER_messenger"]="Mensajería instantánea";
		self::$trad["MESSENGER_currentlyAlone"]="Actualmente sólo";
		self::$trad["MESSENGER_connected"]="Conectado";
		self::$trad["MESSENGER_connectedSince"]="conectado a";//connecté depuis 12:45
		self::$trad["MESSENGER_sendAt"]="Enviado a";
		self::$trad["MESSENGER_addMessageToSelection"]="Mi mensaje (personas seleccionadas)";
		self::$trad["MESSENGER_addMessageTo"]="Mi mensaje a";
		self::$trad["MESSENGER_addMessageNotif"]="Por favor, especifique un mensaje";
		self::$trad["FOOTER_pageGenerated"]="página generada en";
		
		////	forgotPassword
		self::$trad["FORGOTPASS_preciseMail"]="Introduzca la dirección de correo electrónico para recibir su nombre de usuario y contraseña";
		self::$trad["FORGOTPASS_noMail"]="El correo electrónico no está indicado en la base";
		self::$trad["FORGOTPASS_changePass"]="Especifique su nueva contraseña";
		self::$trad["FORGOTPASS_expired_idNewPassword"]="El enlace para regenerar la contraseña ha caducado .. gracias por reiniciar la procedura";
		self::$trad["FORGOTPASS_reinitPassword"]="Su nueva contraseña se registró !";
		
		////	vueObjMenuEdit
		self::$trad["EDIT_notifNoSelection"]="Debe seleccionar al menos una persona o un espacio";
		self::$trad["EDIT_notifNoPersoAccess"]="Usted no se ha asignado al elemento. validar todos lo mismo ?";
		self::$trad["EDIT_notifWriteAccess"]="Debe haber al menos una persona o un espacio asignado para escribir";
		self::$trad["EDIT_notifWriteAdvice"]="¡Advertencia! <br><br>Con acceso de escritura, TODOS los mensajes pueden ser eliminados ! Se recomienda limitar el acceso a escritura";
		self::$trad["EDIT_parentFolderAccessError"]="Comprobar el derecho de acceso de <i>--TARGET_LABEL--</i> a la carpeta <i>--FOLDER_NAME--</i>: <br><br>si no hay asignaciónes, el acceso a la carpeta actual será imposible.";
		self::$trad["EDIT_notifGuest"]="Por favor, especifique un nombre o apodo de";
		self::$trad["EDIT_accessRight"]="Derechos de acceso";
		self::$trad["EDIT_accessRightContent"]="Derechos de acceso al contenido";
		self::$trad["EDIT_identification"]="Identificación";
		self::$trad["EDIT_spaceNoModule"]="El módulo actual aún no se ha añadido a este espacio";
		self::$trad["EDIT_allUsers"]="Todos los usuarios";
		self::$trad["EDIT_allUsersInfo"]="Todos los usuarios del espacio";
		self::$trad["EDIT_allSpaces"]="Todos los espacios";
		self::$trad["EDIT_spaceGuests"]="Invitados del espacio público";
		self::$trad["EDIT_guest"]="Tu nombre / apodo";
		self::$trad["EDIT_adminSpace"]="Administrador del espacio:<br>acceso de escritura a todos los elementos del espacio";
		self::$trad["EDIT_mySpaces"]="Mostrar todos mis espacios";
		self::$trad["EDIT_notifMail"]="Notificación por correo electrónico";
		self::$trad["EDIT_notifMail2"]="Notificación por correo electrónico";
		self::$trad["EDIT_notifMailAddFiles"]="Adjuntar archivos a la notificación";
		self::$trad["EDIT_notifMailInfo"]="Enviar notificación de creación/cambio por correo electrónico a los que tienen acceso al elemento";
		self::$trad["EDIT_notifMailSelect"]="Seleccionar manualmente los destinatarios de las notificaciones";
		self::$trad["EDIT_notifMailMoreUsers"]="Mostrar mas usuarios";
		self::$trad["EDIT_accessRightSubFolders"]="Dar igualdad de derechos a todos los sub-directorios";
		self::$trad["EDIT_accessRightSubFolders_info"]="Extender los derechos de acceso, a los sub-directorios que se pueden editar";
		self::$trad["EDIT_shortcut"]="Acceso directo";
		self::$trad["EDIT_shortcutInfo"]="Mostrar un acceso directo en el menú principal";
		self::$trad["EDIT_attachedFile"]="Añadir archivos";
		self::$trad["EDIT_attachedFileInfo"]="Añadir fotos, vídeos, PDF, Word.. al objeto actual.<br>Imágenes y videos se pueden integrar directamente en el editor.";
		self::$trad["EDIT_fileInsert"]="Mostrar en la descripción";
		self::$trad["EDIT_fileInsertInfo"]="Mostrar la imagen / video / mp3... en la descripción anterior. La inserción se realiza después de la validación del formulario.";
		self::$trad["EDIT_demandToConfirm"]="Su solicitud ha sido registrada. Se confirmó pronto.";
		
		////	Formulaire d'installation
		self::$trad["INSTALL_dbConnect"]="Conexión a la base de datos";
		self::$trad["INSTALL_dbHost"]="Nombre del servidor host (hostname)";
		self::$trad["INSTALL_dbName"]="Nombre de la base de datos";
		self::$trad["INSTALL_dbLogin"]="Nombre de Usuario";
		self::$trad["INSTALL_adminAgora"]="Administrador del Ágora";
		self::$trad["INSTALL_errorConnectSGBD"]="No hay conexión con la base de datos MySQL";
		self::$trad["INSTALL_errorConnectIdentification"]="No identificación con la base de datos MySQL";
		self::$trad["INSTALL_errorAppliInstalled"]="La instalación ya se ha realizado en esta base de datos. Gracias simplemente eliminar la base de datos si se debe reiniciar la instalación.";
		self::$trad["INSTALL_errorConnectDbConfirmInstall"]="La conexión a la base de datos no se ha establecido, confirmar ?";
		self::$trad["INSTALL_PhpOldVersion"]="Agora-Project requiere una versión más reciente de PHP";
		self::$trad["INSTALL_confirmInstall"]="Confirmar instalación ?";
		self::$trad["INSTALL_installOk"]="Agora-Project ha sido instalado !";
		self::$trad["INSTALL_spaceDescription"]="Espacio para el intercambio y el trabajo colaborativo";

		////	MODULE_PARAMETRAGE
		////
		self::$trad["AGORA_headerModuleName"]="Administración general";
		self::$trad["AGORA_generalSettings"]="Administración general";
		self::$trad["AGORA_backupFull"]="Copia de seguridad de la base de datos y los archivos";
		self::$trad["AGORA_backupNotif"]="La creación de la copia de seguridad puede tardar unos minutos ... y descargar una docena de minutos.";
		self::$trad["AGORA_backupDb"]="Copia de seguridad de la base de datos";
		self::$trad["AGORA_diskSpaceInvalid"]="El límite de espacio de disco debe ser un número entero";
		self::$trad["AGORA_confirmModif"]="Confirmar los cambios ?";
		self::$trad["AGORA_name"]="Nombre del sitio";
		self::$trad["AGORA_footerHtml"]="Footer / Pie de página html";
		self::$trad["AGORA_footerHtmlInfo"]="Para incluir herramientas estadísticas, por ejemplo";
		self::$trad["AGORA_lang"]="Lenguaje por defecto";
		self::$trad["AGORA_timezone"]="Zona horaria";
		self::$trad["AGORA_spaceName"]="Nombre del espacio principal";
		self::$trad["AGORA_diskSpaceLimit"]="Espacio de disco disponible para los archivos";
		self::$trad["AGORA_logsTimeOut"]="Periodo de validez de los Logs";
		self::$trad["AGORA_skin"]="Color de la interfaz";
		self::$trad["AGORA_black"]="Negro";
		self::$trad["AGORA_white"]="Blanco";
		self::$trad["AGORA_wallpaperLogoError"]="La imagen de fondo y el logotipo debe tener el formato .jpg ou .png";
		self::$trad["AGORA_deleteWallpaper"]="Eliminar la imagen de fondo ?";
		self::$trad["AGORA_logo"]="Logotipo en pie de página";
		self::$trad["AGORA_logoUrl"]="URL";
		self::$trad["AGORA_logoConnect"]="logo / Imagen de la página de conexión";
		self::$trad["AGORA_logoConnectInfo"]="Desplegado encima del formulario de conexión";
		self::$trad["AGORA_messengerDisabled"]="Mensajería instantánea activada";
		self::$trad["AGORA_personalCalendarsDisabled"]="Calendarios personales habilitadas por defecto";
		self::$trad["AGORA_personalCalendarsDisabled_infos"]="Agregar un calendario personal en la creación de un usuario. El calendario puede ser desactivado más tarde, cuando se cambia el perfil de usuario.";
		self::$trad["AGORA_moduleLabelDisplay"]="Nombre de los módulos en la barra de menú";
		self::$trad["AGORA_personsSort"]="Ordenar los usuarios y contactos";
		self::$trad["AGORA_versions"]="Versiones";
		self::$trad["AGORA_dateUpdate"]="actualización el";
		self::$trad["AGORA_funcMailDisabled"]="Función de PHP para enviar correos electrónicos : desactivada !";
		self::$trad["AGORA_funcMailInfo"]="Algunos ''Host'' desactivan la función PHP para enviar correos electrónicos, por razones de seguridad ou saturación de los servidores (SPAM)";
		self::$trad["AGORA_funcImgDisabled"]="Función de la manipulación de imágenes y miniaturas (PHP GD2) : desactivada !";
		//SMTP
		self::$trad["AGORA_smtpLabel"]="Conexión SMTP & sendMail";
		self::$trad["AGORA_sendmailFrom"]="Mail en el campo 'From'";
		self::$trad["AGORA_sendmailFromPlaceholder"]="ex: 'mi-dominio.es'";
		self::$trad["AGORA_smtpHost"]="Dirección del servidor (hostname)";
		self::$trad["AGORA_smtpPort"]="Puerto de servidor";
		self::$trad["AGORA_smtpPortInfo"]="'25' por defecto. '587' o '465' para SSL/TLS";
		self::$trad["AGORA_smtpSecure"]="Tipo de conexión cifrada (opcional)";
		self::$trad["AGORA_smtpSecureInfo"]="'ssl' o 'tls'";
		self::$trad["AGORA_smtpUsername"]="Nombre del usuario";
		self::$trad["AGORA_smtpPass"]="Contraseña";
		//LDAP
		self::$trad["AGORA_ldapLabel"]="Conexión a un servidor LDAP";
		self::$trad["AGORA_ldapHost"]="Dirección del servidor";
		self::$trad["AGORA_ldapPort"]="Puerto de servidor";
		self::$trad["AGORA_ldapPortInfo"]="''389'' por defecto";
		self::$trad["AGORA_ldapLogin"]="Cadena de conexión para admin";
		self::$trad["AGORA_ldapLoginInfo"]="por ejemplo ''uid=admin,ou=my_company''";
		self::$trad["AGORA_ldapPass"]="Contraseña del administrador";
		self::$trad["AGORA_ldapDn"]="Grupo / base DN";
		self::$trad["AGORA_ldapDnInfo"]="Localización de los usuarios del directorio.<br> por ejemplo ''ou=users,o=my_company''";
		self::$trad["AGORA_ldapConnectError"]="Error al conectar con el servidor LDAP !";
		self::$trad["AGORA_ldapCreaAutoUsers"]="Auto creación de usuarios después identificación";
		self::$trad["AGORA_ldapCreaAutoUsersInfo"]="Creación automática de un usuario si no está en el Agora, pero presente en el servidor LDAP : se le asignará a las áreas accesibles a ''todos los usuarios del sitio''.<br>De lo contrario, el usuario no se creará.";
		self::$trad["AGORA_ldapPassEncrypt"]="Contraseñas cifrado en el servidor";
		self::$trad["AGORA_ldapDisabled"]="Módulo PHP para la conexión a un servidor LDAP no está instalado";

		////	MODULE_LOG
		////
		self::$trad["LOG_headerModuleName"]="Logs";
		self::$trad["LOG_moduleDescription"]="Logs - Registro de eventos";
		self::$trad["LOG_filter"]="filtro";
		self::$trad["LOG_date"]="Fecha / Hora";
		self::$trad["LOG_spaceName"]="Espacio";
		self::$trad["LOG_moduleName"]="Módulo";
		self::$trad["LOG_objectType"]="typo de objeto";
		self::$trad["LOG_action"]="Acción";
		self::$trad["LOG_userName"]="Usuario";
		self::$trad["LOG_ip"]="IP";
		self::$trad["LOG_comment"]="Comentario";
		self::$trad["LOG_noLogs"]="Ningún registro";
		self::$trad["LOG_filterSince"]="filtrado de la";
		self::$trad["LOG_search"]="Buscar";
		self::$trad["LOG_connexion"]="Conexión";//action
		self::$trad["LOG_deconnexion"]="logout";//action
		self::$trad["LOG_consult"]="consulta";//action
		self::$trad["LOG_consult2"]="descarga";//action
		self::$trad["LOG_add"]="Añadir";//action
		self::$trad["LOG_delete"]="eliminar";//action
		self::$trad["LOG_modif"]="cambio";//action

		////	MODULE_ESPACE
		////
		self::$trad["SPACE_headerModuleName"]="Espacios";
		self::$trad["SPACE_moduleInfo"]="El sitio (o el espacio principal) puede ser subdivisado en varios espacios";
		self::$trad["SPACE_manageSpaces"]="Gestión de los spacios del sitio";
		self::$trad["SPACE_config"]="Administración del espacio";
		// Index
		self::$trad["SPACE_confirmDeleteDbl"]="Confirmar eliminación ? Atención, los datos afectados a este espacio seran  definitivamente perdidas !!";
		self::$trad["SPACE_space"]="Espacio";
		self::$trad["SPACE_spaces"]="Espacios";
		self::$trad["SPACE_accessRightUndefined"]="Definir !";
		self::$trad["SPACE_modules"]="Módulos";
		self::$trad["SPACE_addSpace"]="Añadir un espacio";
		//Edit
		self::$trad["SPACE_usersAccess"]="Usuarios asignados al espacio";
		self::$trad["SPACE_selectModule"]="Debe seleccionar al menos un módulo";
		self::$trad["SPACE_spaceModules"]="Módulos del espacio";
		self::$trad["SPACE_moduleRank"]="Mover a establecer el orden de presentación de los módulos";
		self::$trad["SPACE_publicSpace"]="Espacio Público";
		self::$trad["SPACE_publicInfo"]="Proporciona acceso a las personas que no tienen cuentas en el sitio : invitados. Capacidad de especificar una contraseña para proteger el acceso.";
		self::$trad["SPACE_usersInvitation"]="Los usuarios pueden enviar invitaciones por correo";
		self::$trad["SPACE_usersInvitationInfo"]="Todos los usuarios pueden enviar invitaciones por correo electrónico para unirse al espacio";
		self::$trad["SPACE_allUsers"]="Todos los usuarios";
		self::$trad["SPACE_user"]=" Usuarios";
		self::$trad["SPACE_userInfo"]="Usuario del espacio : <br> Acceso normal al espacio";
		self::$trad["SPACE_admin"]="Administrador";
		self::$trad["SPACE_adminInfo"]="Administrador del espacio : ecceso en escritura a todos los elementos del espacio + posibilidad de enviar invitaciones por correo electrónico + añadir nuevos usuarios";
		self::$trad["SPACE_createSpaceCalendar"]="Crear un calendario compartido para el espacio";
		self::$trad["SPACE_createSpaceCalendarInfo"]="El calendario tendrá el mismo nombre que el espacio. Puede ser útil si los calendarios de los usuarios están desactivados.";

		////	MODULE_UTILISATEUR
		////
		// Menu principal
		self::$trad["USER_headerModuleName"]="Usuarios";
		self::$trad["USER_moduleDescription"]="Usuarios del espacio";
		self::$trad["USER_ajout_utilisateurs_groupe"]="Los usuarios también pueden crear grupos";
		//Index
		self::$trad["USER_allUsers"]="Usuarios del sitio";
		self::$trad["USER_allUsersManage"]="Gestión de todos los usuarios";
		self::$trad["USER_allUsersInfo"]="Todos los usuarios del sitio : todas las áreas combinadas";
		self::$trad["USER_spaceUsers"]="Usuarios del espacio";
		self::$trad["USER_confirmDeleteFromSpace"]="Confirmar la desasignación del usuario al espacio corriente ?";
		self::$trad["USER_deleteDefinitely"]="Eliminar definitivamente";
		self::$trad["USER_deleteFromSpace"]="Desasignar del espacio";
		self::$trad["USER_allUsersOnSpaceNotif"]="Todo los usuarios del sitio son asignados a este espacio : no es possible desasignar";
		self::$trad["USER_user"]="Usuario";
		self::$trad["USER_users"]="usuarios";
		self::$trad["USER_addExistUser"]="Añadir un usuario existente, a ese espacio";
		self::$trad["USER_addUser"]="Añadir un usuario";
		self::$trad["USER_addUserSite"]="Crear un usuario en el sitio : por defecto, asignado a ningun espacio !";
		self::$trad["USER_addUserSpace"]="Crear un usuario en el espacio actual";
		self::$trad["USER_sendCoords"]="Enviar el nombre de usuario y contraseña";
		self::$trad["USER_sendCoordsInfo"]="Enviar a usuarios (por correo electronico) sus nombre de usuario<br> y una nueva contraseña";
		self::$trad["USER_sendCoordsInfo2"]="Enviar a cada nuevo usuario <br> un correo electrónico con información de acceso.";
		self::$trad["USER_sendCoordsConfirm"]="Confirmar ?";
		self::$trad["USER_sendCoordsMail"]="Sus datos de acceso a su espacio";
		self::$trad["USER_loginResetPassword"]="Haga clic aquí para acceder a su espacio y reinicializar su contraseña";
		self::$trad["USER_noUser"]="Ningún usuario asignado a este espacio por el momento";
		self::$trad["USER_lastConnection"]="Última conexión";
		self::$trad["USER_spaceList"]="Espacios del usuario";
		self::$trad["USER_spaceNoAffectation"]="Ningún espacio";
		self::$trad["USER_adminGeneral"]="Administrador General del Sitio";
		self::$trad["USER_adminSpace"]="Administrador del espacio";
		self::$trad["USER_userSpace"]="Usuario del espacio";
		self::$trad["USER_notConnectedYet"]="No está conectado";
		self::$trad["USER_modify"]="Editar usuario";
		self::$trad["USER_modifyProfil"]="Editar mi perfil";
		// Invitation
		self::$trad["USER_sendInvitation"]="Invitar alguien a unirse al espacio";
		self::$trad["USER_sendInvitationInfo"]="La invitacion sera enviada por correo electronico";
		self::$trad["USER_mailInvitationObject"]="Invitación de "; // ..Jean DUPOND
		self::$trad["USER_mailInvitationFromSpace"]="le invita a "; // Jean DUPOND "vous invite à rejoindre l'espace" Mon Espace
		self::$trad["USER_mailInvitationConfirm"]="Haga clic aquí para confirmar la invitación";
		self::$trad["USER_mailInvitationWait"]="Invitaciones a confirmar";
		self::$trad["USER_exired_idInvitation"]="La enlace de su invitación ha caducado";
		self::$trad["USER_invitationConfirmPassword"]="Elija su contraseña y clic 'OK' para confirmar su invitación";
		self::$trad["USER_invitationValidated"]="Su invitación ha sido validado !";
		// groupes
		self::$trad["USER_spaceGroups"]="grupos de usuarios del espacio";
		self::$trad["USER_userGroups"]="modificar los grupos de usuarios";
		self::$trad["USER_groupEditInfo"]="Cada grupo puede ser modificado por su autor o por el administrador general";
		// Utilisateur_affecter
		self::$trad["USER_searchPrecision"]="Gracias a especificar un nombre, un apellido o una dirección de correo electrónico";
		self::$trad["USER_userAffectConfirm"]="Confirmar las asignaciónes ?";
		self::$trad["USER_userSearch"]="Buscar usuarios para añadirlo al espacio";
		self::$trad["USER_allUsersOnSpace"]="Todos los usuarios del sitio ya están asignados a este espacio";
		self::$trad["USER_usersSpaceAffectation"]="Asignar usuarios al espacio :";
		self::$trad["USER_usersSearchNoResult"]="No hay usuarios para esta búsqueda";
		// Utilisateur_edit & CO
		self::$trad["USER_specifyName"]="Gracias especificar un appelido";
		self::$trad["USER_specifyFirstName"]="Gracias especificar un nombre";
		self::$trad["USER_specifyLogin"]="Gracias especificar un identificador";
		self::$trad["USER_specifyPassword"]="Gracias especificar una contraseña";
		self::$trad["USER_specifyMailAsLogin"]="Se recomienda utilizar un email como identificador de sesión. ¿Todavía validar el formulario?";
		self::$trad["USER_langs"]="Idioma";
		self::$trad["USER_persoCalendarDisabled"]="Calendario personal desactivado";
		self::$trad["USER_persoCalendarDisabledInfo"]="Por defecto, el calendar personal esta siempre accessible al usuario, incluso si el módulo Agenda del espacio no está activado";
		self::$trad["USER_connectionSpace"]="Espacio de conexión";
		self::$trad["USER_creaNotifMail"]="Enviar una notificación por e-mail de la creación";
		self::$trad["USER_notifSpecifyMail"]="Gracias especificar una dirección de correo electrónico !";
		self::$trad["USER_ipAdress"]="Direcciónes IP de control";
		self::$trad["USER_ipAdressInfo"]="Si se especifica una (o más) direcciones IP, el usuario sólo podra conectarse si utiliza las direcciones IP especificadas";
		self::$trad["USER_loginPresentYet"]="El identificador especificado ya existe. ¡ Gracias a especificar otro !";
		self::$trad["USER_mailPresentYet"]="El email ya existe. ¡ Gracias a especificar otro !";
		self::$trad["USER_mailNotifObject"]="Nueva cuenta en ";  // "...sur" l'Agora machintruc
		self::$trad["USER_mailNotifContent"]="Su cuenta de usuario ha sido creada en";  // idem
		self::$trad["USER_mailNotifContent2"]="Conectar con el login y la contraseña siguientes";
		self::$trad["USER_mailNotifContent3"]="Gracias a mantener este correo electrónico para sus archivos.";
		// Utilisateur_Messenger
		self::$trad["USER_editMessenger"]="Gestión de mensajería instantánea";
		self::$trad["USER_editMyMessenger"]="Gestión de mi mensajería instantánea";
		self::$trad["USER_livecounterVisibility"]="Usuarios que podran verme en línea y hablar en la mensajería instantánea";
		self::$trad["USER_livecounterNobody"]="No hay usuarios por el momento";
		self::$trad["USER_livecounterDisabled"]="Mensajería desactivado (todos los usuarios no pueden verme)";
		self::$trad["USER_livecounterAllUsers"]="Todos los usuarios pueden verme";
		self::$trad["USER_livecounterSomeUsers"]="Algunos usuarios pueden verme";

		////	MODULE_TABLEAU BORD
		////
		// Menu principal + options du module
		self::$trad["DASHBOARD_headerModuleName"]="Noticias";
		self::$trad["DASHBOARD_moduleDescription"]="Noticias y novedades";
		self::$trad["DASHBOARD_ajout_actualite_admin"]="Sólo el administrador puede Añadir noticias";
		//Index
		self::$trad["DASHBOARD_newElems"]="novedades";
		self::$trad["DASHBOARD_newElemsInfo"]="Elementos creados entre <br>";
		self::$trad["DASHBOARD_currentElems"]="corrientes";
		self::$trad["DASHBOARD_currentElemsInfo"]="Eventos y tareas que tienen lugar entre <br>";
		self::$trad["DASHBOARD_pluginSinceConnection"]="desde mi última conexión";
		self::$trad["DASHBOARD_pluginOfDay"]="Hoy";
		self::$trad["DASHBOARD_pluginOfWeek"]="esta semana";
		self::$trad["DASHBOARD_pluginOfMonth"]="este mes";
		self::$trad["DASHBOARD_pluginOtherPeriod"]="otro período";
		self::$trad["DASHBOARD_pluginEmpty"]="No hay elementos para el periodo seleccionado";
		self::$trad["DASHBOARD_addNews"]="Añadir una noticia";
		self::$trad["DASHBOARD_newsOffline"]="Noticias archivadas";
		self::$trad["DASHBOARD_noNews"]="No hay noticias";
		// Actualite_edit
		self::$trad["DASHBOARD_topNews"]="Noticia importante";
		self::$trad["DASHBOARD_topNewsInfo"]="Noticia importante, en la parte superior de la lista";
		self::$trad["DASHBOARD_offline"]="Archivado";
		self::$trad["DASHBOARD_offlineInfo"]="Archive esta noticia (Offline)";
		self::$trad["DASHBOARD_dateOnline"]="En línea el";
		self::$trad["DASHBOARD_dateOnlineInfo"]="Establecer una fecha de línea automático (en línea). La noticia será 'archivada' 'en el ínterin";
		self::$trad["DASHBOARD_dateOnlineNotif"]="La noticia esta archivado en la expectativa de su línea automática";
		self::$trad["DASHBOARD_dateOffline"]="Archivar el";
		self::$trad["DASHBOARD_dateOfflineInfo"]="Fije una fecha de archivo automático (Desconectado)";

		////	MODULE_AGENDA
		////
		// Menu principal
		self::$trad["CALENDAR_headerModuleName"]="Calendarios";
		self::$trad["CALENDAR_moduleDescription"]="Calendarios personal y calendarios compartidos";
		self::$trad["CALENDAR_ajout_agenda_ressource_admin"]="Sólo el administrador puede añadir calendarios de recursos";
		self::$trad["CALENDAR_ajout_categorie_admin"]="Sólo el administrador puede añadir categorías de eventos";
		//Index
		self::$trad["CALENDAR_displayAllCals"]="Ver todo los calendarios";
		self::$trad["CALENDAR_hideAllCals"]="Ocultar todo los calendarios";
		self::$trad["CALENDAR_printCalendars"]="Imprimir el/los calendarios";
		self::$trad["CALENDAR_printCalendarsInfos"]="imprimir la página en modo horizontal";
		self::$trad["CALENDAR_addSharedCalendar"]="Añadir un calendario compartido";
		self::$trad["CALENDAR_addSharedCalendarInfo"]="Añadir un calendario compartido : para reservar une habitación, vehiculo, vídeo, etc.";
		self::$trad["CALENDAR_exportIcal"]="Exportar los eventos (iCal)";
		self::$trad["CALENDAR_exportEvtMail"]="Exportar los eventos por e-mail (iCal)";
		self::$trad["CALENDAR_exportEvtMailInfo"]="Para integrar en un calendario IPHONE, ANDROID, OUTLOOK, GOOGLE CALENDAR...";
		self::$trad["CALENDAR_exportEvtMailList"]="lista de los eventos .ical";
		self::$trad["CALENDAR_importIcal"]="Importar los eventos (iCal)";
		self::$trad["CALENDAR_importIcalState"]="Estado";
		self::$trad["CALENDAR_importIcalStatePresent"]="Ya está presente";
		self::$trad["CALENDAR_importIcalStateImport"]="a importar";
		self::$trad["CALENDAR_addEvtHour"]="Añadir un evento a";
		self::$trad["CALENDAR_addEvtDay"]="Añadir un evento a esa fecha";
		self::$trad["CALENDAR_displayDay"]="Día";
		self::$trad["CALENDAR_display3Days"]="3 días";
		self::$trad["CALENDAR_displayWorkWeek"]="Semana de trabajo";
		self::$trad["CALENDAR_displayWeek"]="Semana";
		self::$trad["CALENDAR_displayMonth"]="Mes";
		self::$trad["CALENDAR_weekNb"]="Ver la semana n°"; //...5
		self::$trad["CALENDAR_periodNext"]="Período siguiente";
		self::$trad["CALENDAR_periodPrevious"]="Período anterior";
		self::$trad["CALENDAR_evtAffects"]="En el calendario de";
		self::$trad["CALENDAR_evtAffectToConfirm"]="Pendiente de confirmación : ";
		self::$trad["CALENDAR_evtProposedFor"]="Eventos propuestos para"; // "Videoprojecteur" / "salle de réunion" / etc.
		self::$trad["CALENDAR_evtProposedForMe"]="Eventos propuestos para mi calendario";
		self::$trad["CALENDAR_evtProposedBy"]="Propuestos por";  // "Proposé par" M. Bidule
		self::$trad["CALENDAR_evtIntegrate"]="Integrar el evento al calendario ?";
		self::$trad["CALENDAR_evtNotIntegrate"]="Eliminar el evento propuesto ?";
		self::$trad["CALENDAR_deleteEvtCal"]="Eliminar sólo en ese calendario ?";
		self::$trad["CALENDAR_deleteEvtCals"]="Eliminar en todos los calendarios ?";
		self::$trad["CALENDAR_deleteEvtDate"]="Eliminar sólo en esta fecha ?";
		self::$trad["CALENDAR_evtPrivate"]="Évento privado";
		self::$trad["CALENDAR_evtAutor"]="Eventos que he creado";
		self::$trad["CALENDAR_noEvt"]="No hay eventos";
		self::$trad["CALENDAR_propose"]="Envíar un evento";
		self::$trad["CALENDAR_synthese"]="Síntesis de los calendarios";
		self::$trad["CALENDAR_calendarsPercentBusy"]="Calendarios ocupados";  // Agendas occupés : 2/5
		self::$trad["CALENDAR_noCalendarDisplayed"]="No calendario";
		// Evenement
		self::$trad["CALENDAR_category"]="Categoría";
		self::$trad["CALENDAR_visibilityPublic"]="Visibilidad normal";
		self::$trad["CALENDAR_visibilityPublicHide"]="Visibilidad semi-privada";
		self::$trad["CALENDAR_visibilityPrivate"]="Visibilidad privada";
		self::$trad["CALENDAR_visibilityInfo"]="<u>Visibilidad semi-privada</u> : solo muestrar el período del evento (sin los detailles) si el evento es accesible en lectura.<br><br><u>Visibilidad privada</u> : visible sólo si el evento es accesible en escritura.";
		//  Agenda_edit
		self::$trad["CALENDAR_timeSlot"]="Banda horaria";
		// Evenement_edit
		self::$trad["CALENDAR_noPeriodicity"]="Evento puntual";
		self::$trad["CALENDAR_period_weekDay"]="Cada semana";
		self::$trad["CALENDAR_period_monthDay"]="Dia del mes";
		self::$trad["CALENDAR_period_month"]="Cada mes";
		self::$trad["CALENDAR_period_dayOfMonth"]="del mes"; // Le 21 du mois
		self::$trad["CALENDAR_period_year"]="Cada año";
		self::$trad["CALENDAR_periodDateEnd"]="Fin de periodicidad";
		self::$trad["CALENDAR_periodException"]="Excepción de periodicidad";
		self::$trad["CALENDAR_calendarAffectations"]="Asignación a los calendarios";
		self::$trad["CALENDAR_verifCalNb"]="Gracias por seleccionar por lo menos un calendario";
		self::$trad["CALENDAR_inputPropose"]="Proponer el evento al propietario del calendario";
		self::$trad["CALENDAR_inputProposed"]="El evento será propuesto al propietario del calendario";
		self::$trad["CALENDAR_inputAffect"]="Añadir el evento al calendario";
		self::$trad["CALENDAR_proposeInfo"]="Proponer el evento (no tiene acceso de escritura a este calendario)";
		self::$trad["CALENDAR_noModifInfo"]="Edición prohibida porque no tiene acceso de escritura al calendario";
		self::$trad["CALENDAR_editLimit"]="Usted no es el autor de el evento : sólo puedes editar las asignaciones a sus calendarios";
		self::$trad["CALENDAR_busyTimeslot"]="La ranura ya está ocupado en este calendario :";
		// Categories
		self::$trad["CALENDAR_editCategories"]="Administrar las categorías de eventos";
		self::$trad["CALENDAR_editCategoriesRight"]="Cada categoría puede ser modificado por su autor o por el administrador general";

		////	MODULE_FICHIER
		////
		// Menu principal
		self::$trad["FILE_headerModuleName"]="Archivos";
		self::$trad["FILE_moduleDescription"]="Administración de Archivos";
		self::$trad["FILE_AdminRootFolderAddContent"]="Sólo el administrador puede añadir elementos en el directorio raíz";
		//Index
		self::$trad["FILE_ajouter_fichier"]="Añadir archivos";
		self::$trad["FILE_ajouter_fichier_alert"]="Los directorios del servidor no son accesible en escritura !  gracias de contactar el administrador";
		self::$trad["FILE_telecharger_selection"]="Descargar selección";
		self::$trad["FILE_nb_versions_fichier"]="Archivo versiones"; // n versions du fichier
		self::$trad["FILE_ajouter_versions_fichier"]="Añadir nueva versión del archivo";
		self::$trad["FILE_aucun_fichier"]="No hay archivo en este momento";
		// fichier_edit_ajouter  &  Fichier_edit
		self::$trad["FILE_fileSizeLimit"]="Los archivos no deben exceder"; // ...2 Mega Octets
		self::$trad["FILE_optimiser_images"]="Limite el tamaño a "; // ..1024*768 pixels
		self::$trad["FILE_updatedName"]="El nombre del archivo será reemplazado por la nueva versión";
		self::$trad["FILE_erreur_taille_fichier"]="Archivo demasiado grande";
		self::$trad["FILE_ajout_multiple_info"]="Pulse 'Maj' o 'Ctrl' para seleccionar varios archivos";
		self::$trad["FILE_selectionner_fichier"]="Gracias por elegir al menos un archivo";
		self::$trad["FILE_contenu"]="contenido";
		// Versions_fichier
		self::$trad["FILE_versions_de"]="Versiones de"; // versions de fichier.gif
		self::$trad["FILE_confirmer_suppression_version"]="Confirme la eliminación de esta versión ?";

		////	MODULE_FORUM
		////
		// Menu principal
		self::$trad["FORUM_headerModuleName"]="Foro";
		self::$trad["FORUM_moduleDescription"]="Foro";
		self::$trad["FORUM_ajout_sujet_admin"]="Sólo el administrador puede añadir sujetos";
		self::$trad["FORUM_ajout_sujet_theme"]="Los usuarios también pueden añadir temas";
		// TRI
		self::$trad["SORT_dateLastMessage"]="último mensaje";
		//Index & Sujet
		self::$trad["FORUM_sujet"]="sujeto";
		self::$trad["FORUM_sujets"]="sujetos";
		self::$trad["FORUM_message"]="mensaje";
		self::$trad["FORUM_messages"]="mensajes";
		self::$trad["FORUM_lastPost"]="último";
		self::$trad["FORUM_ajouter_sujet"]="añadir un sujeto";
		self::$trad["FORUM_voir_sujet"]="Ver el sujeto";
		self::$trad["FORUM_ajouter_message"]="añadir un mensaje";
		self::$trad["FORUM_quoteMessage"]="Responder y citar a ese mensaje";
		self::$trad["FORUM_noSubject"]="No sujeto por el momento";
		self::$trad["FORUM_noMessage"]="No mensaje";
		self::$trad["FORUM_notifyLastPost"]="Notificar por e-mail";
		self::$trad["FORUM_notifyLastPostInfo"]="Deseo recibir una notificación por correo a cada nuevo mensaje";
		// Sujet_edit  &  Message_edit
		self::$trad["FORUM_accessRightInfos"]="Para participar al sujeto, debe tener al minimo un ''acceso limitado de escritura''";
		self::$trad["FORUM_theme_espaces"]="El tema está disponible en los espacios";
		// Themes
		self::$trad["FORUM_theme_sujet"]="Temas";
		self::$trad["FORUM_accueil_forum"]="Index del foro";
		self::$trad["FORUM_sans_theme"]="Sin tema";
		self::$trad["FORUM_themes_gestion"]="Gestión de los temas";
		self::$trad["FORUM_droit_gestion_themes"]="Cada tema puede ser modificado por su autor o por el administrador general";

		////	MODULE_TACHE
		////
		// Menu principal
		self::$trad["TASK_headerModuleName"]="Tareas";
		self::$trad["TASK_moduleDescription"]="Tareas";
		self::$trad["TASK_AdminRootFolderAddContent"]="Sólo el administrador puede añadir elementos en el directorio raíz";
		// TRI
		self::$trad["SORT_priority"]="Prioridad";
		self::$trad["SORT_advancement"]="Progreso";
		self::$trad["SORT_dateBegin"]="Fecha de inicio";
		self::$trad["SORT_dateEnd"]="Fecha de fin";
		//Index
		self::$trad["TASK_ajouter_tache"]="Añadir una tareas";
		self::$trad["TASK_aucune_tache"]="No hay tarea por el momento";
		self::$trad["TASK_advancement"]="Progreso";
		self::$trad["TASK_advancementAverage"]="Progreso promedio";
		self::$trad["TASK_priority"]="Prioridad";
		self::$trad["TASK_priority1"]="Baja";
		self::$trad["TASK_priority2"]="promedia";
		self::$trad["TASK_priority3"]="alta";
		self::$trad["TASK_priority4"]="Crítica";
		self::$trad["TASK_responsiblePersons"]="Responsables";
		self::$trad["TASK_budgetAvailable"]="Presupuesto disponible";
		self::$trad["TASK_budgetAvailable_total"]="Presupuesto disponible total";
		self::$trad["TASK_budgetEngaged"]="Presupuesto comprometido";
		self::$trad["TASK_budgetEngaged_total"]="Presupuesto comprometido total";
		self::$trad["TASK_humanDayCharge"]="Carga dia/hombre";
		self::$trad["TASK_humanDayCharge_info"]="Número de días de trabajo necesarios para una persona para realizar esta tarea";
		self::$trad["TASK_advancement_retard"]="Progreso retrasado";
		self::$trad["TASK_budgetExceeded"]="Presupuesto excedido";

		////	MODULE_CONTACT
		////
		// Menu principal
		self::$trad["CONTACT_headerModuleName"]="Contactos";
		self::$trad["CONTACT_moduleDescription"]="Directorio de contactos";
		self::$trad["CONTACT_AdminRootFolderAddContent"]="Sólo el administrador puede añadir elementos en el directorio raíz";
		//Index
		self::$trad["CONTACT_ajouter_contact"]="Añadir un contacto";
		self::$trad["CONTACT_aucun_contact"]="No hay contacto todavía";
		self::$trad["CONTACT_creer_user"]="Crear un usuario en este espacio";
		self::$trad["CONTACT_creer_user_infos"]="Crear un usuario en este espacio con este contacto ?";
		self::$trad["CONTACT_creer_user_confirm"]="El usuario fue creado";

		////	MODULE_LIEN
		////
		// Menu principal
		self::$trad["LINK_headerModuleName"]="Favoritos";
		self::$trad["LINK_moduleDescription"]="Favoritos";
		self::$trad["LINK_AdminRootFolderAddContent"]="Sólo el administrador puede añadir elementos en el directorio raíz";
		//Index
		self::$trad["LINK_ajouter_lien"]="Añadir un enlace";
		self::$trad["LINK_aucun_lien"]="No hay enlaces por el momento";
		// lien_edit & dossier_edit
		self::$trad["LINK_adress"]="Dirección web";

		////	MODULE_MAIL
		////
		// Menu principal
		self::$trad["MAIL_headerModuleName"]="Mailing";
		self::$trad["MAIL_moduleDescription"]="Enviar mensajes de correo electrónico con un solo clic !";
		//Index
		self::$trad["MAIL_specifier_mail"]="Gracias especificar al menos un destinatario";
		self::$trad["MAIL_title"]="Título del correo electrónico";
		self::$trad["MAIL_fichier_joint"]="Archivo adjunto";
		// Historique Mail
		self::$trad["MAIL_historique_mail"]="Historia de los correos electrónicos enviados";
		self::$trad["MAIL_aucun_mail"]="No correo electrónico";
		self::$trad["MAIL_recipients"]="Destinatarios";
	}

	/*
	 * Jours Fériés de l'année
	 */
	public static function celebrationDays($year)
	{
		// Init
		$dateList=array();

		//Fêtes mobiles (si la fonction de récup' de paques existe)
		if(function_exists("easter_date"))
		{
			$daySecondes=86400;
			$paquesTime=easter_date($year);
			$date=date("Y-m-d", $paquesTime+$daySecondes);
			$dateList[$date]="Lunes de Pascua";
		}

		//Fêtes fixes	$dateList[$year."-01-01"]="Día de Año Nuevo";
		$dateList[$year."-01-06"]="Epifanía";
		$dateList[$year."-05-01"]="Día del Trabajo";
		$dateList[$year."-08-15"]="Asunción";
		$dateList[$year."-10-12"]="Día de la Hispanidad";
		$dateList[$year."-11-01"]="Toussaint";
		$dateList[$year."-12-06"]="Día de la Constitución";
		$dateList[$year."-12-08"]="Inmaculada Concepción";
		$dateList[$year."-12-25"]="Navidad";

		//Retourne le résultat
		return $dateList;
	}
}