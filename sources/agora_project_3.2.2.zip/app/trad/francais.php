<?php
/*
 * Classe de gestion d'une langue
 */
class Trad extends Txt
{
	/*
	 * Chargement les éléments de traduction
	 */
	public static function loadTradsLang()
	{
		////	Langue courante / Header http / Editeurs Tinymce,DatePicker,etc / Dates formatées par PHP
		self::$trad["CURLANG"]="fr";
		self::$trad["HEADER_HTTP"]="fr";
		self::$trad["DATEPICKER"]="fr";
		self::$trad["HTML_EDITOR"]="fr_FR";
		self::$trad["UPLOADER"]="fr";
		setlocale(LC_TIME, "fr_FR.utf8", "fr_FR.UTF-8", "fr_FR", "fr", "french");

		////	Divers
		self::$trad["OK"]="OK";
		self::$trad["fillAllFields"]="Merci de remplir tous les champs";
		self::$trad["inaccessibleElem"]="Element inaccessible";
		self::$trad["warning"]="Attention";
		self::$trad["elemEditedByAnotherUser"]="L'élément est en cours d'edition par";//"..bob"
		self::$trad["requiredFields"]="Champ obligatoire";
		self::$trad["yes"]="oui";
		self::$trad["no"]="non";
		self::$trad["none"]="aucun";
		self::$trad["and"]="et";
		self::$trad["goToPage"]="Aller à la page";
		self::$trad["alphabetFilter"]="Filtre alphabétique";
		self::$trad["displayAll"]="Tout afficher";
		self::$trad["anyCategory"]="Toute categorie";
		self::$trad["important"]="Important";
		self::$trad["show"]="afficher";
		self::$trad["hide"]="masquer";
		self::$trad["keep"]="Garder";
		self::$trad["byDefault"]="Par défaut";
		self::$trad["mapLocalize"]="Localiser sur une carte";
		self::$trad["mailInvalid"]="L'e-mail n'est pas valide";
		self::$trad["element"]="élément";
		self::$trad["elements"]="éléments";
		self::$trad["folder"]="dossier";
		self::$trad["folders"]="dossiers";
		self::$trad["close"]="Fermer";
		self::$trad["visibleSpaces"]="Espaces où il sera visible";
		self::$trad["visibleAllSpaces"]="Visible sur tous les espaces";
		self::$trad["confirmCloseLightbox"]="Fermer le formulaire ?";
		self::$trad["modifRecorded"]="Les modifications ont été enregistrées";

		////	Menu/Menu contextuel
		self::$trad["objNew"]="Nouvel élément";
		self::$trad["objNewInfos"]="Nouvel élément :<br>créé depuis ma précédente connexion ou créé dans les 24 heures";
		self::$trad["personalAccess"]="Accès personnel";

		////	images
		self::$trad["picture"]="Photo";
		self::$trad["wallpaper"]="Fond d'écran";
		self::$trad["imgChange"]="changer";
		self::$trad["pixels"]="pixels";

		////	Connexion
		self::$trad["SpecifyLoginPassword"]="Merci de spécifier un identifiant et un mot de passe";
		self::$trad["login"]="Email / Identifiant";//d'une manière plus generale => nom d'utilisateur OU email
		self::$trad["login2"]="Email / Identifiant de connexion";//d'une manière plus generale => nom d'utilisateur OU email
		self::$trad["placeholderLogin"]="Email / Identifiant";
		self::$trad["password"]="Mot de passe";
		self::$trad["passwordToModify"]="Mot de passe (à modifier au besoin)";
		self::$trad["passwordVerif"]="Confirmer mot de passe";
		self::$trad["passwordInfo"]="Remplir le champ seulement si vous souhaitez changer de mot de passe";
		self::$trad["passwordVerifError"]="Votre confirmation de mot de passe n'est pas valide";
		self::$trad["connect"]="Connexion";
		self::$trad["connectAuto"]="rester connecté";
		self::$trad["connectAutoInfo"]="Retenir mon identifiant et mot de passe pour une connexion automatique";
		self::$trad["forgotPassword"]="infos de connexion oubliées ?";
		self::$trad["forgotPasswordInfo"]="Envoyer mon identifiant et mot de passe à mon adresse mail";
		self::$trad["guestAccess"]="Accès invité";
		self::$trad["spacePassError"]="Mot de passe erroné";
		self::$trad["ieObsolete"]="Votre navigateur est trop ancien et ne prend pas en charge les récents standards : ll est vivement conseillé de le mettre à jour ou d'utiliser un autre navigateur. Mise à jour à cette adresse : windows.microsoft.com/fr-fr/internet-explorer";

		////	Type d'affichage
		self::$trad["displayMode"]="Affichage";
		self::$trad["displayMode_line"]="Liste";
		self::$trad["displayMode_block"]="Bloc";
		
		////	Sélectionner / Déselectionner tous les éléments
		self::$trad["select"]="Sélectionner";
		self::$trad["selectUnselect"]="Sélectionner / déselectionner";
		self::$trad["selectAll"]="Tout sélectionner";
		self::$trad["invertSelection"]="Inverser la sélection";
		self::$trad["deleteElems"]="Supprimer les éléments";
		self::$trad["changeFolder"]="Déplacer vers un autre dossier";
		self::$trad["showOnMap"]="Voir les contacts sur une carte";
		self::$trad["selectUser"]="Merci de sélectionner au moins un utilisateur";
		self::$trad["selectUsers"]="Merci de sélectionner au moins 2 utilisateurs";
		self::$trad["selectSpace"]="Merci de sélectionner au moins un espace";
		
		////	Temps ("de 11h à 12h", "le 25-01-2007 à 10h30", etc.)
		self::$trad["from"]="de";
		self::$trad["at"]="à";
		self::$trad["the"]="le";
		self::$trad["begin"]="Début";
		self::$trad["end"]="Fin";
		self::$trad["hourSeparator"]="h";
		self::$trad["days"]="jours";
		self::$trad["day_1"]="Lundi";
		self::$trad["day_2"]="Mardi";
		self::$trad["day_3"]="Mercredi";
		self::$trad["day_4"]="Jeudi";
		self::$trad["day_5"]="Vendredi";
		self::$trad["day_6"]="Samedi";
		self::$trad["day_7"]="Dimanche";
		self::$trad["month_1"]="janvier";
		self::$trad["month_2"]="fevrier";
		self::$trad["month_3"]="mars";
		self::$trad["month_4"]="avril";
		self::$trad["month_5"]="mai";
		self::$trad["month_6"]="juin";
		self::$trad["month_7"]="juillet";
		self::$trad["month_8"]="aout";
		self::$trad["month_9"]="septembre";
		self::$trad["month_10"]="octobre";
		self::$trad["month_11"]="novembre";
		self::$trad["month_12"]="décembre";
		self::$trad["today"]="aujourd'hui";
		self::$trad["displayToday"]="Afficher aujourd'hui";
		self::$trad["beginEndError"]="La date de fin ne peut pas être antérieure à la date de début";
		self::$trad["dateFormatError"]="La date doit être au format jj/mm/AAAA";
		
		////	Nom & Description (pour les menus d'édition principalement)
		self::$trad["title"]="Titre";
		self::$trad["name"]="Nom";
		self::$trad["description"]="Description";
		self::$trad["specifyName"]="Merci de spécifier un nom";
		
		////	Validation des formulaires
		self::$trad["add"]=" Ajouter";
		self::$trad["modify"]=" Modifier";
		self::$trad["modifyAndAccesRight"]="Modifier / Gérer droits d'accès";
		self::$trad["validate"]=" Valider";
		self::$trad["send"]="Envoyer";
		self::$trad["sendTo"]="Envoyer à";

		////	Tri d'affichage. Tous les éléments (dossier, tâche, lien, etc...) ont par défaut une date, un auteur & une description
		self::$trad["sortBy"]="Trié par";
		self::$trad["SORT_dateCrea"]="date de création";
		self::$trad["SORT_dateModif"]="date de modif";
		self::$trad["SORT_title"]="titre";
		self::$trad["SORT_description"]="description";
		self::$trad["SORT__idUser"]="auteur";
		self::$trad["SORT_extension"]="type de fichier";
		self::$trad["SORT_octetSize"]="taille";
		self::$trad["SORT_downloadsNb"]="nb de téléchargements";
		self::$trad["SORT_civility"]="civilité";
		self::$trad["SORT_name"]="nom";
		self::$trad["SORT_firstName"]="prénom";
		self::$trad["SORT_adress"]="adresse";
		self::$trad["SORT_postalCode"]="code postal";
		self::$trad["SORT_city"]="ville";
		self::$trad["SORT_country"]="pays";
		self::$trad["SORT_function"]="fonction";
		self::$trad["SORT_companyOrganization"]="société / organisme";
		self::$trad["tri_ascendant"]="Ascendant";
		self::$trad["tri_descendant"]="Descendant";

		////	Options de suppression
		self::$trad["confirmDelete"]="Confirmer la suppression ? Attention : action irréversible!";
		self::$trad["confirmDeleteDouble"]="Êtes-vous sûr ?";
		self::$trad["confirmDeleteFolder"]="Attention! certains sous-dossiers ne vous ont pas été affectés en lecture ou ecriture (mais à d'autres utilisateurs) : ils seront également effacés !";
		self::$trad["delete"]="Supprimer";

		////	Visibilité d'un Objet : auteur et droits d'accès
		self::$trad["autor"]="Auteur";
		self::$trad["creation"]="Création";
		self::$trad["modification"]="Modif.";
		self::$trad["objHistory"]="Historique de l'élément";
		self::$trad["guest"]="invité";
		self::$trad["guests"]="invités";
		self::$trad["all"]="tous";
		self::$trad["unknown"]="personne indéfinie";
		self::$trad["accessRead"]="Lecture";
		self::$trad["readInfos"]="Accès en lecture";
		self::$trad["accessWriteLimit"]="Ecriture limitée";
		self::$trad["readLimitInfos"]="Possibilité d'ajouter des éléments (<i>-ELEMENT-</i>),<br>mais pas de modifier/supprimer les éléments créés par d'autres utilisateurs";
		self::$trad["accessWrite"]="Ecriture";
		self::$trad["writeInfos"]="Accès en écriture";
		self::$trad["writeInfosContainer"]="Accès en écriture : possibilité d'ajouter, modifier ou supprimer<br>tous les éléments (-ELEMENT-) du -CONTENEUR-";
		self::$trad["autorPrivilege"]="Seul l'auteur et les administrateurs peuvent<br>modifier les droits d'accès ou supprimer le -CONTENEUR-";
		self::$trad["folderContent"]="contenu";

		////	Libellé des objets (cf. "MdlObject::objectType")
		self::$trad["OBJECTcontainer"]="conteneur";
		self::$trad["OBJECTelement"]="élément";
		self::$trad["OBJECTfolder"]="dossier";
		self::$trad["OBJECTdashboardNews"]="actualité";
		self::$trad["OBJECTfile"]="fichier";
		self::$trad["OBJECTcalendar"]="agenda";
		self::$trad["OBJECTcalendarEvent"]="evenement";
		self::$trad["OBJECTforumSubject"]="sujet";
		self::$trad["OBJECTforumMessage"]="message";
		self::$trad["OBJECTcontact"]="contact";
		self::$trad["OBJECTlink"]="favori";
		self::$trad["OBJECTtask"]="note";
		self::$trad["OBJECTuser"]="utilisateur";
	
		////	Envoi d'un mail (nouvel utilisateur, notification de création d'objet, etc...)
		self::$trad["MAIL_noFooter"]="Ne pas signer le message";
		self::$trad["MAIL_noFooterInfo"]="Ne pas signer la fin du message <br>avec le nom de l'expéditeur et un lien vers l'espace";
		self::$trad["MAIL_hideRecipients"]="Masquer les destinataires";
		self::$trad["MAIL_hideRecipientsInfo"]="Par défaut, les destinataires sont visibles dans le message.<br>Attention car si l'option est coché et qu'il y a trop de destinataires,<br>le mail peut arriver en Spam";
		self::$trad["MAIL_receptionNotif"]="Accusé de reception";
		self::$trad["MAIL_receptionNotifInfo"]="Attention! Certaines messageries ne prennent pas en charge<br>les accusés de réception.";
		self::$trad["MAIL_sendBy"]="Envoyé par";  // "Envoyé par" M. Trucmuche
		self::$trad["MAIL_sendOk"]="L'e-mail a bien été envoyé !";
		self::$trad["MAIL_sendNotif"]="L'e-mail de notification a bien été envoyé !";
		self::$trad["MAIL_notSend"]="L'e-mail n'a pas pu être envoyé...";//idem
		self::$trad["MAIL_elemCreatedBy"]="Nouvel élément créé par";//boby
		self::$trad["MAIL_elemModifiedBy"]="Elément modifié par";//boby
		self::$trad["MAIL_elemOnSpace"]="sur l'espace";//truc
		self::$trad["MAIL_elemAccessLink"]="Cliquez ici pour accéder à l'élément sur votre espace";
		
		////	Dossier & fichier
		self::$trad["gigaOctet"]="Go";
		self::$trad["megaOctet"]="Mo";
		self::$trad["kiloOctet"]="Ko";
		self::$trad["rootFolder"]="Dossier racine";
		self::$trad["rootFolderEditInfo"]="Ouvrez le parametrage de l'espace<br>pour pouvoir modifier les droits d'accès au dossier racine";
		self::$trad["addFolder"]="Ajouter un dossier";
		self::$trad["download"]="Télécharger le fichier";
		self::$trad["downloadNb"]="Téléchargé";
		self::$trad["downloadNb2"]="fois"; // Téléchargé 'n' fois
		self::$trad["downloadFolder"]="Télécharger le dossier";
		self::$trad["diskSpaceUsed"]="Espace disque utilisé";
		self::$trad["diskSpaceUsedModFile"]="Espace disque utilisé sur le module fichier";
		self::$trad["downloadAlert"]="Téléchargement de grosse archive indisponible entre";//..(9h=>19h)
		self::$trad["downloadAlert2"]="Taille maximum sur cette plage horaire";//..200Mo

		////	Infos sur une personne
		self::$trad["civility"]="Civilité";
		self::$trad["name"]="Nom";
		self::$trad["firstName"]="Prénom";
		self::$trad["adress"]="Adresse";
		self::$trad["postalCode"]="Code postal";
		self::$trad["city"]="Ville";
		self::$trad["country"]="Pays";
		self::$trad["telephone"]="Téléphone";
		self::$trad["telmobile"]="Tél. mobile";
		self::$trad["mail"]="Email";
		self::$trad["fax"]="Fax";
		self::$trad["website"]="Site Web";
		self::$trad["skills"]="Compétences";
		self::$trad["hobbies"]="Centres d'intérêt";
		self::$trad["function"]="Fonction";
		self::$trad["companyOrganization"]="Organisme / Société";
		self::$trad["comment"]="Commentaire";

		////	Captcha
		self::$trad["captcha"]="Identification visuelle";
		self::$trad["captchaInfo"]="Merci de recopier les 4 caractères pour votre identification";
		self::$trad["captchaSpecify"]="Merci de spécifier l'identification visuelle";
		self::$trad["captchaError"]="L'identification visuelle est erronée";
		
		////	Rechercher
		self::$trad["searchSpecifyText"]="Merci de préciser des mots clés d'au moins 3 caractères";
		self::$trad["search"]="Rechercher";
		self::$trad["searchDateCrea"]="Date de création";
		self::$trad["searchDateCreaDay"]="moins d'un jour";
		self::$trad["searchDateCreaWeek"]="moins d'une semaine";
		self::$trad["searchDateCreaMonth"]="moins d'un mois";
		self::$trad["searchDateCreaYear"]="moins d'un an";
		self::$trad["searchOnSpace"]="Rechercher sur l'espace";
		self::$trad["advancedSearch"]= "Recherche avancée";
		self::$trad["advancedSearchSomeWords"]= "n'importe quel mot";
		self::$trad["advancedSearchAllWords"]= "tous les mots";
		self::$trad["advancedSearchExactPhrase"]= "expression exacte";
		self::$trad["keywords"]="Mots clés";
		self::$trad["listModules"]="Modules";
		self::$trad["listFields"]="Champs";
		self::$trad["listFieldsElems"]="Eléments concernés";
		self::$trad["noResults"]="Aucun résultat";
		
		////	Gestion des inscriptions d'utilisateur
		self::$trad["usersInscription"]="m'inscrire sur le site";
		self::$trad["usersInscriptionInfo"]="créer un nouveau compte utilisateur (validé par un administrateur)";
		self::$trad["usersInscriptionSpace"]="m'inscrire à l'espace";//.."trucmuche"
		self::$trad["usersInscriptionRecorded"]="votre inscription a bien été enregistrée : elle sera validée dès que possible par l'administrateur de l'espace";
		self::$trad["usersInscriptionOptionSpace"]="Les visiteurs peuvent s'incrire sur l'espace";
		self::$trad["usersInscriptionOptionSpaceInfo"]="L'inscription d'un utilisateur se fait sur la page d'accueil du site. Elle doit ensuite être validée par l'administrateur de l'espace !";
		self::$trad["usersInscriptionValidate"]="Inscriptions";
		self::$trad["usersInscriptionValidateInfo"]="Valider l'inscription d'utilisateurs sur le site";
		self::$trad["usersInscriptionInvalidate"]="Invalider";
		self::$trad["usersInscriptionInvalidateMail"]="Votre compte n'a pas été validé sur";
		
		////	Importer ou Exporter : Contact OU Utilisateurs
		self::$trad["export"]="Exporter";
		self::$trad["import"]="Importer";
		self::$trad["importExport_user"]="des utilisateurs";
		self::$trad["importExport_contact"]="des contacts";
		self::$trad["exportFormat"]="format";
		self::$trad["specifyFile"]="Merci de spécifier un fichier";
		self::$trad["fileExtension"]="Le type de fichier n'est pas valide. Il doit être de type";
		self::$trad["importInfo"]="Sélectionnez les champs Agora à cibler grâce aux listes déroulantes de chaque colonne.";
		self::$trad["importNotif"]="Merci de sélectionner la colonne nom dans les listes déroulante";
		self::$trad["importNotif2"]="Merci de sélectionner au moins un élément à importer";
		self::$trad["importNotif3"]="Le champ agora à déjà été sélectionné sur une autre colonne (chaque champs agora ne peut être sélectionné qu'une fois)";

		////	Messages d'alerte / d'erreur
		self::$trad["NOTIF_identification"]="Identifiant ou mot de passe invalide";
		self::$trad["NOTIF_presentIp"]="Compte actuellement utilisé avec une autre adresse ip... (un compte ne peut être utilisé que sur un seul poste en même temps)";
		self::$trad["NOTIF_adressIp"]="L'Adresse IP que vous utilisez n'est pas autorisée pour ce compte";
		self::$trad["NOTIF_noSpaceAccess"]="L'accès au site ne vous est pas autorisé car actuellement, vous n'êtes probablement affecté à aucun espace.";
		self::$trad["NOTIF_fileOrFolderAccess"]="Fichier ou dossier inaccessible";
		self::$trad["NOTIF_diskSpace"]="L'espace pour le stockage de vos fichiers est insuffisant, vous ne pouvez pas ajouter de fichier";
		self::$trad["NOTIF_fileVersion"]="Type de fichier différent de l'original";
		self::$trad["NOTIF_fileVersionForbidden"]="Type de fichier non autorisé";
		self::$trad["NOTIF_folderMove"]="Vous ne pouvez pas déplacer le dossier à l'intérieur de lui-même..!";
		self::$trad["NOTIF_duplicateName"]="Un élément portant le même nom existe déjà.";
		self::$trad["NOTIF_fileName"]="Un fichier avec le même nom existe déjà (sans être remplacé par le fichier courant)";
		self::$trad["NOTIF_chmodDATAS"]="Le dossier ''DATAS'' n'est pas accessible en écriture. Vous devez y donner un accès en lecture-ecriture, au proprietaire et au groupe (''chmod 775'')";
		self::$trad["NOTIF_usersNb"]="Vous ne pouvez pas créer de nouveau compte utilisateur : nombre limité à "; // "...limité à" 10
		self::$trad["NOTIF_update"]="Une mise à jour a été effectuée";
		self::$trad["NOTIF_usersExist"]="L'identifiant existe déjà : l'utilisateur n'a donc pas été créé";

		////	Header / Messenger / Footer
		self::$trad["HEADER_displaySpace"]="Afficher l'espace";
		self::$trad["HEADER_displayAdmin"]="Affichage Administrateur";
		self::$trad["HEADER_displayAdminInfo"]="Afficher TOUS les éléments de l'espace (réservé aux administrateurs)";
		self::$trad["HEADER_searchElem"]="Rechercher sur l'espace";
		self::$trad["HEADER_documentation"]="Guide d'utilisation";
		self::$trad["HEADER_disconnet"]="Déconnexion";
		self::$trad["HEADER_shortcuts"]="Raccourcis";
		self::$trad["MESSENGER_messenger"]="Messagerie instantanée";
		self::$trad["MESSENGER_currentlyAlone"]="Actuellement le seul connecté à l'espace";
		self::$trad["MESSENGER_connected"]="Connecté";
		self::$trad["MESSENGER_connectedSince"]="connecté depuis";//connecté depuis 12:45
		self::$trad["MESSENGER_sendAt"]="Envoyé à";
		self::$trad["MESSENGER_addMessageToSelection"]="Mon message (personnes selectionnées)";
		self::$trad["MESSENGER_addMessageTo"]="Mon message à";
		self::$trad["MESSENGER_addMessageNotif"]="Merci de spécifier un message";
		self::$trad["FOOTER_pageGenerated"]="page générée en";

		////	forgotPassword
		self::$trad["FORGOTPASS_preciseMail"]="Indiquez votre adresse e-mail pour recevoir vos coordonnées de connexion";
		self::$trad["FORGOTPASS_noMail"]="L'e-mail indiqué n'existe pas dans la base";
		self::$trad["FORGOTPASS_changePass"]="Spécifier ici votre nouveau mot de passe";
		self::$trad["FORGOTPASS_expired_idNewPassword"]="Le lien pour régénérer le mot de passe a expiré. Merci de recommencer la procédure";
		self::$trad["FORGOTPASS_reinitPassword"]="Votre nouveau mot de passe a été enregistré !";

		////	vueObjMenuEdit
		self::$trad["EDIT_notifNoSelection"]="Vous devez sélectionner au moins une personne ou un espace";
		self::$trad["EDIT_notifNoPersoAccess"]="Vous n'êtes pas affecté à l'élément. valider tout de même ?";
		self::$trad["EDIT_notifWriteAccess"]="Il doit y avoir au moins une personne, groupe ou un espace avec un accès en écriture";
		self::$trad["EDIT_notifWriteAdvice"]="Attention ! <br><br>Le droit en écriture permet d'effacer tous les messages du sujet. Il est conseillé de le réserver aux modérateurs du forum. <u>Préférez donc un accès en écriture limitée</u>";
		self::$trad["EDIT_parentFolderAccessError"]="Vérifiez l'accès de <i>--TARGET_LABEL--</i> au dossier parent <i>--FOLDER_NAME--</i> : <br><br>S'il n'y est pas affecté, l'accès au dossier courant lui sera impossible.";
		self::$trad["EDIT_notifGuest"]="Merci de préciser un nom ou un pseudo";
		self::$trad["EDIT_accessRight"]="Droits d'accès";
		self::$trad["EDIT_accessRightContent"]="Droits d'accès au contenu";
		self::$trad["EDIT_identification"]="Identification";
		self::$trad["EDIT_spaceNoModule"]="Le module courant n'a pas encore été ajouté à cet espace";
		self::$trad["EDIT_allUsers"]="Tous les utilisateurs";
		self::$trad["EDIT_allUsersInfo"]="Tous les utilisateurs de l'espace";
		self::$trad["EDIT_allSpaces"]="Tous les espaces";
		self::$trad["EDIT_spaceGuests"]="Invités de l'espace";
		self::$trad["EDIT_guest"]="Votre Nom / Pseudo";
		self::$trad["EDIT_adminSpace"]="Administrateur de l'espace :<br>accède en écriture à tous les éléments de l'espace";
		self::$trad["EDIT_mySpaces"]="Afficher tous mes espaces";
		self::$trad["EDIT_notifMail"]="Notifier par email";
		self::$trad["EDIT_notifMail2"]="Envoyer une notification par email";
		self::$trad["EDIT_notifMailAddFiles"]="Joindre les fichiers à la notification";
		self::$trad["EDIT_notifMailInfo"]="Envoyer une notification de création/modification par email<br>aux personnes affectées à cet élément ou sélectionnées dans le sous-menu";
		self::$trad["EDIT_notifMailSelect"]="Sélectionner manuellement les destinataires des notifications";
		self::$trad["EDIT_notifMailMoreUsers"]="Afficher + d'utilisateurs";
		self::$trad["EDIT_accessRightSubFolders"]="Donner les mêmes droits aux sous-dossiers";
		self::$trad["EDIT_accessRightSubFolders_info"]="Etendre les droits d'accès aux sous-dossiers :<br>uniquement ceux qui vous sont accessibles en écriture";
		self::$trad["EDIT_shortcut"]="Raccourci";
		self::$trad["EDIT_shortcutInfo"]="Afficher un raccourci dans la barre de menu (haut de page)";
		self::$trad["EDIT_attachedFile"]="Joindre des fichiers";
		self::$trad["EDIT_attachedFileInfo"]="Attacher des images, videos, Pdf, etc.<br>Les images et videos peuvent être intégrées au texte";
		self::$trad["EDIT_fileInsert"]="Afficher dans la description";
		self::$trad["EDIT_fileInsertInfo"]="Afficher l'image / video / Lecteur Mp3... dans la description ci-dessus. L'insertion sera réalisé après validation du formulaire.";
		self::$trad["EDIT_demandToConfirm"]="Votre demande a bien été enregistrée. Elle sera prise en compte prochainement.";

		////	Formulaire d'installation
		self::$trad["INSTALL_dbConnect"]="Connexion à la base de données";
		self::$trad["INSTALL_dbHost"]="Nom du serveur MySql (Hostname)";
		self::$trad["INSTALL_dbName"]="Nom de la Base de Données";
		self::$trad["INSTALL_dbLogin"]="Nom d'utilisateur";
		self::$trad["INSTALL_adminAgora"]="Administrateur de l'Agora";
		self::$trad["INSTALL_PhpOldVersion"]="Agora-Project necessite une version plus recente de PHP";
		self::$trad["INSTALL_errorConnectSGBD"]="La connexion au serveur de base de données à échoué";
		self::$trad["INSTALL_errorConnectIdentification"]="L'identification au serveur de base de données à échoué";
		self::$trad["INSTALL_errorAppliInstalled"]="L'application a déjà été installée sur cette base de données. Merci de supprimer la BDD si vous souhaitez relancer l'installation.";
		self::$trad["INSTALL_errorConnectDbConfirmInstall"]="La base de données n'existe pas : confirmer l'install et créer la Bdd ?";
		self::$trad["INSTALL_confirmInstall"]="Confirmer l'installation ?";
		self::$trad["INSTALL_installOk"]="Agora-Project a bien été installé !";
		self::$trad["INSTALL_spaceDescription"]="Espace de partage et de travail collaboratif";

		////	MODULE_PARAMETRAGE DE L'AGORA
		////
		self::$trad["AGORA_headerModuleName"]="Paramétrage général";
		self::$trad["AGORA_generalSettings"]="Paramétrage général";
		self::$trad["AGORA_backupFull"]="Sauvegarder la base de données et les fichiers";
		self::$trad["AGORA_backupNotif"]="La création du fichier de sauvegarde peut durer quelques minutes... et son téléchargement quelques dizaines de minutes.";
		self::$trad["AGORA_backupDb"]="Sauvegarder uniquement la base de données";
		self::$trad["AGORA_diskSpaceInvalid"]="L'espace disque limite doit être un entier";
		self::$trad["AGORA_confirmModif"]="Confirmez-vous les modifications ?";
		self::$trad["AGORA_name"]="Nom du site";
		self::$trad["AGORA_footerHtml"]="Footer / pied de page html";
		self::$trad["AGORA_footerHtmlInfo"]="Pour inclure des outils de statistique par exemple";
		self::$trad["AGORA_lang"]="Langue par défaut";
		self::$trad["AGORA_timezone"]="Fuseau horaire";
		self::$trad["AGORA_spaceName"]="Nom de l'espace principal";
		self::$trad["AGORA_diskSpaceLimit"]="Espace disque pour les fichiers";
		self::$trad["AGORA_logsTimeOut"]="Durée de conservation des Logs d'événements";
		self::$trad["AGORA_skin"]="Couleur de l'interface";
		self::$trad["AGORA_black"]="Noir";
		self::$trad["AGORA_white"]="Blanc";
		self::$trad["AGORA_wallpaperLogoError"]="L'image de fond d'écran et le logo doivent être au format .jpg ou .png";
		self::$trad["AGORA_deleteWallpaper"]="Supprimer le fond d'écran ?";
		self::$trad["AGORA_logo"]="Logo en bas de page";
		self::$trad["AGORA_logoUrl"]="URL";
		self::$trad["AGORA_logoConnect"]="Logo / Image en page de connexion";
		self::$trad["AGORA_logoConnectInfo"]="Affiché au dessus du formulaire de connexion";
		self::$trad["AGORA_messengerDisabled"]="Messagerie instantanée activée";
		self::$trad["AGORA_personalCalendarsDisabled"]="Agendas personnels activés par défaut";
		self::$trad["AGORA_personalCalendarsDisabled_infos"]="Ajouter par défaut un agenda personnel à la création d'un utilisateur. L'agenda pourra toutefois être désactivé par la suite, en modifiant le compte de l'utilisateur.";
		self::$trad["AGORA_moduleLabelDisplay"]="Nom des modules dans la barre de menu";
		self::$trad["AGORA_personsSort"]="Trier les utilisateurs et contacts par";
		self::$trad["AGORA_versions"]="Versions";
		self::$trad["AGORA_dateUpdate"]="mis à jour le";
		self::$trad["AGORA_funcMailDisabled"]="Fonction PHP pour envoyer des e-mails : désactivée !";
		self::$trad["AGORA_funcMailInfo"]="Certains hébergeurs désactivent la fonction PHP d'envoi de mails pour des raisons de sécurité ou de saturation des serveurs (SPAM)";
		self::$trad["AGORA_funcImgDisabled"]="Fonction de manipulation d'images et de vignettes (PHP GD2) : désactivée !";
		//SMTP
		self::$trad["AGORA_smtpLabel"]="Connexion SMTP & sendMail";
		self::$trad["AGORA_sendmailFrom"]="Mail dans le champ 'From'";
		self::$trad["AGORA_sendmailFromPlaceholder"]="ex: 'noreply@mon-domaine.fr'";
		self::$trad["AGORA_smtpHost"]="Adresse sur serveur (hostname)";
		self::$trad["AGORA_smtpPort"]="Port sur serveur";
		self::$trad["AGORA_smtpPortInfo"]="'25' par défaut. '587' ou '465' pour une connexion SSL/TLS";
		self::$trad["AGORA_smtpSecure"]="Type de connexion chiffrée (optionnel)";
		self::$trad["AGORA_smtpSecureInfo"]="'ssl' ou 'tls'";
		self::$trad["AGORA_smtpUsername"]="Nom d'utilisateur";
		self::$trad["AGORA_smtpPass"]="Mot de passe";
		//LDAP
		self::$trad["AGORA_ldapLabel"]="Connexion à un serveur LDAP";
		self::$trad["AGORA_ldapHost"]="Adresse sur serveur (hostname)";
		self::$trad["AGORA_ldapPort"]="Port sur serveur";
		self::$trad["AGORA_ldapPortInfo"]="''389'' par défaut";
		self::$trad["AGORA_ldapLogin"]="Chaine de connexion pour l'admin";
		self::$trad["AGORA_ldapLoginInfo"]="par exemple ''uid=admin,ou=mon_entreprise''";
		self::$trad["AGORA_ldapPass"]="Mot de passe de l'admin";
		self::$trad["AGORA_ldapDn"]="Groupe d'utilisateurs / base DN";
		self::$trad["AGORA_ldapDnInfo"]="Emplacement des utilisateurs dans l'annuaire.<br>Par exemple ''ou=users,o=mon_organisme''";
		self::$trad["AGORA_ldapConnectError"]="Erreur de connexion au serveur LDAP !";
		self::$trad["AGORA_ldapCreaAutoUsers"]="Création auto d'utilisateurs, si identification";
		self::$trad["AGORA_ldapCreaAutoUsersInfo"]="Créer automatiquement un utilisateur s'il est absent de l'Agora mais présent sur le serveur LDAP : il sera alors affecté aux espaces accessibles à ''tous les utilisateurs du site''.<br>Dans le cas contraire, l'utilisateur ne sera pas créé.";
		self::$trad["AGORA_ldapPassEncrypt"]="Password cryptés sur le serveur";
		self::$trad["AGORA_ldapDisabled"]="Le module PHP de connexion à un serveur LDAP n'est pas installé"; 

		////	MODULE_LOG
		////
		self::$trad["LOG_headerModuleName"]="Logs";
		self::$trad["LOG_moduleDescription"]="Logs - Journal des événements";
		self::$trad["LOG_filter"]="Filtre";
		self::$trad["LOG_date"]="Date/Heure";
		self::$trad["LOG_spaceName"]="Espace";
		self::$trad["LOG_moduleName"]="Module";
		self::$trad["LOG_objectType"]="type d'objet";
		self::$trad["LOG_action"]="Action";
		self::$trad["LOG_userName"]="Utilisateur";
		self::$trad["LOG_ip"]="IP";
		self::$trad["LOG_comment"]="Commentaire";
		self::$trad["LOG_noLogs"]="Aucun log";
		self::$trad["LOG_filterSince"]="filtré à partir des";
		self::$trad["LOG_search"]="Chercher";
		self::$trad["LOG_connexion"]="connexion";//action
		self::$trad["LOG_deconnexion"]="déconnexion";//action
		self::$trad["LOG_consult"]="consultation";//action
		self::$trad["LOG_consult2"]="telechargement";//action
		self::$trad["LOG_add"]="ajout";//action
		self::$trad["LOG_delete"]="suppression";//action
		self::$trad["LOG_modif"]="modification";//action

		////	MODULE_ESPACE
		////
		self::$trad["SPACE_headerModuleName"]="Espaces";
		self::$trad["SPACE_moduleInfo"]="Le site (ou espace principal) peut être subdivisé en plusieurs espaces";
		self::$trad["SPACE_manageSpaces"]="Gérer les espaces du site";
		self::$trad["SPACE_config"]="Paramétrer l'espace";
		//Index
		self::$trad["SPACE_confirmDeleteDbl"]="Confirmer la suppression ? Attention, les données affectées uniquement à cet espace seront définitivement perdues !!";
		self::$trad["SPACE_space"]="espace";
		self::$trad["SPACE_spaces"]="espaces";
		self::$trad["SPACE_accessRightUndefined"]="A définir !";
		self::$trad["SPACE_modules"]="Modules";
		self::$trad["SPACE_addSpace"]="Ajouter un espace";
		//Edit
		self::$trad["SPACE_usersAccess"]="Utilisateurs affectés à l'espace";
		self::$trad["SPACE_selectModule"]="Vous devez sélectionner au moins un module";
		self::$trad["SPACE_spaceModules"]="Modules de l'espace";
		self::$trad["SPACE_moduleRank"]="Déplacer pour définir l'ordre d'affichage des modules";
		self::$trad["SPACE_publicSpace"]="Espace public";
		self::$trad["SPACE_publicInfo"]="Donne accès aux personnes qui n'ont pas de compte sur le site : ''invités''. Possibilité de spécifier un mot de passe pour protéger l'accès.";
		self::$trad["SPACE_usersInvitation"]="Les utilisateurs peuvent envoyer des invitations par mail";
		self::$trad["SPACE_usersInvitationInfo"]="Tous les utilisateurs peuvent envoyer des invitations par mail pour rejoindre l'espace";
		self::$trad["SPACE_allUsers"]="Tous les utilisateurs";
		self::$trad["SPACE_user"]=" Utilisateur";
		self::$trad["SPACE_userInfo"]="Accès normal à l'espace";
		self::$trad["SPACE_admin"]="Administrateur";
		self::$trad["SPACE_adminInfo"]="Administrateur de l'espace : Accès en écriture à tous les éléments de l'espace + envoi d'invitations par mail + création d'utilisateurs sur l'espace";
		self::$trad["SPACE_createSpaceCalendar"]="Créer un agenda partagé";
		self::$trad["SPACE_createSpaceCalendarInfo"]="L'agenda portera le même nom que l'espace<br>(option utile si les agendas des utilisateurs sont désactivés)";

		////	MODULE_UTILISATEUR
		////
		// Menu principal
		self::$trad["USER_headerModuleName"]="Utilisateurs";
		self::$trad["USER_moduleDescription"]="Utilisateurs de l'espace";
		self::$trad["USER_ajout_utilisateurs_groupe"]="Tous les utilisateurs peuvent créer des groupes";//OPTION EN BDD
		//Index
		self::$trad["USER_allUsers"]="Tous les utilisateurs";
		self::$trad["USER_allUsersManage"]="Gérer tous les utilisateurs du site";
		self::$trad["USER_allUsersInfo"]="Tous les utilisateurs :<br>Ensemble des utilisateurs du site, tous espaces confondus";
		self::$trad["USER_spaceUsers"]="Utilisateurs de l'espace";
		self::$trad["USER_confirmDeleteFromSpace"]="Confirmer la désaffectation de l'utilisateur à l'espace courant ?";
		self::$trad["USER_deleteDefinitely"]="Supprimer définitivement";
		self::$trad["USER_deleteFromSpace"]="Désaffecter de l'espace";
		self::$trad["USER_allUsersOnSpaceNotif"]="Tous les utilisateurs du site sont affectés à cet espace : pas de désaffectation possible";
		self::$trad["USER_user"]="Utilisateur";
		self::$trad["USER_users"]="utilisateurs";
		self::$trad["USER_addExistUser"]="Ajouter un utilisateur existant";
		self::$trad["USER_addUser"]="Ajouter un utilisateur";
		self::$trad["USER_addUserSite"]="Créer un utilisateur sur le site : affecté par défaut à aucun espace !";
		self::$trad["USER_addUserSpace"]="Créer un utilisateur pour l'espace courant";
		self::$trad["USER_sendCoords"]="Envoyer login et mot de passe";
		self::$trad["USER_sendCoordsInfo"]="Envoyer à des utilisateurs<br>un mail avec leurs coordonnées de connexion.";
		self::$trad["USER_sendCoordsInfo2"]="Envoyer à chaque nouvel utilisateur<br>un mail avec leurs coordonnées de connexion.";
		self::$trad["USER_sendCoordsConfirm"]="Confirmer l'envoi ?";
		self::$trad["USER_sendCoordsMail"]="Vos coordonnées de connexion à votre espace";
		self::$trad["USER_loginResetPassword"]="Cliquer ici pour vous connecter à votre espace et initialiser votre mot de passe";
		self::$trad["USER_noUser"]="Aucun utilisateur affecté à cet espace pour le moment";
		self::$trad["USER_lastConnection"]="Dernière connexion";
		self::$trad["USER_spaceList"]="Espaces de l'utilisateur";
		self::$trad["USER_spaceNoAffectation"]="aucun espace";
		self::$trad["USER_adminGeneral"]="Administrateur général";
		self::$trad["USER_adminSpace"]="Administrateur de l'espace";
		self::$trad["USER_userSpace"]="Utilisateur de l'espace";
		self::$trad["USER_notConnectedYet"]="Pas encore connecté";
		self::$trad["USER_modify"]="Modifier le profil utilisateur";
		self::$trad["USER_modifyProfil"]="Modifier mon profil utilisateur";
		// Invitations
		self::$trad["USER_sendInvitation"]="Inviter quelqu'un à rejoindre l'espace";
		self::$trad["USER_sendInvitationInfo"]="L'invitation sera envoyé par mail";
		self::$trad["USER_mailInvitationObject"]="Invitation de "; // ..Jean DUPOND
		self::$trad["USER_mailInvitationFromSpace"]="vous invite sur "; // Jean DUPOND "vous invite à rejoindre l'espace" Mon Espace
		self::$trad["USER_mailInvitationConfirm"]="Cliquer ici pour confirmer l'invitation";
		self::$trad["USER_mailInvitationWait"]="Invitation(s) en attente de confirmation";
		self::$trad["USER_exired_idInvitation"]="Le lien de votre invitation a expiré...";
		self::$trad["USER_invitationConfirmPassword"]="Choisissez votre mot de passe puis cliquez sur 'OK' pour confirmer votre invitation";
		self::$trad["USER_invitationValidated"]="Votre invitation a été validée !";
		// groupes
		self::$trad["USER_spaceGroups"]="groupes d'utilisateur de l'espace";
		self::$trad["USER_userGroups"]="editer les groupes d'utilisateurs";
		self::$trad["USER_groupEditInfo"]="Chaque groupe peut être modifié par son auteur ou par l'administrateur général";
		// Utilisateur_affecter
		self::$trad["USER_searchPrecision"]="Merci de préciser un nom, un prénom ou une adresse e-mail";
		self::$trad["USER_userAffectConfirm"]="Confirmer les affectations ?";
		self::$trad["USER_userSearch"]="Rechercher des utilisateurs pour les ajouter à l'espace";
		self::$trad["USER_allUsersOnSpace"]="Tous les utilisateurs du site sont affectés à cet espace";
		self::$trad["USER_usersSpaceAffectation"]="Affecter des utilisateurs à l'espace :";
		self::$trad["USER_usersSearchNoResult"]="Aucun utilisateur pour cette recherche";
		// Utilisateur_edit  & CO
		self::$trad["USER_specifyName"]="Merci de spécifier un nom";
		self::$trad["USER_specifyFirstName"]="Merci de spécifier un prénom";
		self::$trad["USER_specifyLogin"]="Merci de spécifier un identifiant";
		self::$trad["USER_specifyPassword"]="Merci de spécifier un mot de passe";
		self::$trad["USER_specifyMailAsLogin"]="Il est recommandé d'utiliser une adresse mail comme identifiant de connexion. Valider tout de même le formulaire?";
		self::$trad["USER_langs"]="Langue";
		self::$trad["USER_persoCalendarDisabled"]="Agenda personnel désactivé";
		self::$trad["USER_persoCalendarDisabledInfo"]="Par défaut, l'agenda personnel reste toujours accessible à l'utilisateur, même si le module Agenda est désactivé sur l'espace";
		self::$trad["USER_connectionSpace"]="Espace affiché à la connexion";
		self::$trad["USER_creaNotifMail"]="Envoyer une notification de création par e-mail";
		self::$trad["USER_notifSpecifyMail"]="Pensez à spécifier une adresse e-mail !";
		self::$trad["USER_ipAdress"]="Adresses IP de contrôle";
		self::$trad["USER_ipAdressInfo"]="Si vous spécifiez une adresse IP (ou+) :<br>l'utilisateur ne pourra se connecter que depuis celle-ci";
		self::$trad["USER_loginPresentYet"]="L'identifiant spécifié existe déjà. Merci d'en spécifier un autre";
		self::$trad["USER_mailPresentYet"]="L'adresse e-mail existe déjà. Merci d'en spécifier une autre";
		self::$trad["USER_mailNotifObject"]="Bienvenue sur ";  //.."mon-espace"
		self::$trad["USER_mailNotifContent"]="Votre compte utilisateur vient d'être créé sur";  //.."mon-espace"
		self::$trad["USER_mailNotifContent2"]="Connectez-vous ici avec les coordonnées suivantes";
		self::$trad["USER_mailNotifContent3"]="Merci de conserver cet e-mail dans vos archives.";
		// Livecounter / Messenger
		self::$trad["USER_editMessenger"]="Gérer la messagerie instantanée";
		self::$trad["USER_editMyMessenger"]="Gérer ma messagerie instantanée";
		self::$trad["USER_livecounterVisibility"]="Utilisateurs qui me voient en ligne <br>et avec qui je peux discuter sur la messagerie instantanée";
		self::$trad["USER_livecounterNobody"]="Aucun utilisateur pour l'instant";
		self::$trad["USER_livecounterDisabled"]="Messagerie désactivée (aucun utilisateur ne peut me voir)";
		self::$trad["USER_livecounterAllUsers"]="Tous les utilisateurs peuvent me voir";
		self::$trad["USER_livecounterSomeUsers"]="Seuls certains utilisateurs peuvent me voir";

		////	MODULE_TABLEAU BORD
		////
		// Menu principal + options du module
		self::$trad["DASHBOARD_headerModuleName"]="News";
		self::$trad["DASHBOARD_moduleDescription"]="Actualités & nouveaux éléments";
		self::$trad["DASHBOARD_ajout_actualite_admin"]="Seul l'administrateur peut ajouter des actualités";//OPTION
		//Index
		self::$trad["DASHBOARD_newElems"]="nouveautés";
		self::$trad["DASHBOARD_newElemsInfo"]="Eléments créés entre <br>";
		self::$trad["DASHBOARD_currentElems"]="elems. courants";
		self::$trad["DASHBOARD_currentElemsInfo"]="Evenements et tâches ayant lieu entre <br>";
		self::$trad["DASHBOARD_pluginSinceConnection"]="depuis ma dernière connexion";
		self::$trad["DASHBOARD_pluginOfDay"]="d'aujourd'hui";
		self::$trad["DASHBOARD_pluginOfWeek"]="de la semaine";
		self::$trad["DASHBOARD_pluginOfMonth"]="du mois";
		self::$trad["DASHBOARD_pluginOtherPeriod"]="Autre période";
		self::$trad["DASHBOARD_pluginEmpty"]="Aucun élément sur la période";
		self::$trad["DASHBOARD_addNews"]="Ajouter une actualité";
		self::$trad["DASHBOARD_newsOffline"]="Actualités hors ligne";
		self::$trad["DASHBOARD_noNews"]="Aucune actualité";
		// Actualite_edit
		self::$trad["DASHBOARD_topNews"]="Actualité à la une";
		self::$trad["DASHBOARD_topNewsInfo"]="Actualité affichée en haut de liste";
		self::$trad["DASHBOARD_offline"]="Hors ligne";
		self::$trad["DASHBOARD_offlineInfo"]="Actualité hors ligne";
		self::$trad["DASHBOARD_dateOnline"]="Date de mise en ligne";
		self::$trad["DASHBOARD_dateOnlineInfo"]="Définir une date de mise en ligne automatique.<br>Dans cette attente, l'actualité sera mise hors ligne";
		self::$trad["DASHBOARD_dateOnlineNotif"]="L'actualité est hors ligne dans l'attente de sa mise en ligne automatique";
		self::$trad["DASHBOARD_dateOffline"]="Date de mise hors ligne";
		self::$trad["DASHBOARD_dateOfflineInfo"]="Définir une date de mise hors ligne automatique";

		////	MODULE_AGENDA
		////
		// Menu principal
		self::$trad["CALENDAR_headerModuleName"]="Agenda";
		self::$trad["CALENDAR_moduleDescription"]="Agendas personnel et agendas partagés";
		self::$trad["CALENDAR_ajout_agenda_ressource_admin"]="Seul l'administrateur peut ajouter des agendas partagés";//OPTION
		self::$trad["CALENDAR_ajout_categorie_admin"]="Seul l'administrateur peut ajouter des categories d'événement";//OPTION
		//Index
		self::$trad["CALENDAR_displayAllCals"]="Afficher tous les agendas (réservé aux administrateurs)";
		self::$trad["CALENDAR_hideAllCals"]="Masquer tous les agendas";
		self::$trad["CALENDAR_printCalendars"]="Imprimer l'agenda";
		self::$trad["CALENDAR_printCalendarsInfos"]="Imprimez la page en mode paysage";
		self::$trad["CALENDAR_addSharedCalendar"]="Créer un agenda partagé";
		self::$trad["CALENDAR_addSharedCalendarInfo"]="Créer un agenda partagé :<br>pour les réservation d'une salle, véhicule, vidéoprojecteur, etc.";
		self::$trad["CALENDAR_exportIcal"]="Exporter les événements (iCal)";
		self::$trad["CALENDAR_exportEvtMail"]="Envoyer les événements par mail (iCal)";
		self::$trad["CALENDAR_exportEvtMailInfo"]="Pour les intégrer dans un calendrier IPHONE, ANDROID, OUTLOOK, GOOGLE CALENDAR...";
		self::$trad["CALENDAR_exportEvtMailList"]="liste des événements au format .Ical";
		self::$trad["CALENDAR_importIcal"]="Importer les événements (iCal)";
		self::$trad["CALENDAR_importIcalState"]="Etat";
		self::$trad["CALENDAR_importIcalStatePresent"]="Déjà présent";
		self::$trad["CALENDAR_importIcalStateImport"]="A importer";
		self::$trad["CALENDAR_addEvtHour"]="Ajouter un événement à";
		self::$trad["CALENDAR_addEvtDay"]="Ajouter un événement à cette date";
		self::$trad["CALENDAR_displayDay"]="Jour";
		self::$trad["CALENDAR_display3Days"]="3 jours";
		self::$trad["CALENDAR_displayWorkWeek"]="Semaine de travail";
		self::$trad["CALENDAR_displayWeek"]="Semaine";
		self::$trad["CALENDAR_displayMonth"]="Mois";
		self::$trad["CALENDAR_weekNb"]="Voir la semaine n°"; //...5
		self::$trad["CALENDAR_periodNext"]="Période suivante";
		self::$trad["CALENDAR_periodPrevious"]="Période précédente";
		self::$trad["CALENDAR_evtAffects"]="Dans l'agenda de";
		self::$trad["CALENDAR_evtAffectToConfirm"]="Attente de confirmation pour les agendas : ";
		self::$trad["CALENDAR_evtProposedFor"]="Proposé pour "; // "Videoprojecteur" / "salle de réunion" / etc.
		self::$trad["CALENDAR_evtProposedForMe"]="Proposé pour mon agenda perso";
		self::$trad["CALENDAR_evtProposedBy"]="Proposé par";  // "Proposé par" M. Bidule
		self::$trad["CALENDAR_evtIntegrate"]="Intégrer l'événement à l'agenda ?";
		self::$trad["CALENDAR_evtNotIntegrate"]="Supprimer la proposition d'événement ?";
		self::$trad["CALENDAR_deleteEvtCal"]="Supprimer uniquement dans cet agenda?";
		self::$trad["CALENDAR_deleteEvtCals"]="Supprimer dans tous les agendas?";
		self::$trad["CALENDAR_deleteEvtDate"]="Supprimer uniquement à cette date?";
		self::$trad["CALENDAR_evtPrivate"]="Évènement privé";
		self::$trad["CALENDAR_evtAutor"]="Événements que j'ai créés";
		self::$trad["CALENDAR_noEvt"]="Aucun événement";
		self::$trad["CALENDAR_propose"]="Proposer l'événement";
		self::$trad["CALENDAR_synthese"]="Synthèse des agendas";
		self::$trad["CALENDAR_calendarsPercentBusy"]="Agendas occupés";  // Agendas occupés : 2/5
		self::$trad["CALENDAR_noCalendarDisplayed"]="Aucun agenda affiché";
		// Evenement
		self::$trad["CALENDAR_category"]="Catégorie";
		self::$trad["CALENDAR_visibilityPublic"]="visibilité normale";
		self::$trad["CALENDAR_visibilityPublicHide"]="visibilité semi-privée";
		self::$trad["CALENDAR_visibilityPrivate"]="visibilité privée";
		self::$trad["CALENDAR_visibilityInfo"]="<u>visibilité semi-privée</u> : si l'évènement est accessible en lecture seule, seule la plage horaire sera affichée (sans titre ni détail).<br><br><u>visibilité privée</u> : visible uniquement pour ceux dont l'évènement est accessible en écriture.";
		// Agenda_edit
		self::$trad["CALENDAR_timeSlot"]="Plage horaire";
		// Evenement_edit
		self::$trad["CALENDAR_noPeriodicity"]="Evenement ponctuel";
		self::$trad["CALENDAR_period_weekDay"]="Toutes les semaines";
		self::$trad["CALENDAR_period_monthDay"]="Jours du mois";
		self::$trad["CALENDAR_period_month"]="Tous les mois";
		self::$trad["CALENDAR_period_dayOfMonth"]="du mois";//Le 21 du mois
		self::$trad["CALENDAR_period_year"]="Tous les ans";
		self::$trad["CALENDAR_periodDateEnd"]="Fin de périodicité";
		self::$trad["CALENDAR_periodException"]="Exception de périodicité";
		self::$trad["CALENDAR_calendarAffectations"]="Affectation aux agendas";
		self::$trad["CALENDAR_verifCalNb"]="Merci de sélectionner au moins un agenda";
		self::$trad["CALENDAR_inputPropose"]="Proposer l'événement au propriétaire de l'agenda";
		self::$trad["CALENDAR_inputProposed"]="L'événement sera proposé au propriétaire de l'agenda";
		self::$trad["CALENDAR_inputAffect"]="Ajouter l'événement à l'agenda";
		self::$trad["CALENDAR_proposeInfo"]="Proposition seulement (vous n'avez pas accès en écriture à cet agenda)";
		self::$trad["CALENDAR_noModifInfo"]="Modification non autorisé :<br> vous n'avez pas accès en écriture à cet agenda";
		self::$trad["CALENDAR_editLimit"]="Vous n'êtes pas l'auteur de l'événement :<br>vous pouvez uniquement gérer les affectations à vos agendas";
		self::$trad["CALENDAR_busyTimeslot"]="Créneau est déjà occupé sur l'agenda suivant :";
		// Categories
		self::$trad["CALENDAR_editCategories"]="Editer les catégories d'événements";
		self::$trad["CALENDAR_editCategoriesRight"]="Chaque categorie peut être modifié par son auteur ou par l'administrateur général";

		////	MODULE_FICHIER
		////
		// Menu principal
		self::$trad["FILE_headerModuleName"]="Fichiers";
		self::$trad["FILE_moduleDescription"]="Gestionnaire de fichiers";
		self::$trad["FILE_AdminRootFolderAddContent"]="Seul l'administrateur peut ajouter des dossiers et fichiers à la racine";//OPTION
		//Index
		self::$trad["FILE_ajouter_fichier"]="Ajouter des fichiers";
		self::$trad["FILE_ajouter_fichier_alert"]="Dossier du serveur inaccessible en écriture!  merci de contacter l'administrateur";
		self::$trad["FILE_telecharger_selection"]="télécharger la sélection";
		self::$trad["FILE_nb_versions_fichier"]="versions du fichier"; // n versions du fichier
		self::$trad["FILE_ajouter_versions_fichier"]="Ajouter nouvelle version du fichier";
		self::$trad["FILE_aucun_fichier"]="Aucun fichier pour le moment";
		// fichier_edit_ajouter  &  Fichier_edit
		self::$trad["FILE_fileSizeLimit"]="Les fichiers ne doivent pas dépasser"; // ...2 Mega Octets
		self::$trad["FILE_optimiser_images"]="Limiter la taille à "; // ..1024 pixels
		self::$trad["FILE_updatedName"]="Le nom du fichier sera remplacé par celui de la nouvelle version";
		self::$trad["FILE_erreur_taille_fichier"]="Fichier trop volumineux";
		self::$trad["FILE_ajout_multiple_info"]="Touche Ctrl pour sélectionner plusieurs fichiers";
		self::$trad["FILE_selectionner_fichier"]="Merci de sélectionner au moins un fichier";
		self::$trad["FILE_contenu"]="contenu";
		// Versions_fichier
		self::$trad["FILE_versions_de"]="Versions de"; // versions de fichier.gif
		self::$trad["FILE_confirmer_suppression_version"]="Confirmer la suppression de cette version ?";

		////	MODULE_FORUM
		////
		// Menu principal
		self::$trad["FORUM_headerModuleName"]="Forum";
		self::$trad["FORUM_moduleDescription"]="Forum";
		self::$trad["FORUM_ajout_sujet_admin"]="Seul l'administrateur peut ajouter des sujets";
		self::$trad["FORUM_ajout_sujet_theme"]="Tous les utilisateurs peuvent ajouter des thèmes";
		// TRI
		self::$trad["SORT_dateLastMessage"]="dernier message";
		//Index & Sujet
		self::$trad["FORUM_sujet"]="sujet";
		self::$trad["FORUM_sujets"]="sujets";
		self::$trad["FORUM_message"]="message";
		self::$trad["FORUM_messages"]="messages";
		self::$trad["FORUM_lastPost"]="dernier";
		self::$trad["FORUM_ajouter_sujet"]="Ajouter un sujet";
		self::$trad["FORUM_voir_sujet"]="Voir le sujet";
		self::$trad["FORUM_ajouter_message"]="Ajouter un message";
		self::$trad["FORUM_quoteMessage"]="Répondre en citant ce message";
		self::$trad["FORUM_noSubject"]="Pas de sujet pour le moment";
		self::$trad["FORUM_noMessage"]="Pas de message pour le moment";
		self::$trad["FORUM_notifyLastPost"]="Me notifier par mail";
		self::$trad["FORUM_notifyLastPostInfo"]="Me prévenir par mail à chaque nouveau message";
		// Sujet_edit  &  Message_edit
		self::$trad["FORUM_accessRightInfos"]="Pour participer à la discussion, il faut au minimum un accès en ''ecriture limitée''";
		self::$trad["FORUM_theme_espaces"]="Le thème sélectionné est uniquement accessible aux espaces";
		// Themes
		self::$trad["FORUM_theme_sujet"]="Thème";
		self::$trad["FORUM_accueil_forum"]="Accueil du forum";
		self::$trad["FORUM_sans_theme"]="Sans thème";
		self::$trad["FORUM_themes_gestion"]="Editer les thèmes de sujet";
		self::$trad["FORUM_droit_gestion_themes"]="Chaque theme peut être modifié par son auteur ou par l'administrateur général";

		////	MODULE_TACHE
		////
		// Menu principal
		self::$trad["TASK_headerModuleName"]="Notes";
		self::$trad["TASK_moduleDescription"]="Notes & Tâches";
		self::$trad["TASK_AdminRootFolderAddContent"]="Seul l'administrateur peut ajouter des dossiers et notes à la racine";
		// TRI
		self::$trad["SORT_priority"]="Priorité";
		self::$trad["SORT_advancement"]="Avancement";
		self::$trad["SORT_dateBegin"]="Date de debut";
		self::$trad["SORT_dateEnd"]="Date de fin";
		//Index
		self::$trad["TASK_ajouter_tache"]="Ajouter une note";
		self::$trad["TASK_aucune_tache"]="Aucune note pour le moment";
		self::$trad["TASK_advancement"]="Avancement";
		self::$trad["TASK_advancementAverage"]="Avancement moyen";
		self::$trad["TASK_priority"]="Priorité";
		self::$trad["TASK_priority1"]="Basse";
		self::$trad["TASK_priority2"]="Moyenne";
		self::$trad["TASK_priority3"]="Haute";
		self::$trad["TASK_priority4"]="Critique";
		self::$trad["TASK_responsiblePersons"]="Responsables";
		self::$trad["TASK_budgetAvailable"]="Budget disponible";
		self::$trad["TASK_budgetAvailable_total"]="Budget total disponible";
		self::$trad["TASK_budgetEngaged"]="Budget engagé";
		self::$trad["TASK_budgetEngaged_total"]="Budget total engagé";
		self::$trad["TASK_humanDayCharge"]="Charge jours/homme";
		self::$trad["TASK_humanDayCharge_info"]="Nombre de jours de travail necessaires à une seule personne pour accomplir cette tâche";
		self::$trad["TASK_advancement_retard"]="Avancement en retard";
		self::$trad["TASK_budgetExceeded"]="Budget dépassé";

		////	MODULE_CONTACT
		////
		// Menu principal
		self::$trad["CONTACT_headerModuleName"]="Contacts";
		self::$trad["CONTACT_moduleDescription"]="Annuaire de contacts";
		self::$trad["CONTACT_AdminRootFolderAddContent"]="Seul l'administrateur peut ajouter des dossiers et contacts à la racine";
		//Index
		self::$trad["CONTACT_ajouter_contact"]="Ajouter un contact";
		self::$trad["CONTACT_aucun_contact"]="Aucun contact pour le moment";
		self::$trad["CONTACT_creer_user"]="Créer un utilisateur sur cet espace";
		self::$trad["CONTACT_creer_user_infos"]="Créer un utilisateur sur cet espace à partir de ce contact ?";
		self::$trad["CONTACT_creer_user_confirm"]="L'utilisateur a été créé";

		////	MODULE_LIEN
		////
		// Menu principal
		self::$trad["LINK_headerModuleName"]="Liens";
		self::$trad["LINK_moduleDescription"]="Liens favoris";
		self::$trad["LINK_AdminRootFolderAddContent"]="Seul l'administrateur peut ajouter des dossiers et liens à la racine";
		//Index
		self::$trad["LINK_ajouter_lien"]="Ajouter un lien";
		self::$trad["LINK_aucun_lien"]="Aucun lien pour le moment";
		// lien_edit & dossier_edit
		self::$trad["LINK_adress"]="Adresse web";

		////	MODULE_MAIL
		////
		// Menu principal
		self::$trad["MAIL_headerModuleName"]="Mailing";
		self::$trad["MAIL_moduleDescription"]="Envoyer en toute simplicité des e-mails à vos collaborateurs, amis ou contacts pour informer des dernières actualités";
		//Index
		self::$trad["MAIL_specifier_mail"]="Merci de spécifier au moins un destinataire";
		self::$trad["MAIL_title"]="Titre de l'e-mail";
		self::$trad["MAIL_fichier_joint"]="Fichier joint";
		// Historique Mail
		self::$trad["MAIL_historique_mail"]="Historique des e-mails envoyés";
		self::$trad["MAIL_aucun_mail"]="Aucun e-mail";
		self::$trad["MAIL_recipients"]="Destinataires";
	}

	/*
	 * Jours Fériés de l'année (sur quatre chiffre)
	 */
	public static function celebrationDays($year)
	{
		// Init
		$dateList=array();

		//Fêtes mobiles (si la fonction de récup' de paques existe)
		if(function_exists("easter_date"))
		{
			$daySecondes=86400;
			$paquesTime=easter_date($year);
			$date=date("Y-m-d", $paquesTime+$daySecondes);
			$dateList[$date]="Lundi de pâques";
			$date=date("Y-m-d", $paquesTime+($daySecondes*39));
			$dateList[$date]="Jeudi de l'ascension";
			$date=date("Y-m-d", $paquesTime+($daySecondes*50));
			$dateList[$date]="Lundi de pentecôte";
		}

		//Fêtes fixes
		$dateList[$year."-01-01"]="Jour de l'an";
		$dateList[$year."-05-01"]="Fête du travail";
		$dateList[$year."-05-08"]="Armistice 39-45";
		$dateList[$year."-07-14"]="Fête nationale";
		$dateList[$year."-08-15"]="Assomption";
		$dateList[$year."-11-01"]="Toussaint";
		$dateList[$year."-11-11"]="Armistice 14-18";
		$dateList[$year."-12-25"]="Noël";

		//Retourne le résultat
		return $dateList;
	}
}
