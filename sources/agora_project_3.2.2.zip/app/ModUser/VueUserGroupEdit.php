<script type="text/javascript">
////	Resize
lightboxWidth(550);

////	Controle du formulaire
function formControl(targetObjId)
{
	//Vérif la présence du titre
	if($("#form-"+targetObjId+" [name='title']").isEmpty()){
		notify("<?= Txt::trad("requiredFields")." : ".Txt::trad("title") ?>");
		$("#form-"+targetObjId+" [name='title']").focusRed();
		return false;
	}
	// Au moins 2 utilisateurs sélectionnés
	if($("#form-"+targetObjId+" [name='userList[]']:checked").length<2){
		notify("<?= Txt::trad("selectUsers") ?>");
		return false;
	}
}
</script>

<style>
form				{margin-top:30px; margin-left:10px; width:93%; padding:10px; border: #999 1px solid;}
#form-userGroup-0	{display:none;}/*masque le premier groupe : nouveau groupe*/
.labelDetail		{margin-top:8px;}
.labelSpaceName		{font-style:italic;}
input[name='title']	{width:50%; margin-bottom:5px;}
.vGroupAutor		{float:right; font-style:italic;}
[id^='userListMenu']{overflow:auto; max-height:150px;}
.userListUser		{display:inline-block; width:32%; padding:2px;}
.userListUser input	{display:none;}
.formButtons		{margin-top:10px; text-align:right;}
button				{width:120px;}
[src*='delete.png']	{margin-left:10px;}
#addGroup			{margin-top:30px; margin-right:10px; text-align:center;}

/*RESPONSIVE -> 400px!*/
@media screen and (max-width:400px){
	form				{width:88%;}
	.userListUser		{width:48%; padding:3px;}
}
</style>

<div class="lightboxTitle">
	<img src="app/img/user/userGroup.png"> <?= Txt::trad("USER_spaceGroups") ?> : <span class="labelSpaceName"><?= Ctrl::$curSpace->name ?></span>
	<div class="labelDetail"><?= Txt::trad("USER_groupEditInfo") ?></div>
</div>

<!--LISTE LES GROUPES-->
<?php foreach($groupList as $cptGroup=>$tmpGroup){ ?>
<form action="index.php" method="post" class="sBlock" id="form-<?= $tmpGroup->tmpId ?>" OnSubmit="return formControl('<?= $tmpGroup->tmpId ?>');">
	<!--AUTEUR & TITRE-->
	<div class="vGroupAutor"><?= $tmpGroup->createdBy ?></div>
	<input type="text" name="title" value="<?= $tmpGroup->title ?>" placeholder="<?= Txt::trad("title") ?>">
	<!--USERS-->
	<hr>
	<div id="userListMenu<?= $tmpGroup->tmpId ?>">
		<?php foreach($usersList as $tmpUser){ ?>
			<div class="userListUser">
				<input type="checkbox" name="userList[]" value="<?= $tmpUser->_id ?>" id="box<?= $tmpGroup->tmpId.$tmpUser->_targetObjId ?>" <?= in_array($tmpUser->_id,$tmpGroup->userIds)?"checked":null ?>>
				<label for="box<?= $tmpGroup->tmpId.$tmpUser->_targetObjId ?>"><?= $tmpUser->display() ?></label>
			</div>
		<?php } ?>
	</div>
	<!--VALIDATION/SUPPRESSION-->
	<div class="formButtons">
		<input type="hidden" name="targetObjId" value="<?= $tmpGroup->tmpId ?>">
		<?= ($tmpGroup->isNew()) ? Txt::formValidate("add",false) : Txt::formValidate("modify",false) ?>
		<?php if($tmpGroup->isNew()==false){ ?><img src="app/img/delete.png" class="sLink" title="<?= Txt::trad("delete") ?>" onclick="if(confirm('<?= Txt::trad("confirmDelete",true) ?>')) {lightboxClose(true,'<?= $tmpGroup->getUrl("delete") ?>');}"><?php } ?> 
	</div>
</form>
<?php } ?>

<div id="addGroup">
	<button onclick="$('#form-userGroup-0').slideToggle();$('#form-userGroup-0 [name=title]').focus();"><?= Txt::trad("add") ?></button>	
</div>