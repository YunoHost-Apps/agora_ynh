<script type="text/javascript">
////	Resize
lightboxWidth(400);

////	Confirme l'envoi?
function formControl()
{
	//Vérifie que les champs obligatoires sont spécifiés
	if($("input[name='name']").isEmpty() || $("input[name='firstName']").isEmpty() || $("input[name='mail']").isEmpty())	{notify("<?= Txt::trad("fillAllFields") ?>");  return false;}
	// Verif mail & verif Ajax s'il existe déjà (car utilisé comme identifiant..)
	if(!isMail($("input[name='mail']").val()))  {notify("<?= Txt::trad("mailInvalid"); ?>");  return false;}
	var ajaxUrl="?ctrl=misc&action=UserAccountExist&mail="+encodeURIComponent($("input[name='mail']").val());
	var ajaxResult=$.ajax({url:ajaxUrl,async:false}).responseText;//Attend la réponse Ajax pour passer à la suite (async:false)
	if(find("true",ajaxResult))	{notify("<?= Txt::trad("USER_mailPresentYet"); ?>");  return false;}
}
</script>

<style>
input, textarea		{width:100% !important; margin-bottom:10px !important;}
#vInvitationList	{display:none;}
.vSpaceLabel		{font-size:90%;}
</style>

<div class="lightboxTitle"><?= Txt::trad("USER_sendInvitation") ?></div>

<form action="index.php" method="post" OnSubmit="return formControl();" class="lightboxContent">
	<!--ENVOI D'UNE INVITATION-->
	<?php foreach($userFields as $tmpField){ ?><input type="text" name="<?= $tmpField ?>" placeholder="<?= Txt::trad($tmpField) ?>"><?php } ?>
	<textarea name="comment" placeholder="<?= Txt::trad("comment") ?>"><?= Req::getParam("comment") ?></textarea>
	<?= Txt::formValidate("send") ?>
	
	<!--INVITATIONS EN ATTENTES ENVOYEES PAR L'USER COURANT-->
	<?php if(!empty($invitationList)){ ?>
	<br><hr><div class="sLink" onclick="$('#vInvitationList').fadeToggle();"><img src="app/img/mail.png"> <?= count($invitationList)." ".Txt::trad("USER_mailInvitationWait") ?></div>
	<ul id="vInvitationList">
		<?php
		//Invitations déjà envoyées
		foreach($invitationList as $tmpInvitation){
			$objSpace=Ctrl::getObj("space",$tmpInvitation["_idSpace"]);
			$deleteInvitationImg="<img src='app/img/delete.png' class='sLink' title=\"".txt::trad("delete")."\" onclick=\"confirmRedir('".Txt::trad("confirmDelete",true)."', '?ctrl=user&action=sendInvitation&deleteInvitation=true&_idInvitation=".$tmpInvitation["_idInvitation"]."')\" >";
			echo "<li>".$tmpInvitation["name"]." ".$tmpInvitation["firstName"]." - ".$tmpInvitation["mail"]." - ".Txt::displayDate($tmpInvitation["dateCrea"])." ".$deleteInvitationImg."<div class='vSpaceLabel'>".$objSpace->name."</div></li>";
		}
		?>
	</ul>
	<?php } ?>
</form>