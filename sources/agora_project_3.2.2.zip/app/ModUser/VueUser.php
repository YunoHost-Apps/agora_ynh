<script type="text/javascript">
lightboxWidth(400);//Resize
</script>

<style>
.objVueBg	{background-image:url('app/img/user/iconBg.png');}
</style>

<div class="lightboxContent objVueBg">
	<div class="lightboxObjTitle">
		<?php
		if($curObj->editRight())	{echo "<a href=\"javascript:lightboxOpen('".$curObj->getUrl("edit")."')\" class='lightboxObjEditIcon' title=\"".Txt::trad("modify")."\"><img src='app/img/edit.png'></a>";}
		echo $curObj->display("all");
		?>
	</div>
	<hr>
	<div class="personVueImg"><?= $curObj->getImg() ?></div>
	<div class="personVueFields">
		<?= $curObj->getFields("profile") ?>
		<div class="objField">
			<div class="fieldLabel"><img src="app/img/user/userConnection.png"> <?= Txt::trad("USER_lastConnection") ?></div>
			<div><?= !empty($curObj->lastConnection) ? Txt::displayDate($curObj->lastConnection) : Txt::trad("USER_notConnectedYet") ?></div>
		</div>
	</div>
	<?= $curObj->menuAttachedFiles() ?>
</div>