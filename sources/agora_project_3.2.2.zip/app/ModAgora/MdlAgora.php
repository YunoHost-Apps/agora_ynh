<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/


/*
 * Modele de la config de l'Agora
 */
class MdlAgora extends MdlObject
{
	const moduleName="agora";
	const objectType="agora";
	const dbTable="ap_agora";
	//Propriésé bdd
	const hasDateCrea=false;
	const hasAutor=false;
	const hasInfosModif=false;
	const hasAccessRight=false;
	//Propriétés d'IHM
	const hasShortcut=false;
	const hasAttachedFiles=false;
	const hasNotifMail=false;

	/*
	 * SURCHARGE : Constructeur
	 */
	function __construct()
	{
		parent::__construct(Db::getLine("select * from ap_agora"));
		if(!empty($this->personsSort))	{$this->personsSort="name";}
	}

	/*
	 * PATH DU LOGO EN BAS DE PAGE
	 */
	public function pathLogoFooter()
	{
		return (!empty($this->logo) && is_file(PATH_DATAS.$this->logo))  ?  PATH_DATAS.$this->logo  :  "app/img/logo.png";
	}

	/*
	 * PATH DU LOGO DE PAGE DE CONNEXION
	 */
	public function pathLogoConnect()
	{
		return (!empty($this->logoConnect) && is_file(PATH_DATAS.$this->logoConnect))  ?  PATH_DATAS.$this->logoConnect  :  null;
	}
}