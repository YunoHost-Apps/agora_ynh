<script>
$(function(){
	////	Logo du footer
	$("select[name='logo']").change(function(){
		$("#logoFile,#logoUrl").hide();
		if(this.value=="modify")	{$("#logoUrl,#logoFile").show();}
		else if(this.value!="")		{$("#logoUrl").show();}
	});

	////	Logo en page de connexion
	$("select[name='logoConnect']").change(function(){
		if(this.value=="modify")	{$("#logoConnectFile").show();}
		else						{$("#logoConnectFile").hide();}
	});

	////	Vérif le type du fichier
	$("#wallpaperFile,#logoFile,#logoConnectFile").change(function(){
		if(!find(".jpg",this.value) && !find(".jpeg",this.value) && !find(".png",this.value))
			{notify("<?= Txt::trad("AGORA_wallpaperLogoError") ?>");}
	});

	////	logsTimeOut par défaut après mise à jour
	if(Math.round("<?= Ctrl::$agora->logsTimeOut ?>")>0 && $("select[name='logsTimeOut'] option[value='<?= Ctrl::$agora->logsTimeOut ?>']").exist()==false)
		{$("select[name='logsTimeOut']").val("60");}
});

////    On contrôle le formulaire
function formControl()
{
	// Contrôle du nom
	if($("[name='name']").isEmpty() || ($("[name='limite_espace_disque']").exist() && $("[name='limite_espace_disque']").isEmpty()))
		{notify("<?= Txt::trad("fillAllFields") ?>");  return false; }
	if($("[name='limite_espace_disque']").exist() && isNaN($("[name='limite_espace_disque']").val()))	{notify("<?= Txt::trad("AGORA_diskSpaceInvalid") ?>"); return false; }
	if(!confirm("<?= Txt::trad("AGORA_confirmModif") ?>"))	{return false;}
}
</script>

<style>
.vAgoraForm, .vVersions, .vBackupForm	{padding:10px; margin-bottom:25px;}
#logoFile, #logoConnectFile	{display:none;}
#logoUrl					{margin-top:10px; <?= (empty(Ctrl::$agora->logo)) ? "display:none;":null ?>}
#imgLogo, #imgLogoConnect	{max-height:45px;}
#limite_espace_disque		{width:40px;}
.smtpLdapLabel				{cursor:pointer; margin-top:20px;}
#smtpConfig					{margin-top:10px; <?= (empty(Ctrl::$agora->sendmailFrom) && empty(Ctrl::$agora->smtpHost)) ? "display:none;":null ?>}
#smtpConfig .fieldLabel		{padding-left:20px;}
#ldapConfig					{margin-top:10px; <?= (empty(Ctrl::$agora->ldap_server)) ? "display:none;":null ?>}
#ldapConfig .fieldLabel		{padding-left:20px;}
.vBackupForm				{text-align:center;}
.vBackupForm img			{max-height:20px;}
.vBackupForm button			{min-width:60%; height:50px; margin:10px;}

/*RESPONSIVE -> 400px!*/
@media screen and (max-width:400px){
	form .objField	{margin-top:15px; margin-bottom:15px;}/*surcharge*/
	.fieldLabel		{padding-right:5px;}
}
</style>


<div class="pageCenter">
	<div class="pageCenterContent">
		<form action="index.php" method="post" onsubmit="return formControl()" class="vAgoraForm sBlock" enctype="multipart/form-data">
			
			<!--TITRE & DESCRIPTION-->
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_name") ?></div>
				<div><input type="text" name="name" value="<?= Ctrl::$agora->name ?>"></div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("description") ?></div>
				<div><input type="text" name="description" value="<?= Ctrl::$agora->description ?>"></div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_footerHtmlInfo") ?>"><?= Txt::trad("AGORA_footerHtml") ?></abbr></div>
				<div><textarea name="footerHtml"><?= Ctrl::$agora->footerHtml ?></textarea></div>
			</div>

			<!--INTERFACE DE L'ESPACE-->
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("wallpaper") ?></div>
				<div><?= CtrlMisc::menuWallpaper(Ctrl::$agora->wallpaper) ?></div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_logo") ?></div>
				<div>
					<img src="<?= Ctrl::$agora->pathLogoFooter() ?>" id="imgLogo">
					<select name="logo">
						<?php
						if(!empty(Ctrl::$agora->logo))	{echo "<option value=\"".Ctrl::$agora->logo."\">".Txt::trad("keep")."</option>";}
						echo "<option value=''>".Txt::trad("byDefault")."</option>";//aucun logo : 1ere option  / logo 2ème option
						echo "<option value='modify'>".Txt::trad("modify")."</option>";
						?>
					</select>
					<input type="file" name="logoFile" id="logoFile">
					<input type="text" name="logoUrl" id="logoUrl" value="<?= Ctrl::$agora->logoUrl ?>" placeholder="<?= Txt::trad("AGORA_logoUrl") ?>">
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_logoConnectInfo") ?>"><?= Txt::trad("AGORA_logoConnect") ?></abbr></div>
				<div>
					<img src="<?= Ctrl::$agora->pathLogoConnect() ?>" id="imgLogoConnect">
					<select name="logoConnect">
						<?php
						if(!empty(Ctrl::$agora->logoConnect))	{echo "<option value=\"".Ctrl::$agora->logoConnect."\">".Txt::trad("keep")."</option>";}
						echo "<option value=''>".(empty(Ctrl::$agora->logoConnect)?Txt::trad("none"):Txt::trad("delete"))."</option>";//aucun logo : 1ere option  / logo 2ème option
						echo "<option value='modify'>".(empty(Ctrl::$agora->logoConnect)?Txt::trad("add"):Txt::trad("modify"))."</option>";
						?>
					</select>
					<input type="file" name="logoConnectFile" id="logoConnectFile">
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_skin") ?></div>
				<div>
					<select name="skin">
						<option value="white"><?= Txt::trad("AGORA_white") ?></option>
						<option value="black" <?= Ctrl::$agora->skin=="black"?"selected":null ?>><?= Txt::trad("AGORA_black") ?></option>
					</select>
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_moduleLabelDisplay") ?></div>
				<div>
					<select name="moduleLabelDisplay">
						<option value=""><?= Txt::trad("show") ?></option>
						<option value="hide" <?= Ctrl::$agora->moduleLabelDisplay=="hide"?"selected":null ?>><?= Txt::trad("hide") ?></option>
					</select>
				</div>
			</div>

			<!--DETAILS DE PARAMETRAGE-->
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_lang") ?></div>
				<div><?= Txt::menuTrad("agora",Ctrl::$agora->lang) ?></div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_timezone") ?></div>
				<div>
					<select name="timezone">
						<?php foreach(Tool::$tabTimezones as $tmpLabel=>$timezone)  {echo "<option value=\"".$timezone."\" ".($timezone==Tool::$tabTimezones[Ctrl::$curTimezone]?'selected':null).">[gmt ".($timezone>0?"+":"").$timezone."] ".$tmpLabel."</option>";}?>
					</select>
				</div>
			</div>
			<?php if(!defined("HOST_DOMAINE")){ ?>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_diskSpaceLimit") ?></div>
				<div><input type="text" name="limite_espace_disque" id="limite_espace_disque" value="<?= round((limite_espace_disque/File::sizeGo),2) ?>"> <?= Txt::trad("gigaOctet")?></div>
			</div>
			<?php } ?>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_logsTimeOut") ?></div>
				<div>
					<select name="logsTimeOut">
						<?php foreach($logsTimeOut as $tmpTime)  {echo "<option value='".$tmpTime."' ".($tmpTime==Ctrl::$agora->logsTimeOut?"selected":null).">".$tmpTime."</option>";} ?>
					</select>
					<?= Txt::trad("days") ?>
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_personsSort") ?></div>
				<div>
					<select name="personsSort">
						<option value="firstName"><?= Txt::trad("firstName") ?></option>
						<option value="name" <?= Ctrl::$agora->personsSort=="name"?"selected":null ?>><?= Txt::trad("name") ?></option>
					</select>
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_messengerDisabled") ?></div>
				<div>
					<select name="messengerDisabled">
						<option value=""><?= Txt::trad("yes") ?></option>
						<option value="1" <?= !empty(Ctrl::$agora->messengerDisabled)?"selected":null ?>><?= Txt::trad("no") ?></option>
					</select>
				</div>
			</div>
			<div class="objField">
				<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_personalCalendarsDisabled_infos") ?>"><?= Txt::trad("AGORA_personalCalendarsDisabled") ?></abbr></div>
				<div>
					<select name="personalCalendarsDisabled">
						<option value=""><?= Txt::trad("yes") ?></option>
						<option value="1" <?= !empty(Ctrl::$agora->personalCalendarsDisabled)?"selected":null ?>><?= Txt::trad("no") ?></option>
					</select>
				</div>
			</div>

			<!--SMTP-->
			<?php if(!defined("HOST_DOMAINE")){ ?>
			<div class="smtpLdapLabel" onclick="$('#smtpConfig').fadeToggle()"><?= Txt::trad("AGORA_smtpLabel") ?> <img src="app/img/plusSmall.png"></div>
			<div id="smtpConfig">
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_sendmailFrom") ?></div>
					<div><input type="text" name="sendmailFrom" value="<?= Ctrl::$agora->sendmailFrom ?>" placeholder="<?= Txt::trad("AGORA_sendmailFromPlaceholder") ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_smtpHost") ?></div>
					<div><input type="text" name="smtpHost" value="<?= Ctrl::$agora->smtpHost ?>"></div>
				</div>
				<div class="objField" title="<?= Txt::trad("AGORA_smtpPortInfo") ?>">
					<div class="fieldLabel"><?= Txt::trad("AGORA_smtpPort") ?></div>
					<div><input type="text" name="smtpPort" value="<?= Ctrl::$agora->smtpPort ?>"></div>
				</div>
				<div class="objField" title="<?= Txt::trad("AGORA_smtpSecureInfo") ?>">
					<div class="fieldLabel"><?= Txt::trad("AGORA_smtpSecure") ?></div>
					<div><input type="text" name="smtpSecure" value="<?= Ctrl::$agora->smtpSecure ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_smtpUsername") ?></div>
					<div><input type="text" name="smtpUsername" value="<?= Ctrl::$agora->smtpUsername ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_smtpPass") ?></div>
					<div><input type="text" name="smtpPass" value="<?= Ctrl::$agora->smtpPass ?>"></div>
				</div>
			</div>
			<?php } ?>

			<!--LDAP-->
			<div class="smtpLdapLabel" onclick="$('#ldapConfig').fadeToggle()"><?= Txt::trad("AGORA_ldapLabel") ?> <img src="app/img/plusSmall.png"></div>
			<?php
			//Module de connexion Ldap désactivé / activé
			if(!function_exists("ldap_connect"))  {echo "<div class='labelInfos'>".Txt::trad("AGORA_ldapDisabled")."</div>";}
			else{
			?>
			<div id="ldapConfig">
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_ldapHost") ?></div>
					<div><input type="text" name="ldap_server" value="<?= Ctrl::$agora->ldap_server ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_ldapPortInfo") ?>"><?= Txt::trad("AGORA_ldapPort") ?></abbr></div>
					<div><input type="text" name="ldap_server_port" value="<?= Ctrl::$agora->ldap_server_port ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_ldapLoginInfo") ?>"><?= Txt::trad("AGORA_ldapLogin") ?></abbr></div>
					<div><input type="text" name="ldap_admin_login" value="<?= Ctrl::$agora->ldap_admin_login ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_ldapPass") ?></div>
					<div><input type="text" name="ldap_admin_pass" value="<?= Ctrl::$agora->ldap_admin_pass ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_ldapDnInfo") ?>"><?= Txt::trad("AGORA_ldapDn") ?></abbr></div>
					<div><input type="text" name="ldap_base_dn" value="<?= Ctrl::$agora->ldap_base_dn ?>"></div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><abbr title="<?= Txt::trad("AGORA_ldapCreaAutoUsersInfo") ?>"><?= Txt::trad("AGORA_ldapCreaAutoUsers") ?></abbr></div>
					<div>
						<select name="ldap_crea_auto_users">
							<option value="1"><?= Txt::trad("yes") ?></option>
							<option value="" <?= empty(Ctrl::$agora->ldap_crea_auto_users)?"selected":null ?>><?= Txt::trad("no") ?></option>
						</select>
					</div>
				</div>
				<div class="objField">
					<div class="fieldLabel"><?= Txt::trad("AGORA_ldapPassEncrypt") ?></div>
					<div>
						<select name="ldap_pass_cryptage">
							<option value="1"><?= Txt::trad("none") ?></option>
							<option value="sha" <?= Ctrl::$agora->ldap_pass_cryptage=="sha"?"selected":null ?>>SHA</option>
							<option value="md5" <?= Ctrl::$agora->ldap_pass_cryptage=="md5"?"selected":null ?>>Md5</option>
						</select>
					</div>
				</div>
			</div>
			<?php } ?>

			<!--VALIDATION DU FORMULAIRE-->
			<?= Txt::formValidate("modify") ?>
		</form>

		<!--INFOS & VERSIONS-->
		<form class="sBlock vVersions">
			<div class="objField">
				<div class="fieldLabel"><?= Txt::trad("AGORA_versions") ?></div>
				<div class="vAgoraVersions">
					Agora-Project <?= Ctrl::$agora->version_agora ?> <img src="app/img/separator.png"> <?= Txt::trad("AGORA_dateUpdate")." ".Txt::displayDate(Ctrl::$agora->dateUpdateDb,"dateMini") ?><br>
					PHP <?= str_replace(strstr(phpversion(),"+deb"),null,phpversion()); ?> <img src="app/img/separator.png"> MySQL <?= str_replace(strstr(Db::dbVersion(),"+deb"),null,Db::dbVersion()); ?>
					<?php if(!function_exists("mail")){ ?><div title="<?= Txt::trad("AGORA_funcMailInfo") ?>"><img src="app/img/delete.png"> &nbsp; <?= Txt::trad("AGORA_funcMailDisabled") ?></div><?php } ?>
					<?php if(!function_exists("imagecreatetruecolor")){ ?><div><img src="app/img/delete.png"> &nbsp; <?= Txt::trad("AGORA_funcImgDisabled") ?></div><?php } ?>
				</div>
			</div>
		</form>
		
		<?php if(Tool::isMobile()==false){ ?>
		<form class="sBlock vBackupForm" action="index.php" method="post">
			<input type="hidden" name="ctrl" value="agora">
			<input type="hidden" name="action" value="getBackup">
			<button type="submit" name="typeBackup" value="all" <?= $alertMessageBigSav==true?"onClick=\"alert('".addslashes(Txt::trad("AGORA_backupNotif"))."')\"":null ?>><img src="app/img/download.png"> <?= Txt::trad("AGORA_backupFull") ?> <img src="app/img/diskSpace.png"><img src="app/img/folderSmall.png"></button>
			<button type="submit" name="typeBackup" value="db"><img src="app/img/download.png"> <?= Txt::trad("AGORA_backupDb") ?> <img src="app/img/diskSpace.png"></button>
		</form>
		<?php } ?>
	</div>
</div>