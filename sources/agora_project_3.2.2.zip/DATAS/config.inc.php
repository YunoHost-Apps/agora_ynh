<?php
//CONNEXION À LA BDD
define("db_host", "localhost");
define("db_login", "omnispace");
define("db_password", "admin");
define("db_name", "agora");

//ESPACE DISQUE / NB USERS / SALT
define("limite_espace_disque", "10737418240");
define("limite_nb_users", "10000");
define("AGORA_SALT", "");
